/**
 * NEPSE Financial and Numeric Formatters
 */

export function formatNPR(value: number | null | undefined, decimals = 2): string {
  if (value === null || value === undefined || isNaN(value)) return 'NPR 0.00';
  return `NPR ${value.toLocaleString('en-IN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })}`;
}

export function formatPercent(value: number | null | undefined, includeSign = true, decimals = 2): string {
  if (value === null || value === undefined || isNaN(value)) return '0.00%';
  const sign = includeSign && value > 0 ? '+' : '';
  return `${sign}${value.toFixed(decimals)}%`;
}

export function formatNumber(value: number | null | undefined, decimals = 0): string {
  if (value === null || value === undefined || isNaN(value)) return '0';
  return value.toLocaleString('en-IN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function formatNepseDenomination(value: number | null | undefined): string {
  if (value === null || value === undefined || isNaN(value)) return '0.00';
  const abs = Math.abs(value);
  const sign = value < 0 ? '-' : '';

  if (abs >= 10000000) {
    // Crores (1 Cr = 10,000,000)
    return `${sign}${(abs / 10000000).toFixed(2)} Cr`;
  } else if (abs >= 100000) {
    // Lakhs (1 Lakh = 100,000)
    return `${sign}${(abs / 100000).toFixed(2)} L`;
  } else if (abs >= 1000) {
    // Thousands
    return `${sign}${(abs / 1000).toFixed(1)} K`;
  }
  return `${sign}${abs.toFixed(2)}`;
}
