import { CompanyMaster } from '../types/dataInfrastructure';
import { normalizedCompanies } from '../data/normalizedMasterData';
import { supabase } from '../lib/supabaseClient';

export class CompanyRepository {
  public async getAllCompanies(): Promise<CompanyMaster[]> {
    try {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .order('symbol', { ascending: true });

      if (error || !data || data.length === 0) {
        return [...normalizedCompanies];
      }

      return data as CompanyMaster[];
    } catch {
      return [...normalizedCompanies];
    }
  }

  public async getCompanyBySymbol(symbol: string): Promise<CompanyMaster | null> {
    const companies = await this.getAllCompanies();
    return companies.find(c => c.symbol.toUpperCase() === symbol.toUpperCase()) || null;
  }
}

export const companyRepository = new CompanyRepository();
