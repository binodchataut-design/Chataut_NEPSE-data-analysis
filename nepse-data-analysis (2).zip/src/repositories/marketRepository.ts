import { MarketIndexRecord } from '../types/dataInfrastructure';
import { normalizedIndices } from '../data/normalizedMasterData';
import { supabase } from '../lib/supabaseClient';

export class MarketRepository {
  public async getIndices(): Promise<MarketIndexRecord[]> {
    try {
      const { data, error } = await supabase
        .from('indices')
        .select('*')
        .order('date', { ascending: false });

      if (error || !data || data.length === 0) {
        return [...normalizedIndices];
      }

      return data as MarketIndexRecord[];
    } catch {
      return [...normalizedIndices];
    }
  }
}

export const marketRepository = new MarketRepository();
