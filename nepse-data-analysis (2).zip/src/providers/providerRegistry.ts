/**
 * Provider Registry
 * Manages active data source modes ('MOCK_DATA', 'SUPABASE', 'REAL_DATA', 'LIVE')
 * and returns appropriate provider instances for Market, Stock, Fundamental, and Broker data.
 */

import { DataSourceMode } from '../types';
import {
  IMarketDataProvider,
  IStockDataProvider,
  IFundamentalDataProvider,
  IBrokerDataProvider
} from './interfaces';
import { MockMarketDataProvider } from './mock/MockMarketDataProvider';
import { MockStockDataProvider } from './mock/MockStockDataProvider';
import { MockFundamentalDataProvider } from './mock/MockFundamentalDataProvider';
import { MockBrokerDataProvider } from './mock/MockBrokerDataProvider';
import {
  LiveMarketDataProvider,
  LiveStockDataProvider,
  LiveFundamentalDataProvider,
  LiveBrokerDataProvider
} from './live/LiveProviders';

export class ProviderRegistry {
  private mode: DataSourceMode = 'MOCK_DATA';
  private listeners: ((mode: DataSourceMode) => void)[] = [];

  private mockMarket = new MockMarketDataProvider();
  private mockStock = new MockStockDataProvider();
  private mockFundamental = new MockFundamentalDataProvider();
  private mockBroker = new MockBrokerDataProvider();

  private liveMarket = new LiveMarketDataProvider();
  private liveStock = new LiveStockDataProvider();
  private liveFundamental = new LiveFundamentalDataProvider();
  private liveBroker = new LiveBrokerDataProvider();

  public getMode(): DataSourceMode {
    return this.mode;
  }

  public setMode(newMode: DataSourceMode): void {
    if (this.mode === newMode) return;
    this.mode = newMode;
    this.listeners.forEach(fn => fn(newMode));
  }

  public subscribe(listener: (mode: DataSourceMode) => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  public getMarketProvider(): IMarketDataProvider {
    return this.mode === 'LIVE' || this.mode === 'REAL_DATA' ? this.liveMarket : this.mockMarket;
  }

  public getStockProvider(): IStockDataProvider {
    return this.mode === 'LIVE' || this.mode === 'REAL_DATA' ? this.liveStock : this.mockStock;
  }

  public getFundamentalProvider(): IFundamentalDataProvider {
    return this.mode === 'LIVE' || this.mode === 'REAL_DATA' ? this.liveFundamental : this.mockFundamental;
  }

  public getBrokerProvider(): IBrokerDataProvider {
    return this.mode === 'LIVE' || this.mode === 'REAL_DATA' ? this.liveBroker : this.mockBroker;
  }
}

export const providerRegistry = new ProviderRegistry();
