import { IStockDataProvider } from '../interfaces';
import { CompanyMaster, HistoricalPriceRecord, ProviderStatusInfo } from '../../types/dataInfrastructure';
import { normalizedCompanies, getNormalizedStockBars } from '../../data/normalizedMasterData';

export class MockStockDataProvider implements IStockDataProvider {
  public readonly providerName = 'MockStockDataProvider';
  public readonly isLive = false;

  public getStatus(): ProviderStatusInfo {
    return {
      providerStatus: 'MOCK_DATA',
      reason: 'Standardized simulated reference dataset loaded for calculation validation.',
      timestamp: new Date().toISOString(),
      gateway: this.providerName,
      authenticated: true,
    };
  }

  public async fetchCompanies(): Promise<CompanyMaster[]> {
    return [...normalizedCompanies];
  }

  public async fetchPriceHistory(symbolOrId: string, limit?: number): Promise<HistoricalPriceRecord[]> {
    const sym = symbolOrId.toUpperCase();
    const bars = getNormalizedStockBars(sym);
    const records: HistoricalPriceRecord[] = bars.map((b, idx) => ({
      id: `${sym}-${b.date}`,
      company_id: `cmp-${sym.toLowerCase()}`,
      symbol: sym,
      date: b.date,
      open: b.open,
      high: b.high,
      low: b.low,
      close: b.close,
      previous_close: idx > 0 ? bars[idx - 1].close : b.open,
      change: idx > 0 ? Math.round((b.close - bars[idx - 1].close) * 100) / 100 : 0,
      change_percent: idx > 0 ? Math.round(((b.close - bars[idx - 1].close) / bars[idx - 1].close) * 10000) / 100 : 0,
      volume: b.volume,
      turnover: b.turnover || b.close * b.volume,
      transactions: 250,
      created_at: `${b.date}T15:00:00Z`,
    }));

    if (limit && limit > 0) {
      return records.slice(-limit);
    }
    return records;
  }

  public async fetchLatestPrice(symbolOrId: string): Promise<HistoricalPriceRecord | null> {
    const history = await this.fetchPriceHistory(symbolOrId, 1);
    return history.length > 0 ? history[0] : null;
  }
}
