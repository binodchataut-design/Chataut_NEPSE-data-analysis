/**
 * Corporate Action Service (Phase 3D / 4A)
 */

export interface CorporateActionRecord {
  id: string;
  symbol: string;
  actionType: 'BONUS_SHARE' | 'RIGHT_SHARE' | 'CASH_DIVIDEND' | 'STOCK_SPLIT' | 'MERGER';
  date: string;
  bookClosureDate?: string;
  ratio?: string;
  cashPercent?: number;
  bonusPercent?: number;
  adjustmentFactor: number;
  description: string;
}

export class CorporateActionService {
  private static actions: CorporateActionRecord[] = [
    {
      id: 'ca-chcl-1',
      symbol: 'CHCL',
      actionType: 'BONUS_SHARE',
      date: '2025-12-15',
      bonusPercent: 5.0,
      adjustmentFactor: 1.05,
      description: '5.0% Bonus Share declared for FY 2080/081',
    },
    {
      id: 'ca-nabil-1',
      symbol: 'NABIL',
      actionType: 'BONUS_SHARE',
      date: '2025-11-20',
      bonusPercent: 10.0,
      adjustmentFactor: 1.10,
      description: '10.0% Bonus Share declared for FY 2080/081',
    },
  ];

  public static getActionsForSymbol(symbol: string): CorporateActionRecord[] {
    const cleanSym = symbol.toUpperCase();
    return this.actions.filter(a => a.symbol.toUpperCase() === cleanSym);
  }

  public static getAllActions(): CorporateActionRecord[] {
    return [...this.actions];
  }
}
