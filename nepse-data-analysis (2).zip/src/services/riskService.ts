/**
 * Risk Management and Position Sizing Service
 */

import { RiskAlert } from '../types';
import { mockRiskAlerts } from '../data/mockData';

export interface PositionSizeResult {
  shares: number;
  totalCost: number;
  riskAmount: number;
  rewardAmount: number;
  riskRewardRatio: number;
  portfolioWeightPercent: number;
  lossPerShare: number;
  gainPerShare: number;
}

export class RiskService {
  public async getActiveRiskAlerts(): Promise<RiskAlert[]> {
    return [...mockRiskAlerts];
  }

  public calculatePositionSize(
    capital: number,
    riskPercent: number,
    entryPrice: number,
    stopPrice: number,
    targetPrice: number
  ): PositionSizeResult {
    const riskAmount = (capital * riskPercent) / 100;
    const lossPerShare = Math.max(0.1, entryPrice - stopPrice);
    const gainPerShare = Math.max(0.1, targetPrice - entryPrice);

    const rawShares = Math.floor(riskAmount / lossPerShare);
    const shares = Math.max(10, Math.floor(rawShares / 10) * 10); // round to multiple of 10 for NEPSE
    const totalCost = shares * entryPrice;
    const rewardAmount = shares * gainPerShare;
    const riskRewardRatio = Math.round((gainPerShare / lossPerShare) * 100) / 100;
    const portfolioWeightPercent = Math.round((totalCost / capital) * 1000) / 10;

    return {
      shares,
      totalCost,
      riskAmount: shares * lossPerShare,
      rewardAmount,
      riskRewardRatio,
      portfolioWeightPercent,
      lossPerShare,
      gainPerShare,
    };
  }
}

export const riskService = new RiskService();
