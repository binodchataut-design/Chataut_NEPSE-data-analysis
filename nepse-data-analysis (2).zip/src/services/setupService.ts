/**
 * Predefined Trading Setup Detection Service
 */

import { SetupDetection, SetupType } from '../types';
import { mockSetups } from '../data/mockData';

export class SetupService {
  public async getDetectedSetups(): Promise<SetupDetection[]> {
    return [...mockSetups];
  }

  public async getSetupTypes(): Promise<Array<{ type: SetupType; label: string; description: string }>> {
    return [
      { type: 'BREAKOUT', label: 'Resistance Breakout', description: 'Price breaks through multi-week consolidation resistance with volume surge.' },
      { type: 'PULLBACK', label: 'Trend Pullback to EMA', description: 'Healthy retracement back into the 20-period EMA during confirmed uptrend.' },
      { type: 'ACCUMULATION', label: 'Institutional Base', description: 'Tight daily ranges with above-average volume near key structural support.' },
      { type: 'REVERSAL', label: 'Bullish Divergence Reversal', description: 'Momentum oscillator higher low while price creates marginal lower low.' },
      { type: 'MOMENTUM', label: 'Trend Continuation', description: 'Breakout above previous session high with expanding volatility and volume.' },
    ];
  }
}

export const setupService = new SetupService();
