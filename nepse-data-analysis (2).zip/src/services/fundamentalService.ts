/**
 * Fundamental Analysis Service
 */

import { FundamentalMetrics, FundamentalScoreBreakdown } from '../types';

export class FundamentalService {
  public async getMetrics(symbol: string): Promise<FundamentalMetrics> {
    const sym = symbol.toUpperCase();
    return {
      symbol: sym,
      peRatio: 16.8,
      pbRatio: 2.1,
      roe: 18.5,
      roa: 3.4,
      eps: 32.4,
      bookValue: 245.0,
      dividendYield: 4.2,
      debtToEquity: 0.85,
      netProfitMargin: 24.2,
    };
  }

  public calculateFundamentalScore(metrics: FundamentalMetrics): FundamentalScoreBreakdown {
    const valuationScore = metrics.peRatio < 20 ? 80 : 60;
    const profitabilityScore = metrics.roe > 15 ? 85 : 65;
    const solvencyScore = metrics.debtToEquity < 1.5 ? 90 : 70;
    const growthScore = 75;
    const compositeScore = Math.round((valuationScore + profitabilityScore + solvencyScore + growthScore) / 4);

    let classification = 'Grade B (Solid)';
    if (compositeScore >= 85) classification = 'Grade A (High Quality)';
    else if (compositeScore < 70) classification = 'Grade C (Moderate Risk)';

    return {
      compositeScore,
      valuationScore,
      profitabilityScore,
      solvencyScore,
      growthScore,
      classification,
    };
  }
}

export const fundamentalService = new FundamentalService();
