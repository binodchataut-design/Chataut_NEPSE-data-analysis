/**
 * Multi-Factor Scoring Weight Service
 */

import { ScoringWeights } from '../types';

export class ScoringService {
  private weights: ScoringWeights = {
    technical: 30,
    fundamental: 25,
    market: 15,
    broker: 15,
    risk: 15,
  };

  public getWeights(): ScoringWeights {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('nepse_scoring_weights');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fallback
        }
      }
    }
    return { ...this.weights };
  }

  public setWeights(newWeights: ScoringWeights): void {
    this.weights = { ...newWeights };
    if (typeof window !== 'undefined') {
      localStorage.setItem('nepse_scoring_weights', JSON.stringify(this.weights));
    }
  }
}

export const scoringService = new ScoringService();
