/**
 * Current Market State Service (Phase 4A)
 */

import { CurrentMarketState } from '../types/currentStateEngine';
import { normalizedIndices, normalizedDailyStats } from '../data/normalizedMasterData';

export class CurrentMarketStateService {
  public static getLatestMarketDate(): string {
    return '2026-08-30';
  }

  public static getMarketState(asOfDate?: string): CurrentMarketState {
    const targetDate = asOfDate || this.getLatestMarketDate();
    const nepseIndex = normalizedIndices.find(i => i.index_id === 'NEPSE') || normalizedIndices[0];

    return {
      asOfDate: targetDate,
      regime: 'BULLISH',
      nepseClose: nepseIndex.close,
      nepseChange: nepseIndex.change,
      nepseChangePercent: nepseIndex.change_percent,
      marketTurnover: normalizedDailyStats.total_turnover,
      marketTurnover20Avg: 5400000000,
      breadth: {
        advances: normalizedDailyStats.advancers,
        declines: normalizedDailyStats.decliners,
        unchanged: normalizedDailyStats.unchanged,
        adRatio: normalizedDailyStats.advance_decline_ratio,
      },
      sectorDispersion: 1.45,
      warnings: [],
    };
  }
}
