/**
 * Market Intelligence Service
 */

import { MarketIndex, Sector, MarketBreadth } from '../types';
import { normalizedIndices, normalizedSectors, normalizedDailyStats } from '../data/normalizedMasterData';
import { providerRegistry } from '../providers/providerRegistry';

export class MarketService {
  public async getMarketIndices(): Promise<MarketIndex[]> {
    const indices = await providerRegistry.getMarketProvider().fetchIndices();
    return indices.map(idx => ({
      symbol: idx.index_id,
      name: idx.name,
      currentValue: idx.close,
      change: idx.change,
      changePercent: idx.change_percent,
      high: idx.high,
      low: idx.low,
      turnover: idx.turnover,
      timestamp: idx.date,
    }));
  }

  public async getSectors(): Promise<Sector[]> {
    return normalizedSectors.map((sec, idx) => ({
      id: sec.id,
      name: sec.name,
      indexSymbol: sec.index_symbol,
      changePercent: Math.round(((idx % 2 === 0 ? 1 : -1) * (0.4 + (idx * 0.2))) * 100) / 100,
      turnover: Math.round(150000000 + (idx * 85000000)),
      advanceDeclineRatio: 1.8,
      peRatio: 16.5 + idx * 1.2,
    }));
  }

  public async getMarketBreadth(): Promise<MarketBreadth> {
    const stats = await providerRegistry.getMarketProvider().fetchDailyStatistics();
    return {
      advances: stats.advancers,
      declines: stats.decliners,
      unchanged: stats.unchanged,
      totalTradedShares: stats.total_volume,
      totalTurnover: stats.total_turnover,
      totalTransactions: stats.total_transactions,
      adRatio: stats.advance_decline_ratio,
    };
  }
}

export const marketService = new MarketService();
