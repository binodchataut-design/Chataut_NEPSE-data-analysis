/**
 * Liquidity Validation Service (Phase 3D / 4A)
 */

import { OHLCVBar } from '../types/technicalIndicators';

export interface LiquidityMetrics {
  averageTurnover20: number;
  averageTurnover60: number;
  averageVolume20: number;
  tradedDayRatio: number;
  zeroVolumeRatio: number;
  tier: 'HIGH' | 'MEDIUM' | 'LOW' | 'ILLIQUID';
  slippageEstimateBps: number;
}

export class LiquidityValidationService {
  public static computeLiquidityMetrics(symbol: string, bars: OHLCVBar[]): LiquidityMetrics {
    if (!bars || bars.length === 0) {
      return {
        averageTurnover20: 0,
        averageTurnover60: 0,
        averageVolume20: 0,
        tradedDayRatio: 0,
        zeroVolumeRatio: 1,
        tier: 'ILLIQUID',
        slippageEstimateBps: 150,
      };
    }

    const last20 = bars.slice(-20);
    const last60 = bars.slice(-60);

    const sumTurnover20 = last20.reduce((acc, b) => acc + (b.turnover || b.close * b.volume), 0);
    const sumTurnover60 = last60.reduce((acc, b) => acc + (b.turnover || b.close * b.volume), 0);
    const sumVolume20 = last20.reduce((acc, b) => acc + b.volume, 0);

    const avgTurnover20 = sumTurnover20 / Math.max(1, last20.length);
    const avgTurnover60 = sumTurnover60 / Math.max(1, last60.length);
    const avgVolume20 = sumVolume20 / Math.max(1, last20.length);

    const zeroVolumeCount = last20.filter(b => !b.volume || b.volume === 0).length;
    const zeroVolumeRatio = zeroVolumeCount / Math.max(1, last20.length);
    const tradedDayRatio = 1 - zeroVolumeRatio;

    let tier: 'HIGH' | 'MEDIUM' | 'LOW' | 'ILLIQUID' = 'MEDIUM';
    if (avgTurnover20 >= 20000000) tier = 'HIGH';
    else if (avgTurnover20 >= 5000000) tier = 'MEDIUM';
    else if (avgTurnover20 >= 1000000) tier = 'LOW';
    else tier = 'ILLIQUID';

    const slippageEstimateBps = tier === 'HIGH' ? 15 : tier === 'MEDIUM' ? 35 : tier === 'LOW' ? 75 : 180;

    return {
      averageTurnover20: Math.round(avgTurnover20),
      averageTurnover60: Math.round(avgTurnover60),
      averageVolume20: Math.round(avgVolume20),
      tradedDayRatio,
      zeroVolumeRatio,
      tier,
      slippageEstimateBps,
    };
  }
}
