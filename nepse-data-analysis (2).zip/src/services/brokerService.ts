/**
 * Floor Sheet & Broker Analytics Service
 */

import { BrokerActivity, StockBrokerConcentration } from '../types';

export class BrokerService {
  public async getTopBrokers(): Promise<BrokerActivity[]> {
    return [
      {
        brokerCode: '58',
        brokerName: 'Naasa Securities Co. Ltd.',
        buyAmount: 185400000,
        sellAmount: 142100000,
        netAmount: 43300000,
        topBoughtSymbols: ['CHCL', 'NABIL', 'SHIVM'],
        topSoldSymbols: ['NICA', 'GBIME'],
      },
      {
        brokerCode: '45',
        brokerName: 'Imperial Securities Co. Pvt. Ltd.',
        buyAmount: 142000000,
        sellAmount: 158000000,
        netAmount: -16000000,
        topBoughtSymbols: ['AKPL', 'NMB'],
        topSoldSymbols: ['CHCL', 'CIT'],
      },
      {
        brokerCode: '34',
        brokerName: 'Vision Securities Pvt. Ltd.',
        buyAmount: 128000000,
        sellAmount: 96000000,
        netAmount: 32000000,
        topBoughtSymbols: ['HDL', 'EBL'],
        topSoldSymbols: ['PCBL'],
      },
      {
        brokerCode: '28',
        brokerName: 'Shrikrishna Securities Ltd.',
        buyAmount: 98000000,
        sellAmount: 85000000,
        netAmount: 13000000,
        topBoughtSymbols: ['CIT', 'SCB'],
        topSoldSymbols: ['ADBL'],
      },
    ];
  }

  public async getStockBrokerConcentration(symbol: string): Promise<StockBrokerConcentration> {
    const sym = symbol.toUpperCase();
    return {
      symbol: sym,
      top5BrokersShare: 42.5,
      top10BrokersShare: 68.2,
      dominantBroker: 'Broker 58 (Naasa Securities)',
      dominantAction: 'ACCUMULATION',
      netInstitutionalFlow: 24500000,
    };
  }
}

export const brokerService = new BrokerService();
