/**
 * Sector State Service (Phase 4A)
 */

import { CurrentSectorState, RelativeStrengthState, TrendState } from '../types/currentStateEngine';
import { normalizedCompanies, normalizedSectors } from '../data/normalizedMasterData';

export interface SectorStateDetail extends CurrentSectorState {
  sectorReturn5D: number;
  sectorReturn20D: number;
  sectorReturn60D: number;
}

export class SectorStateService {
  public static getSectorState(symbol: string, asOfDate?: string): SectorStateDetail {
    const cleanSym = symbol.toUpperCase();
    const company = normalizedCompanies.find(c => c.symbol.toUpperCase() === cleanSym);
    const sectorName = company?.sector || 'Hydropower';
    const sector = normalizedSectors.find(s => s.name.toLowerCase() === sectorName.toLowerCase()) || normalizedSectors[0];

    return {
      sectorId: sector.id,
      sectorName: sector.name,
      asOfDate: asOfDate || '2026-08-30',
      indexValue: 3162.10,
      changePercent: 1.33,
      turnover: 2840000000,
      turnoverSharePercent: 41.5,
      relativeStrengthMarket: 'OUTPERFORMING' as RelativeStrengthState,
      trend: 'UPTREND' as TrendState,
      breadth: {
        advances: 42,
        declines: 12,
      },
      warnings: [],
      sectorReturn5D: 2.4,
      sectorReturn20D: 6.8,
      sectorReturn60D: 11.2,
    };
  }

  public static getAllSectorStates(asOfDate?: string): SectorStateDetail[] {
    return normalizedSectors.map(s => ({
      sectorId: s.id,
      sectorName: s.name,
      asOfDate: asOfDate || '2026-08-30',
      indexValue: 2450.0,
      changePercent: 0.85,
      turnover: 1200000000,
      turnoverSharePercent: 15.0,
      relativeStrengthMarket: 'IN_LINE' as RelativeStrengthState,
      trend: 'UPTREND' as TrendState,
      breadth: { advances: 15, declines: 8 },
      warnings: [],
      sectorReturn5D: 1.9,
      sectorReturn20D: 4.8,
      sectorReturn60D: 8.5,
    }));
  }
}
