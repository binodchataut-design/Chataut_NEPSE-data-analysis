/**
 * Portfolio Management Service
 */

import { PortfolioPosition, PortfolioSummary } from '../types';
import { mockPortfolioPositions } from '../data/mockData';
import { getNormalizedStockBars } from '../data/normalizedMasterData';

export class PortfolioService {
  private positions: PortfolioPosition[] = [...mockPortfolioPositions];

  public async getPortfolioPositions(): Promise<PortfolioPosition[]> {
    return [...this.positions];
  }

  public async getPortfolioSummary(): Promise<PortfolioSummary> {
    let totalInvested = 0;
    let totalValue = 0;

    for (const pos of this.positions) {
      totalInvested += pos.investedAmount;
      totalValue += pos.currentValue;
    }

    const totalPnl = totalValue - totalInvested;
    const totalPnlPercent = totalInvested > 0 ? Math.round((totalPnl / totalInvested) * 10000) / 100 : 0;
    const dailyPnl = Math.round(totalValue * 0.012);
    const dailyPnlPercent = 1.2;

    return {
      totalInvested,
      totalValue,
      totalPnl,
      totalPnlPercent,
      dailyPnl,
      dailyPnlPercent,
      cashBalance: 450000,
      stockCount: this.positions.length,
    };
  }

  public async addPosition(symbol: string, quantity: number, buyPrice: number): Promise<void> {
    const cleanSym = symbol.toUpperCase();
    const bars = getNormalizedStockBars(cleanSym);
    const currentPrice = bars.length > 0 ? bars[bars.length - 1].close : buyPrice;
    const investedAmount = quantity * buyPrice;
    const currentValue = quantity * currentPrice;
    const pnl = currentValue - investedAmount;
    const pnlPercent = investedAmount > 0 ? Math.round((pnl / investedAmount) * 10000) / 100 : 0;

    this.positions.push({
      symbol: cleanSym,
      companyName: `${cleanSym} Company Ltd.`,
      quantity,
      buyPrice,
      currentPrice,
      investedAmount,
      currentValue,
      pnl,
      pnlPercent,
      sector: 'General',
      weightPercent: 10.0,
    });
  }

  public async removePosition(symbol: string): Promise<void> {
    this.positions = this.positions.filter(p => p.symbol.toUpperCase() !== symbol.toUpperCase());
  }
}

export const portfolioService = new PortfolioService();
