/**
 * Stock Data Service
 */

import { Company } from '../types';
import { normalizedCompanies, getNormalizedStockBars } from '../data/normalizedMasterData';
import { OHLCVBar } from '../types/technicalIndicators';
import { getCachedBars, getCachedCompany } from '../data/liveBarsCache';

export class StockService {
  public async getAllStocks(): Promise<Company[]> {
    return normalizedCompanies.map(c => {
      const bars = getNormalizedStockBars(c.symbol);
      const lastBar = bars[bars.length - 1] || { close: 350, open: 345, volume: 50000 };
      const prevBar = bars.length > 1 ? bars[bars.length - 2] : lastBar;
      const change = Math.round((lastBar.close - prevBar.close) * 100) / 100;
      const changePercent = Math.round(((lastBar.close - prevBar.close) / prevBar.close) * 10000) / 100;

      return {
        symbol: c.symbol,
        company_name: c.company_name,
        sector: c.sector || 'Others',
        ltp: lastBar.close,
        change,
        changePercent,
        volume: lastBar.volume,
        peRatio: 18.5,
        marketCap: lastBar.close * (c.listed_shares || 10000000),
      };
    });
  }

  public async getStockBySymbol(symbol: string): Promise<Company | null> {
    const all = await this.getAllStocks();
    return all.find(s => s.symbol.toUpperCase() === symbol.toUpperCase()) || null;
  }

  public async getHistoricalBars(symbol: string): Promise<OHLCVBar[]> {
    const cached = getCachedBars(symbol);
    if (cached && cached.length > 0) return cached;
    return getNormalizedStockBars(symbol);
  }
}

export const stockService = new StockService();
