/**
 * Feature Engine & Probability Laboratory Domain Types (Phase 3C)
 */

import { HoldingHorizon } from './historicalResearch';

export type FeatureCategory =
  | 'TREND'
  | 'MOMENTUM'
  | 'VOLATILITY'
  | 'VOLUME'
  | 'PRICE_STRUCTURE'
  | 'MOVING_AVERAGES'
  | 'OSCILLATORS'
  | 'SUPPORT_RESISTANCE'
  | 'MARKET_BREADTH'
  | 'QUANTITATIVE'
  | 'CANDLESTICK'
  | 'CHART_PATTERNS';

export type OutcomeType = 'WIN_RATE' | 'AVG_RETURN' | 'EXPECTANCY' | 'MAX_DRAWDOWN' | 'SHARPE';

export interface FeatureBin {
  id: string;
  label: string;
  min: number;
  max: number;
  inclusiveMin: boolean;
  inclusiveMax: boolean;
  description?: string;
}

export interface FeatureDefinition {
  featureId: string;
  name: string;
  category: FeatureCategory;
  sourceIndicator: string;
  description: string;
  formulaDescription: string;
  normalizationMethod: string;
  parameters: Record<string, any>;
  defaultBins: FeatureBin[];
  calculationVersion: string;
}

export interface FeatureCondition {
  featureId: string;
  binId?: string;
  operator?: '>' | '<' | '>=' | '<=' | '==' | 'between';
  minValue?: number;
  maxValue?: number;
  threshold?: number;
}

export interface ConditionTree {
  operator: 'AND' | 'OR';
  conditions: (FeatureCondition | ConditionTree)[];
}

export interface FeatureRedundancyPair {
  featureAId: string;
  featureAName: string;
  featureBId: string;
  featureBName: string;
  pearsonCorrelation: number;
  spearmanCorrelation: number;
  isRedundant: boolean;
  recommendedAction: string;
}

export interface FeaturePerformanceMetrics {
  featureId: string;
  featureName: string;
  category: FeatureCategory;
  informationCoefficient: number;
  spearmanRankIC: number;
  pValue: number;
  fdrAdjustedPValue: number;
  isStatisticallySignificant: boolean;
  horizon: HoldingHorizon;
  winRateDifferential: number;
  cohensD: number;
  sampleCount: number;
}

export interface FeatureStabilityMetrics {
  featureId: string;
  bullRegimeWinRate: number;
  bearRegimeWinRate: number;
  sidewaysRegimeWinRate: number;
  regimeStabilityScore: number; // 0 - 100
  walkForwardDegradationPct: number;
  isRobust: boolean;
}

export interface ConditionalProbabilityQuery {
  conditions: FeatureCondition[];
  horizon: HoldingHorizon;
  symbolUniverse?: string[];
  regimeFilter?: string;
}

export interface ConditionalProbabilityResult {
  query: ConditionalProbabilityQuery;
  totalMatches: number;
  baseRateWinRate: number;
  conditionalWinRate: number;
  winRateLift: number;
  wilsonConfidenceInterval: {
    lower: number;
    upper: number;
    center: number;
  };
  bayesianSmoothedWinRate: number;
  averageReturn: number;
  medianReturn: number;
  expectancy: number;
  profitFactor: number;
  sampleSizeWarning: boolean;
}

export interface CurrentConditionComparison {
  featureId: string;
  featureName: string;
  currentValue: number;
  currentBinLabel: string;
  historicalConditionalWinRate: number;
  isAligned: boolean;
}

export interface FeatureSelectionReportItem {
  featureId: string;
  featureName: string;
  category: FeatureCategory;
  compositeScore: number;
  rank: number;
  selected: boolean;
  rationale: string;
}

export type FeatureSelectionCriterion =
  | 'INFORMATION_COEFFICIENT'
  | 'WIN_RATE_LIFT'
  | 'EFFECT_SIZE'
  | 'REGIME_STABILITY'
  | 'MINIMAL_CORRELATION';

export interface ProbabilityCalibrationBucket {
  predictedProbabilityRange: [number, number];
  predictedMidpoint: number;
  actualObservedFrequency: number;
  sampleCount: number;
}
