/**
 * Research Validation & Data Quality Domain Types (Phase 3D)
 */

export type ValidityStatus = 'PASS' | 'WARN' | 'FAIL' | 'BLOCKED';

export type EvidenceGrade = 'A' | 'B' | 'C' | 'D' | 'F';

export type PriceMode = 'RAW' | 'ADJUSTED';

export type UniverseMode = 'SURVIVOR_FREE' | 'ACTIVE_ONLY' | 'ALL_HISTORICAL';

export interface ExecutionRealityConfig {
  entryPriceModel: 'CLOSE' | 'NEXT_OPEN' | 'VWAP' | 'WORST_CASE';
  slippageModel: 'ZERO' | 'FIXED' | 'LIQUIDITY_BASED';
  fixedSlippagePct: number;
  marketImpactFactor: number;
  brokerageFeePct: number;
  sebonFeePct: number;
  dpFeeNpr: number;
  capitalGainsTaxPct: number;
  maxParticipationRatePct: number; // e.g. 5% of daily volume
  allowPartialFill: boolean;
  rejectCircuitBars: boolean;
}

export interface LiquidityFilterConfig {
  minTurnoverDailyNPR: number;
  minTradedDaysPct: number;
  maxZeroVolumeDaysPct: number;
  maxSpreadPct?: number;
}

export interface DataQualityReport {
  symbol: string;
  totalBars: number;
  startDate: string;
  endDate: string;
  missingDaysCount: number;
  suspensionDaysCount: number;
  abnormalSpikesCount: number;
  zeroVolumeDaysCount: number;
  overallScore: number;
  grade: EvidenceGrade;
  status: ValidityStatus;
  issues: string[];
}

export interface CorporateActionDiagnostic {
  symbol: string;
  exDate: string;
  actionType: 'BONUS' | 'RIGHTS' | 'CASH_DIVIDEND' | 'STOCK_SPLIT' | 'MERGER';
  ratio: string;
  priceDropPct: number;
  isAdjusted: boolean;
  discontinuityDetected: boolean;
}

export interface RobustnessTestSummary {
  grade: EvidenceGrade;
  validityStatus: ValidityStatus;
  perturbationStabilityScore: number; // 0-100
  regimeConsistencyScore: number; // 0-100
  resamplingPValue: number;
  walkForwardEfficiency: number; // 0-100
  survivorshipBiasRisk: 'LOW' | 'MODERATE' | 'HIGH';
  liquidityConstraintPenalty: number;
  executionDragPct: number;
}
