/**
 * Historical Research and Backtesting Domain Types
 */

import { OHLCVBar, Timeframe } from './technicalIndicators';

export type HoldingHorizon = 1 | 3 | 5 | 10 | 20 | 30 | 60;

export type MarketRegimeType =
  | 'BULL'
  | 'BEAR'
  | 'SIDEWAYS'
  | 'HIGH_VOLATILITY'
  | 'LOW_VOLATILITY';

export type SampleSizeTier = 'VERY_SMALL' | 'SMALL' | 'MODERATE' | 'LARGE' | 'ROBUST';

export interface WilsonConfidenceInterval {
  lower: number;
  upper: number;
  center: number;
}

export interface TransactionCostModel {
  includeCosts: boolean;
  slippagePercent: number;
  brokeragePercent: number;
  sebonFeePercent: number;
  dpFeeNPR: number;
  capitalGainsTaxPercent: number;
}

export interface TargetStopParams {
  targetPercent: number;
  stopLossPercent: number;
  maxHoldBars?: number;
}

export interface ConditionNode {
  id: string;
  field: string;
  operator: '>' | '<' | '>=' | '<=' | '==' | '!=' | 'crosses_above' | 'crosses_below';
  value: number | string;
  secondaryField?: string;
}

export interface ConditionTree {
  operator: 'AND' | 'OR';
  conditions: (ConditionNode | ConditionTree)[];
}

export interface ResearchRunConfig {
  id?: string;
  name: string;
  symbols: string[];
  timeframe: Timeframe;
  conditionTree: ConditionTree;
  entryModel: 'CLOSE' | 'NEXT_OPEN' | 'BREAKOUT';
  horizons: HoldingHorizon[];
  costs: TransactionCostModel;
  targetStop?: TargetStopParams;
  startDate?: string;
  endDate?: string;
  trainEndDate?: string; // For out-of-sample split
  isOutOfSample?: boolean;
}

export interface ForwardReturnOutcome {
  horizon: HoldingHorizon;
  exitPrice: number;
  rawReturn: number;
  netReturn: number;
  profitable: boolean;
}

export interface ResearchObservation {
  id: string;
  symbol: string;
  companyId: string;
  timestamp: string;
  barIndex: number;
  timeframe: Timeframe;
  close: number;
  volume: number;
  marketRegime: MarketRegimeType;
  entryPrice?: number;
  forwardOutcomes?: Record<HoldingHorizon, ForwardReturnOutcome>;
  mfe?: Record<HoldingHorizon, number>;
  mae?: Record<HoldingHorizon, number>;
  targetStopResult?: {
    hitTarget: boolean;
    hitStop: boolean;
    exitBarIndex: number;
    exitPrice: number;
    netReturn: number;
  };
}

export interface HorizonMetrics {
  horizon: HoldingHorizon;
  sampleSize: number;
  winRate: number;
  wilsonInterval: WilsonConfidenceInterval;
  avgReturn: number;
  medianReturn: number;
  profitFactor: number;
  maxDrawdown: number;
  expectancy: number;
  sharpeRatio: number;
}

export interface ResearchResult {
  id: string;
  config: ResearchRunConfig;
  status: 'COMPLETED' | 'RUNNING' | 'FAILED';
  executedAt: string;
  totalObservations: number;
  observations: ResearchObservation[];
  sampleSizeTier: SampleSizeTier;
  horizonMetrics: Record<HoldingHorizon, HorizonMetrics>;
  regimeBreakdown: Record<MarketRegimeType, {
    count: number;
    winRate: number;
    avgReturn: number;
  }>;
  overallScore: number;
  robustnessGrade: 'A' | 'B' | 'C' | 'D' | 'F';
}

export interface ParameterSweepResult {
  parameterName: string;
  parameterValues: any[];
  results: {
    paramValue: any;
    winRate: number;
    avgReturn: number;
    sampleSize: number;
    expectancy: number;
  }[];
}
