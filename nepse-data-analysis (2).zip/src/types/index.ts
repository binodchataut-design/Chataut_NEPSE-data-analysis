/**
 * Central Type Definitions for NEPSE Platform
 */

export type DataSourceMode = 'MOCK_DATA' | 'SUPABASE' | 'LIVE' | 'REAL_DATA';

export interface MarketIndex {
  symbol: string;
  name: string;
  currentValue: number;
  change: number;
  changePercent: number;
  high?: number;
  low?: number;
  turnover?: number;
  timestamp?: string;
}

export interface Sector {
  id: string;
  name: string;
  indexSymbol: string;
  changePercent: number;
  turnover: number;
  advanceDeclineRatio?: number;
  peRatio?: number;
}

export interface MarketBreadth {
  advances: number;
  declines: number;
  unchanged: number;
  totalTradedShares: number;
  totalTurnover: number;
  totalTransactions: number;
  adRatio?: number;
}

export type SetupType =
  | 'BREAKOUT'
  | 'PULLBACK'
  | 'ACCUMULATION'
  | 'REVERSAL'
  | 'MOMENTUM'
  | 'VALUE'
  | 'VOLUME_PUMP'
  | string;

export interface SetupDetection {
  id: string;
  symbol: string;
  companyName: string;
  setupType: SetupType;
  qualityScore: number;
  bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  triggerPrice: number;
  stopLoss: number;
  target1: number;
  target2?: number;
  riskRewardRatio: number;
  timeframe: string;
  detectedDate: string;
  indicators: string[];
}

export interface RiskAlert {
  id: string;
  symbol: string;
  type: 'VOLATILITY' | 'DRAWDOWN' | 'LIQUIDITY' | 'CIRCUIT' | 'REGULATORY' | 'CONCENTRATION';
  severity: 'HIGH' | 'MEDIUM' | 'LOW';
  message: string;
  timestamp: string;
  actionRecommended?: string;
}

export interface WatchlistItem {
  symbol: string;
  companyName: string;
  sector: string;
  ltp: number;
  changePercent: number;
  volume: number;
  alertTriggered?: boolean;
  notes?: string;
}

export interface PortfolioPosition {
  symbol: string;
  companyName: string;
  quantity: number;
  buyPrice: number;
  currentPrice: number;
  investedAmount: number;
  currentValue: number;
  pnl: number;
  pnlPercent: number;
  sector: string;
  weightPercent?: number;
}

export interface PortfolioSummary {
  totalInvested: number;
  totalValue: number;
  totalPnl: number;
  totalPnlPercent: number;
  dailyPnl: number;
  dailyPnlPercent: number;
  cashBalance: number;
  stockCount: number;
}

export interface BrokerActivity {
  brokerCode: string;
  brokerName: string;
  buyAmount: number;
  sellAmount: number;
  netAmount: number;
  topBoughtSymbols: string[];
  topSoldSymbols: string[];
}

export interface StockBrokerConcentration {
  symbol: string;
  top5BrokersShare: number;
  top10BrokersShare: number;
  dominantBroker: string;
  dominantAction: 'ACCUMULATION' | 'DISTRIBUTION' | 'NEUTRAL';
  netInstitutionalFlow: number;
}

export interface Company {
  symbol: string;
  company_name: string;
  sector: string;
  ltp: number;
  change: number;
  changePercent: number;
  volume: number;
  peRatio?: number;
  marketCap?: number;
  high52?: number;
  low52?: number;
}

export interface FundamentalMetrics {
  symbol: string;
  peRatio: number;
  pbRatio: number;
  roe: number;
  roa: number;
  eps: number;
  bookValue: number;
  dividendYield: number;
  debtToEquity: number;
  netProfitMargin: number;
}

export interface FundamentalScoreBreakdown {
  compositeScore: number;
  valuationScore: number;
  profitabilityScore: number;
  solvencyScore: number;
  growthScore: number;
  classification: string;
}

export interface SystemSettings {
  dataSourceMode: DataSourceMode;
  autoRefresh: boolean;
  refreshIntervalSec: number;
  theme: 'dark' | 'light';
  maxHistoricalBars: number;
}

export interface ScoringWeights {
  technical: number;
  fundamental: number;
  market?: number;
  broker?: number;
  risk?: number;
  momentum?: number;
  liquidity?: number;
  brokerFlow?: number;
}
