/**
 * Current State Engine Domain Models (Phase 4A)
 */

import { OHLCVBar } from './technicalIndicators';
import { DataSourceMode } from './index';

export type StateDataQualityGrade = 'EXCELLENT' | 'GOOD' | 'FAIR' | 'POOR' | 'UNUSABLE';

export type TrendState =
  | 'STRONG_UPTREND'
  | 'UPTREND'
  | 'NEUTRAL'
  | 'DOWNTREND'
  | 'STRONG_DOWNTREND';

export type MomentumState =
  | 'OVERBOUGHT'
  | 'BULLISH'
  | 'NEUTRAL'
  | 'BEARISH'
  | 'OVERSOLD';

export type MomentumLevel = 'HIGH' | 'MODERATE' | 'LOW';
export type MomentumDirection = 'EXPANDING' | 'CONTRACTING' | 'STABLE';

export type VolumeTurnoverState =
  | 'VERY_HIGH'
  | 'ABOVE_AVERAGE'
  | 'AVERAGE'
  | 'BELOW_AVERAGE'
  | 'VERY_LOW';

export type VolumePriceRelationship =
  | 'VOLUME_CONFIRMED_UP'
  | 'VOLUME_CONFIRMED_DOWN'
  | 'DIVERGENT_UP'
  | 'DIVERGENT_DOWN'
  | 'NEUTRAL';

export type StockVolatilityState =
  | 'HIGH_VOLATILITY'
  | 'MODERATE_VOLATILITY'
  | 'LOW_VOLATILITY'
  | 'SQUEEZE';

export type VolatilityTransition =
  | 'EXPANDING'
  | 'COMPRESSING'
  | 'STABLE';

export type RelativeStrengthState =
  | 'OUTPERFORMING'
  | 'IN_LINE'
  | 'UNDERPERFORMING';

export type PriceStructureState =
  | 'HIGHER_HIGHS'
  | 'LOWER_LOWS'
  | 'CONSOLIDATING'
  | 'BREAKOUT'
  | 'BREAKDOWN';

export interface SupportResistanceContext {
  nearestSupport: number;
  nearestResistance: number;
  distanceToSupportPct: number;
  distanceToResistancePct: number;
  testedSupportCount: number;
  testedResistanceCount: number;
}

export interface CrossSectionalRank {
  momentumRank: number;
  volumeRank: number;
  rsRank: number;
  totalUniverse: number;
}

export interface StockPriceMetrics {
  open: number;
  high: number;
  low: number;
  close: number;
  previousClose: number;
  change: number;
  changePercent: number;
  volume: number;
  turnover?: number;
  transactions?: number;
}

export interface StockReturnMetrics {
  return1d: number;
  return5d: number;
  return20d: number;
  return60d: number;
  return120d?: number;
}

export interface StockTrendMetrics {
  state: TrendState;
  sma20?: number;
  sma50?: number;
  sma200?: number;
  ema20?: number;
  structure: {
    aboveSMA20?: boolean;
    aboveSMA50?: boolean;
    aboveSMA200?: boolean;
    sma20AboveSMA50?: boolean;
    goldenCross?: boolean;
    deathCross?: boolean;
  };
}

export interface StockMomentumMetrics {
  state: MomentumState;
  level: MomentumLevel;
  direction: MomentumDirection;
  rsi14?: number;
  macd?: {
    macdLine: number;
    signalLine: number;
    histogram: number;
  };
  stochasticK?: number;
  stochasticD?: number;
}

export interface StockVolumeMetrics {
  state: VolumeTurnoverState;
  relationship: VolumePriceRelationship;
  volume20Avg: number;
  relativeVolume: number; // current / 20avg
  turnover: number;
  turnover20Avg?: number;
}

export interface StockVolatilityMetrics {
  state: StockVolatilityState;
  transition: VolatilityTransition;
  atr14: number;
  atrPercent: number;
  bollingerBandWidth?: number;
}

export interface CurrentStockState {
  symbol: string;
  companyName: string;
  sectorId: string;
  sectorName: string;
  asOfDate: string;
  price: StockPriceMetrics;
  returns: StockReturnMetrics;
  trend: StockTrendMetrics;
  momentum: StockMomentumMetrics;
  volume: StockVolumeMetrics;
  volatility: StockVolatilityMetrics;
  relativeStrengthMarket: RelativeStrengthState;
  relativeStrengthSector: RelativeStrengthState;
  priceStructure: {
    state: PriceStructureState;
    description: string;
  };
  supportResistance: SupportResistanceContext;
  crossSectionalRank: CrossSectionalRank;
  liquidity: {
    adt20: number;
    adt60?: number;
    tradedDayRatio?: number;
    zeroVolumeRatio?: number;
    liquidityPercentile?: number;
    tier?: 'HIGH' | 'MEDIUM' | 'LOW' | 'ILLIQUID';
  };
  liquidityTier: 'HIGH' | 'MEDIUM' | 'LOW' | 'ILLIQUID';
  lifecycleStatus: 'NORMAL' | 'NEWLY_LISTED' | 'PROMOTER' | 'SUSPENDED';
  corporateActionNotice?: string | null;
  dataQualityGrade: StateDataQualityGrade;
  warnings: string[];
}

export interface CurrentMarketState {
  asOfDate: string;
  regime: 'BULLISH' | 'BEARISH' | 'RANGING' | 'VOLATILE' | 'TRANSITIONAL';
  nepseClose: number;
  nepseChange: number;
  nepseChangePercent: number;
  marketTurnover: number;
  marketTurnover20Avg: number;
  breadth: {
    advances: number;
    declines: number;
    unchanged: number;
    adRatio: number;
  };
  sectorDispersion: number;
  warnings: string[];
}

export interface CurrentSectorState {
  sectorId: string;
  sectorName: string;
  asOfDate: string;
  indexValue: number;
  changePercent: number;
  turnover: number;
  turnoverSharePercent: number;
  relativeStrengthMarket: RelativeStrengthState;
  trend: TrendState;
  breadth: {
    advances: number;
    declines: number;
  };
  warnings: string[];
}

export interface StateTransition {
  id: string;
  layer: 'MARKET' | 'SECTOR' | 'STOCK';
  property: string;
  previousValue: string;
  currentValue: string;
  sessionDate: string;
  significance: 'HIGH' | 'MEDIUM' | 'LOW';
  description: string;
}

export interface CurrentStateSnapshot {
  symbol: string;
  asOfDate: string;
  mode: 'LATEST' | 'HISTORICAL_SNAPSHOT';
  marketState: CurrentMarketState;
  sectorState: CurrentSectorState;
  stockState: CurrentStockState;
  stateTransitions: StateTransition[];
  calculationVersions: {
    stateEngineVersion: string;
    indicatorVersion: string;
    featureVersion: string;
    marketRegimeVersion: string;
    datasetVersion: string;
  };
  causalityAudit: {
    cutoffDate: string;
    futureDataIncluded: boolean;
    zeroLookaheadVerified: boolean;
    auditMessage: string;
  };
  warnings: string[];
  limitations: string[];
  stateAvailability: {
    isAvailable: boolean;
    status: 'AVAILABLE' | 'UNAVAILABLE';
    dataSourceMode: DataSourceMode;
    reason?: string;
  };
}

export interface CurrentMarketAndStockSnapshot {
  symbol: string;
  asOfDate: string;
  marketState: CurrentMarketState;
  stockState: CurrentStockState;
  sectorState?: CurrentSectorState;
}
