/**
 * Decision Intelligence Domain Types (Phase 4B)
 */

import { EvidenceGrade } from './researchValidation';
import { MarketRegimeType } from './historicalResearch';

export type EvidenceLayer = 'MARKET' | 'SECTOR' | 'STOCK';
export type EvidenceDirection = 'BULLISH' | 'BEARISH' | 'NEUTRAL';
export type EvidenceStrength = 'STRONG' | 'MODERATE' | 'WEAK';

export interface EvidenceItem {
  id: string;
  layer: EvidenceLayer;
  category: string;
  name: string;
  direction: EvidenceDirection;
  strength: EvidenceStrength;
  rawScore: number; // -1.0 to 1.0
  normalizedWeight: number; // 0.0 to 1.0
  reliabilityMultiplier: number;
  effectiveScore: number; // rawScore * normalizedWeight * reliabilityMultiplier
  description: string;
  historicalSampleSize?: number;
  statisticalPValue?: number;
  confidenceGrade?: EvidenceGrade;
  regimeSensitivity?: string;
  metricValue?: number | string;
  thresholdUsed?: string;
}

export interface EvidenceAlignmentResult {
  overallAlignment: 'STRONGLY_BULLISH' | 'BULLISH' | 'MIXED' | 'BEARISH' | 'STRONGLY_BEARISH';
  alignmentScore: number; // 0 to 1
  netDirectionalScore: number; // -1 to +1
  layerBreakdown: {
    market: { bullishCount: number; bearishCount: number; netScore: number };
    sector: { bullishCount: number; bearishCount: number; netScore: number };
    stock: { bullishCount: number; bearishCount: number; netScore: number };
  };
  dominantFactors: string[];
}

export interface EvidenceConflict {
  id: string;
  factorA: string;
  factorB: string;
  severity: 'CRITICAL' | 'MAJOR' | 'MODERATE' | 'MINOR';
  description: string;
  resolutionHint: string;
}

export interface EvidenceConflictSummary {
  hasCriticalConflict: boolean;
  conflictCount: number;
  conflicts: EvidenceConflict[];
}

export interface HistoricalComparableCondition {
  symbol: string;
  date: string;
  similarityScore: number;
  regime: MarketRegimeType;
  forwardReturns: Record<number, number>; // horizon -> return %
  mfe?: Record<number, number>;
  mae?: Record<number, number>;
}

export interface HorizonProbabilityDistribution {
  horizon: number; // 1, 3, 5, 10, 20, 30, 60
  observations: number;
  pPositive: number; // win rate %
  wilsonInterval: {
    lower: number;
    upper: number;
  };
  avgReturn: number;
  medianReturn: number;
  expectedValue: number;
  expectancy: number;
  sharpeRatio: number;
  sampleTier: string;
}

export interface DecisionProbabilityResult {
  distributions: Record<number, HorizonProbabilityDistribution>;
  primaryHorizon: number;
  overallSampleTier: string;
  regimeConditioned: boolean;
}

export interface RiskRewardParameters {
  currentPrice: number;
  recommendedEntryZone: {
    low: number;
    high: number;
  };
  suggestedStopLoss: number;
  stopDistancePercent: number;
  target1: number;
  target1Percent: number;
  target2: number;
  target2Percent: number;
  riskRewardRatio: number;
  estimatedSlippagePercent: number;
  estimatedBrokerageRoundTripPercent: number;
  estimatedNetExpectancyPercent: number;
  liquidityAbsorptionScore: number;
}

export interface DecisionEligibilityResult {
  isEligible: boolean;
  hasHardBlocker: boolean;
  eligibilityStatus: 'ELIGIBLE' | 'CONDITIONAL' | 'BLOCKED';
  hardBlockers: string[];
  warnings: string[];
  confidenceScore: number;
}

export interface DecisionExplanation {
  primaryDrivers: string[];
  headwinds: string[];
  probabilisticOutlook: string;
  riskSummary: string;
  keyAssumptions: string[];
  plainLanguageSummary: string;
}

export interface DecisionAssessment {
  id: string;
  symbol: string;
  companyName: string;
  sectorName: string;
  asOfDate: string;
  dataSource: string;
  engineVersion: string;
  probabilityEngineVersion: string;
  calculationTimestamp: string;
  evidenceItems: EvidenceItem[];
  alignment: EvidenceAlignmentResult;
  conflicts: EvidenceConflictSummary;
  probability: DecisionProbabilityResult;
  comparables: HistoricalComparableCondition[];
  eligibility: DecisionEligibilityResult;
  riskReward: RiskRewardParameters;
  explanation: DecisionExplanation;
  researchEvidenceGrade: EvidenceGrade;
  researchGradeExplanation: string;
  audit: {
    inputSnapshotHash: string;
    dataProvenance: string;
    totalObservationsMatched: number;
    isPointInTimeGuaranteed: boolean;
    engineVersion: string;
    probabilityEngineVersion: string;
    calculationTimestamp: string;
  };
}

export interface MarketWideEvidenceRankingItem {
  symbol: string;
  companyName: string;
  sector: string;
  compositeScore: number;
  evidenceAlignment: string;
  alignmentScore: number;
  historicalSupportObservations: number;
  researchGrade: EvidenceGrade;
  fiveDayProb: number;
  fiveDayWilsonCI: { lower: number; upper: number };
  twentyDayProb: number;
  twentyDayWilsonCI: { lower: number; upper: number };
  riskLevel: 'LOW' | 'MODERATE' | 'HIGH' | 'EXTREME';
  eligibilityStatus: 'ELIGIBLE' | 'CONDITIONAL' | 'BLOCKED';
  hardBlockersCount: number;
  conflictCount: number;
  actionHint: string;
}

export type DecisionIntelligenceEventType =
  | 'ASSESSMENT_COMPLETED'
  | 'CRITICAL_CONFLICT_DETECTED'
  | 'HARD_BLOCKER_TRIGGERED'
  | 'PROBABILITY_UPDATED';

export interface DecisionIntelligenceEvent {
  type: DecisionIntelligenceEventType;
  symbol: string;
  timestamp: string;
  payload: any;
}
