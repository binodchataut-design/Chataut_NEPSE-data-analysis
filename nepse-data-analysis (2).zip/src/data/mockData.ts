/**
 * Default System Settings and Mock Baseline Datasets
 */

import { SystemSettings, WatchlistItem, PortfolioPosition, RiskAlert, SetupDetection } from '../types';

export const defaultSystemSettings: SystemSettings = {
  dataSourceMode: 'MOCK_DATA',
  autoRefresh: false,
  refreshIntervalSec: 60,
  theme: 'dark',
  maxHistoricalBars: 250,
};

export const mockWatchlist: WatchlistItem[] = [
  { symbol: 'CHCL', companyName: 'Chilime Hydropower Company Ltd.', sector: 'Hydropower', ltp: 520, changePercent: 1.85, volume: 85200 },
  { symbol: 'NABIL', companyName: 'Nabil Bank Limited', sector: 'Commercial Banks', ltp: 615, changePercent: 0.95, volume: 142000 },
  { symbol: 'NICA', companyName: 'NIC Asia Bank Limited', sector: 'Commercial Banks', ltp: 480, changePercent: -0.40, volume: 98000 },
  { symbol: 'AKPL', companyName: 'Arun Kabeli Power Limited', sector: 'Hydropower', ltp: 245, changePercent: 2.10, volume: 112000 },
  { symbol: 'SHIVM', companyName: 'Shivam Cements Limited', sector: 'Manufacturing & Processing', ltp: 590, changePercent: 3.45, volume: 64000 },
];

export const mockPortfolioPositions: PortfolioPosition[] = [
  {
    symbol: 'CHCL',
    companyName: 'Chilime Hydropower Co. Ltd.',
    quantity: 500,
    buyPrice: 480,
    currentPrice: 520,
    investedAmount: 240000,
    currentValue: 260000,
    pnl: 20000,
    pnlPercent: 8.33,
    sector: 'Hydropower',
    weightPercent: 35.0,
  },
  {
    symbol: 'NABIL',
    companyName: 'Nabil Bank Limited',
    quantity: 400,
    buyPrice: 580,
    currentPrice: 615,
    investedAmount: 232000,
    currentValue: 246000,
    pnl: 14000,
    pnlPercent: 6.03,
    sector: 'Commercial Banks',
    weightPercent: 33.1,
  },
  {
    symbol: 'SHIVM',
    companyName: 'Shivam Cements Limited',
    quantity: 400,
    buyPrice: 610,
    currentPrice: 590,
    investedAmount: 244000,
    currentValue: 236000,
    pnl: -8000,
    pnlPercent: -3.28,
    sector: 'Manufacturing & Processing',
    weightPercent: 31.9,
  }
];

export const mockRiskAlerts: RiskAlert[] = [
  {
    id: 'ra-1',
    symbol: 'SHIVM',
    type: 'VOLATILITY',
    severity: 'MEDIUM',
    message: 'Bollinger Band expansion: 14-day volatility expanded by 32% over 3 sessions.',
    timestamp: '2026-08-30 14:15:00',
    actionRecommended: 'Verify stop loss proximity and review liquidity absorption.',
  },
  {
    id: 'ra-2',
    symbol: 'AKPL',
    type: 'LIQUIDITY',
    severity: 'LOW',
    message: 'Turnover ratio elevated relative to 20-day baseline average.',
    timestamp: '2026-08-30 13:45:00',
  }
];

export const mockSetups: SetupDetection[] = [
  {
    id: 'setup-1',
    symbol: 'CHCL',
    companyName: 'Chilime Hydropower Company Ltd.',
    setupType: 'BREAKOUT',
    qualityScore: 84,
    bias: 'BULLISH',
    triggerPrice: 522,
    stopLoss: 498,
    target1: 565,
    target2: 590,
    riskRewardRatio: 1.79,
    timeframe: 'DAILY',
    detectedDate: '2026-08-30',
    indicators: ['SMA 20/50 Golden Cross', 'RSI Bullish Momentum (58)', 'Volume > 1.4x 20-day Average'],
  },
  {
    id: 'setup-2',
    symbol: 'NABIL',
    companyName: 'Nabil Bank Limited',
    setupType: 'PULLBACK',
    qualityScore: 78,
    bias: 'BULLISH',
    triggerPrice: 618,
    stopLoss: 595,
    target1: 655,
    target2: 680,
    riskRewardRatio: 1.61,
    timeframe: 'DAILY',
    detectedDate: '2026-08-30',
    indicators: ['EMA 20 Support Test', 'Stochastic Oversold Bounce', 'Institutional Net Inflow'],
  }
];
