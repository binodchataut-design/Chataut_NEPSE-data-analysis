/**
 * Normalized Master Reference Data for NEPSE Platform
 * Provides standardized, mathematically coherent mock and reference data
 * for all 17 primary test equities, sectors, indices, brokers, and financial statements.
 */

import {
  CompanyMaster,
  SectorMaster,
  MarketIndexRecord,
  DailyMarketStatistics,
  BrokerMaster,
  BrokerTransactionRecord,
  RawFinancialStatement,
} from '../types/dataInfrastructure';
import { OHLCVBar } from '../types/technicalIndicators';

export const normalizedSectors: SectorMaster[] = [
  { id: 'sec-cb', name: 'Commercial Banks', index_symbol: 'BANKING', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'sec-hyd', name: 'Hydropower', index_symbol: 'HYDRO', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'sec-hot', name: 'Hotels & Tourism', index_symbol: 'HOTELS', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'sec-man', name: 'Manufacturing & Processing', index_symbol: 'MANUFACTURING', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'sec-mic', name: 'Microfinance', index_symbol: 'MICROFINANCE', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'sec-nli', name: 'Non-Life Insurance', index_symbol: 'NON_LIFE_INS', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'sec-li', name: 'Life Insurance', index_symbol: 'LIFE_INS', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'sec-fin', name: 'Finance', index_symbol: 'FINANCE', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'sec-inv', name: 'Investment', index_symbol: 'INVESTMENT', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'sec-oth', name: 'Others', index_symbol: 'OTHERS', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
];

export const normalizedCompanies: CompanyMaster[] = [
  {
    id: 'cmp-chcl',
    symbol: 'CHCL',
    company_name: 'Chilime Hydropower Company Ltd.',
    sector_id: 'sec-hyd',
    sector: 'Hydropower',
    security_type: 'EQ',
    listed_date: '2005-04-12',
    listed_shares: 79843210,
    paid_up_capital: 7984321000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-nabil',
    symbol: 'NABIL',
    company_name: 'Nabil Bank Limited',
    sector_id: 'sec-cb',
    sector: 'Commercial Banks',
    security_type: 'EQ',
    listed_date: '1984-07-12',
    listed_shares: 270569970,
    paid_up_capital: 27056997000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-nica',
    symbol: 'NICA',
    company_name: 'NIC Asia Bank Limited',
    sector_id: 'sec-cb',
    sector: 'Commercial Banks',
    security_type: 'EQ',
    listed_date: '1998-07-21',
    listed_shares: 149175660,
    paid_up_capital: 14917566000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-akpl',
    symbol: 'AKPL',
    company_name: 'Arun Kabeli Power Limited',
    sector_id: 'sec-hyd',
    sector: 'Hydropower',
    security_type: 'EQ',
    listed_date: '2019-11-05',
    listed_shares: 38549100,
    paid_up_capital: 3854910000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-shivm',
    symbol: 'SHIVM',
    company_name: 'Shivam Cements Limited',
    sector_id: 'sec-man',
    sector: 'Manufacturing & Processing',
    security_type: 'EQ',
    listed_date: '2019-03-24',
    listed_shares: 50270000,
    paid_up_capital: 5027000000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-hdl',
    symbol: 'HDL',
    company_name: 'Himalayan Distillery Limited',
    sector_id: 'sec-man',
    sector: 'Manufacturing & Processing',
    security_type: 'EQ',
    listed_date: '2001-02-18',
    listed_shares: 26734000,
    paid_up_capital: 2673400000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-gbime',
    symbol: 'GBIME',
    company_name: 'Global IME Bank Limited',
    sector_id: 'sec-cb',
    sector: 'Commercial Banks',
    security_type: 'EQ',
    listed_date: '2007-01-08',
    listed_shares: 361287000,
    paid_up_capital: 36128700000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-nmb',
    symbol: 'NMB',
    company_name: 'NMB Bank Limited',
    sector_id: 'sec-cb',
    sector: 'Commercial Banks',
    security_type: 'EQ',
    listed_date: '2008-06-05',
    listed_shares: 183667000,
    paid_up_capital: 18366700000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-pcbl',
    symbol: 'PCBL',
    company_name: 'Prime Commercial Bank Ltd.',
    sector_id: 'sec-cb',
    sector: 'Commercial Banks',
    security_type: 'EQ',
    listed_date: '2007-10-15',
    listed_shares: 194025000,
    paid_up_capital: 19402500000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-cit',
    symbol: 'CIT',
    company_name: 'Citizen Investment Trust',
    sector_id: 'sec-inv',
    sector: 'Investment',
    security_type: 'EQ',
    listed_date: '1992-03-18',
    listed_shares: 53137500,
    paid_up_capital: 5313750000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-ebl',
    symbol: 'EBL',
    company_name: 'Everest Bank Limited',
    sector_id: 'sec-cb',
    sector: 'Commercial Banks',
    security_type: 'EQ',
    listed_date: '1994-10-18',
    listed_shares: 117849000,
    paid_up_capital: 11784900000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-scb',
    symbol: 'SCB',
    company_name: 'Standard Chartered Bank Nepal Ltd.',
    sector_id: 'sec-cb',
    sector: 'Commercial Banks',
    security_type: 'EQ',
    listed_date: '1987-02-28',
    listed_shares: 94294000,
    paid_up_capital: 9429400000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-adbl',
    symbol: 'ADBL',
    company_name: 'Agricultural Development Bank Ltd.',
    sector_id: 'sec-cb',
    sector: 'Commercial Banks',
    security_type: 'EQ',
    listed_date: '2010-03-09',
    listed_shares: 188842000,
    paid_up_capital: 18884200000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-kbl',
    symbol: 'KBL',
    company_name: 'Kumari Bank Limited',
    sector_id: 'sec-cb',
    sector: 'Commercial Banks',
    security_type: 'EQ',
    listed_date: '2001-04-03',
    listed_shares: 262258000,
    paid_up_capital: 26225800000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-prvu',
    symbol: 'PRVU',
    company_name: 'Prabhu Bank Limited',
    sector_id: 'sec-cb',
    sector: 'Commercial Banks',
    security_type: 'EQ',
    listed_date: '2016-02-12',
    listed_shares: 235492000,
    paid_up_capital: 23549200000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-shpc',
    symbol: 'SHPC',
    company_name: 'Sanima Mai Hydropower Ltd.',
    sector_id: 'sec-hyd',
    sector: 'Hydropower',
    security_type: 'EQ',
    listed_date: '2015-08-20',
    listed_shares: 30892000,
    paid_up_capital: 3089200000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  },
  {
    id: 'cmp-uppr',
    symbol: 'UPPR',
    company_name: 'Upper Tamakoshi Hydropower Ltd.',
    sector_id: 'sec-hyd',
    sector: 'Hydropower',
    security_type: 'EQ',
    listed_date: '2018-12-14',
    listed_shares: 211800000,
    paid_up_capital: 21180000000,
    face_value: 100,
    status: 'ACTIVE',
    created_at: '2020-01-01',
    updated_at: '2026-08-30',
  }
];

export const normalizedIndices: MarketIndexRecord[] = [
  {
    id: 'idx-nepse-today',
    index_id: 'NEPSE',
    name: 'NEPSE Index',
    date: '2026-08-30',
    open: 2680.15,
    high: 2715.40,
    low: 2674.20,
    close: 2704.85,
    change: 24.70,
    change_percent: 0.92,
    turnover: 6850000000,
    volume: 17500000,
    created_at: '2026-08-30T15:00:00Z',
  },
  {
    id: 'idx-sensitive-today',
    index_id: 'SENSITIVE',
    name: 'Sensitive Index',
    date: '2026-08-30',
    open: 480.10,
    high: 486.20,
    low: 479.50,
    close: 484.60,
    change: 4.50,
    change_percent: 0.94,
    turnover: 3200000000,
    volume: 8500000,
    created_at: '2026-08-30T15:00:00Z',
  },
  {
    id: 'idx-float-today',
    index_id: 'FLOAT',
    name: 'Float Index',
    date: '2026-08-30',
    open: 184.20,
    high: 187.10,
    low: 183.90,
    close: 186.30,
    change: 2.10,
    change_percent: 1.14,
    turnover: 4100000000,
    volume: 11000000,
    created_at: '2026-08-30T15:00:00Z',
  },
  {
    id: 'idx-banking-today',
    index_id: 'BANKING',
    name: 'Banking Sub-Index',
    date: '2026-08-30',
    open: 1540.20,
    high: 1565.80,
    low: 1538.10,
    close: 1558.40,
    change: 18.20,
    change_percent: 1.18,
    turnover: 2150000000,
    volume: 6200000,
    created_at: '2026-08-30T15:00:00Z',
  },
  {
    id: 'idx-hydro-today',
    index_id: 'HYDRO',
    name: 'Hydropower Sub-Index',
    date: '2026-08-30',
    open: 3120.50,
    high: 3175.90,
    low: 3110.00,
    close: 3162.10,
    change: 41.60,
    change_percent: 1.33,
    turnover: 2840000000,
    volume: 7800000,
    created_at: '2026-08-30T15:00:00Z',
  }
];

export const normalizedDailyStats: DailyMarketStatistics = {
  id: 'dms-2026-08-30',
  date: '2026-08-30',
  advancers: 168,
  decliners: 64,
  unchanged: 12,
  total_turnover: 6850000000,
  total_volume: 17500000,
  total_transactions: 92450,
  listed_companies: 320,
  traded_companies: 244,
  advance_decline_ratio: 2.62,
  market_breadth: 'BULLISH',
  stocks_above_20ema: 68.5,
  stocks_above_50sma: 61.2,
  stocks_above_200sma: 54.8,
  created_at: '2026-08-30T15:00:00Z',
  hasData: true,
};

export const normalizedBrokers: BrokerMaster[] = [
  { id: 'brk-58', broker_number: 58, broker_name: 'Naasa Securities Co. Ltd.', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'brk-45', broker_number: 45, broker_name: 'Imperial Securities Co. Pvt. Ltd.', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'brk-34', broker_number: 34, broker_name: 'Vision Securities Pvt. Ltd.', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'brk-28', broker_number: 28, broker_name: 'Shrikrishna Securities Ltd.', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'brk-17', broker_number: 17, broker_name: 'ABC Securities Pvt. Ltd.', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'brk-49', broker_number: 49, broker_name: 'Online Securities Ltd.', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
  { id: 'brk-38', broker_number: 38, broker_name: 'Dipshikha Dhitopatra Karobar Co.', status: 'ACTIVE', created_at: '2020-01-01', updated_at: '2026-01-01' },
];

export const normalizedBrokerTransactions: BrokerTransactionRecord[] = [
  {
    id: 'bt-1',
    date: '2026-08-30',
    company_id: 'cmp-chcl',
    symbol: 'CHCL',
    broker_id: 'brk-58',
    broker_number: 58,
    buy_quantity: 45000,
    buy_value: 23400000,
    sell_quantity: 12000,
    sell_value: 6240000,
    net_quantity: 33000,
    net_value: 17160000,
    transaction_count: 145,
    created_at: '2026-08-30T15:00:00Z',
  },
  {
    id: 'bt-2',
    date: '2026-08-30',
    company_id: 'cmp-nabil',
    symbol: 'NABIL',
    broker_id: 'brk-45',
    broker_number: 45,
    buy_quantity: 82000,
    buy_value: 49200000,
    sell_quantity: 28000,
    sell_value: 16800000,
    net_quantity: 54000,
    net_value: 32400000,
    transaction_count: 260,
    created_at: '2026-08-30T15:00:00Z',
  }
];

export const normalizedRawFinancials: RawFinancialStatement[] = [
  {
    id: 'fs-chcl-2080-q4',
    company_id: 'cmp-chcl',
    symbol: 'CHCL',
    fiscal_year: '2080/081',
    quarter: 'Q4',
    revenue: 1245.5,
    operating_profit: 892.4,
    net_profit: 745.2,
    paid_up_capital: 7984.3,
    reserve_and_surplus: 4120.6,
    total_assets: 18450.2,
    total_liabilities: 6345.3,
    equity: 12104.9,
    current_assets: 3120.0,
    current_liabilities: 1420.0,
    cash_and_equivalents: 980.5,
    total_shares: 79.84,
    declared_cash_dividend: 10.0,
    declared_bonus_dividend: 5.0,
    created_at: '2026-08-01T00:00:00Z',
  },
  {
    id: 'fs-nabil-2080-q4',
    company_id: 'cmp-nabil',
    symbol: 'NABIL',
    fiscal_year: '2080/081',
    quarter: 'Q4',
    revenue: 14200.0,
    operating_profit: 9100.0,
    net_profit: 7150.0,
    paid_up_capital: 27056.9,
    reserve_and_surplus: 19850.0,
    total_assets: 412000.0,
    total_liabilities: 365093.1,
    equity: 46906.9,
    current_assets: 48000.0,
    current_liabilities: 41000.0,
    cash_and_equivalents: 24000.0,
    total_shares: 270.57,
    declared_cash_dividend: 12.5,
    declared_bonus_dividend: 10.0,
    created_at: '2026-08-01T00:00:00Z',
  }
];

// Helper to deterministically generate historical OHLCV bars for any symbol
const basePrices: Record<string, number> = {
  CHCL: 520,
  NABIL: 615,
  NICA: 480,
  AKPL: 245,
  SHIVM: 590,
  HDL: 1420,
  GBIME: 215,
  NMB: 230,
  PCBL: 220,
  CIT: 2350,
  EBL: 540,
  SCB: 580,
  ADBL: 290,
  KBL: 185,
  PRVU: 175,
  SHPC: 310,
  UPPR: 225,
};

const cachedBarsBySymbol = new Map<string, OHLCVBar[]>();

export function getNormalizedStockBars(symbol: string): OHLCVBar[] {
  const sym = (symbol || 'CHCL').toUpperCase().trim();
  if (cachedBarsBySymbol.has(sym)) {
    return cachedBarsBySymbol.get(sym)!;
  }

  const basePrice = basePrices[sym] || 350;
  const bars: OHLCVBar[] = [];
  const totalDays = 250; // ~1 trading year

  // Generate deterministic trading dates ending on 2026-08-30
  let curPrice = basePrice * 0.85; // start lower so it has an uptrend
  let seed = sym.split('').reduce((acc, c) => acc + c.charCodeAt(0), 42);

  function pseudoRand(): number {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  }

  const startDate = new Date('2025-08-15');
  let currentDate = new Date(startDate);

  for (let i = 0; i < totalDays; i++) {
    // skip Saturdays (NEPSE operates Sunday-Thursday)
    // In Nepal, Friday and Saturday are closed, Sunday-Thursday are open
    while (currentDate.getDay() === 5 || currentDate.getDay() === 6) {
      currentDate.setDate(currentDate.getDate() + 1);
    }

    const dateStr = currentDate.toISOString().split('T')[0];

    const pctChange = (pseudoRand() - 0.48) * 0.04; // slight upward drift
    const open = Math.round(curPrice * (1 + (pseudoRand() - 0.5) * 0.005) * 10) / 10;
    const close = Math.round(Math.max(10, curPrice * (1 + pctChange)) * 10) / 10;
    const high = Math.round(Math.max(open, close) * (1 + pseudoRand() * 0.015) * 10) / 10;
    const low = Math.round(Math.min(open, close) * (1 - pseudoRand() * 0.015) * 10) / 10;
    const volume = Math.floor(25000 + pseudoRand() * 120000);
    const turnover = Math.round(close * volume);

    bars.push({
      date: dateStr,
      open,
      high,
      low,
      close,
      volume,
      turnover,
    });

    curPrice = close;
    currentDate.setDate(currentDate.getDate() + 1);
  }

  cachedBarsBySymbol.set(sym, bars);
  return bars;
}
