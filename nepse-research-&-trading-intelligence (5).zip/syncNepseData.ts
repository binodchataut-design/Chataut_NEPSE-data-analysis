/**
 * syncNepseData.ts
 *
 * Standalone script — run manually for now (npx tsx syncNepseData.ts), later on a
 * Cloud Scheduler + Cloud Run Job cadence. NOT part of the browser app bundle.
 *
 * Fetches the symbol list + daily OHLCV CSVs from binayabaral/nepal-market-data,
 * keeps only the last 5 years, flags likely corporate actions using the CSV's own
 * per_change column, and upserts everything into Supabase.
 *
 * Requires env vars:
 *   SUPABASE_URL             https://tbeznjlzyinoaorcovis.supabase.co/rest/v1/
 *   SUPABASE_SERVICE_ROLE_KEY - eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
 */

import 'dotenv/config';
import { createClient } from '@supabase/supabase-js';

// Normalize url: Supabase client expects base project URL like https://xyz.supabase.co, but handle /rest/v1/ suffix gracefully if provided
let rawUrl = process.env.SUPABASE_URL || 'https://tbeznjlzyinoaorcovis.supabase.co';
if (rawUrl.endsWith('/rest/v1/')) {
  rawUrl = rawUrl.replace(/\/rest\/v1\/$/, '');
} else if (rawUrl.endsWith('/rest/v1')) {
  rawUrl = rawUrl.replace(/\/rest\/v1$/, '');
}

const SUPABASE_URL = rawUrl;
const SUPABASE_SERVICE_ROLE_KEY =
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRiZXpuamx6eWlub2FvcmNvdmlzIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4OTQ3NDk5MiwiZXhwIjoyMTA1MDUwOTkyfQ.5V6uvI1f3BNieoxnurI3n3mjGvb9r53lC27qCNVlnlo';

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY env vars.');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

const REPO_CONTENTS_URL =
  'https://api.github.com/repos/binayabaral/nepal-market-data/contents/data/nepse';
const RAW_BASE =
  'https://raw.githubusercontent.com/binayabaral/nepal-market-data/main/data/nepse';

const FIVE_YEARS_AGO = new Date();
FIVE_YEARS_AGO.setFullYear(FIVE_YEARS_AGO.getFullYear() - 5);

const CIRCUIT_CHANGE_DATE = '2026-04-20';

function circuitLimitFor(date: string): number {
  return date >= CIRCUIT_CHANGE_DATE ? 15 : 10;
}

interface CsvRow {
  date: string;
  open: number | null;
  high: number | null;
  low: number | null;
  close: number | null;
  volume: number | null;
  perChange: number | null;
}

function parseCsv(text: string): CsvRow[] {
  const lines = text.trim().split('\n');
  if (lines.length < 2) return [];
  const header = lines[0].split(',').map((h) => h.trim().toLowerCase());
  const idx = (name: string) => header.indexOf(name);

  const dateIdx = idx('date') >= 0 ? idx('date') : (idx('published_date') >= 0 ? idx('published_date') : idx('timestamp'));
  const openIdx = idx('open');
  const highIdx = idx('high');
  const lowIdx = idx('low');
  const closeIdx = idx('close');
  const volIdx = idx('volume') >= 0 ? idx('volume') : idx('traded_quantity');
  const perChangeIdx = idx('per_change') >= 0 ? idx('per_change') : idx('%_change');

  const rows: CsvRow[] = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const cols = line.split(',');
    const dateStr = cols[dateIdx]?.trim();
    if (!dateStr) continue;

    const num = (v: string | undefined) => {
      if (v === undefined || v === '') return null;
      const n = Number(v.replace(/,/g, ''));
      return Number.isFinite(n) ? n : null;
    };

    rows.push({
      date: dateStr,
      open: num(cols[openIdx]),
      high: num(cols[highIdx]),
      low: num(cols[lowIdx]),
      close: num(cols[closeIdx]),
      volume: volIdx >= 0 ? num(cols[volIdx]) : null,
      perChange: perChangeIdx >= 0 ? num(cols[perChangeIdx]) : null,
    });
  }
  return rows;
}

function detectCorporateAction(row: CsvRow, prevClose: number | null): boolean {
  const limit = circuitLimitFor(row.date);
  if (prevClose && row.close) {
    const gap = Math.abs(((row.close - prevClose) / prevClose) * 100);
    if (gap > limit + 0.5) return true;
  }
  if (row.perChange !== null) {
    return Math.abs(row.perChange) > limit + 0.5; // buffer for rounding
  }
  return false;
}

async function fetchSymbolList(): Promise<string[]> {
  const res = await fetch(REPO_CONTENTS_URL, {
    headers: { 'User-Agent': 'nepse-sync-script' },
  });
  if (!res.ok) {
    throw new Error(`GitHub Contents API failed: ${res.status} ${res.statusText}`);
  }
  const files: Array<{ name: string }> = await res.json();
  return files
    .map((f) => f.name)
    .filter((name) => name.endsWith('.csv'))
    .filter((name) => name !== 'NEPSE_INDEX.csv')
    .filter((name) => !name.includes('-')) // drop debentures (repo maps "/" -> "-")
    .map((name) => name.replace('.csv', ''))
    .filter((symbol) => /^[A-Z0-9]+$/.test(symbol));
}

async function fetchCsvFor(pathName: string): Promise<CsvRow[] | null> {
  const res = await fetch(`${RAW_BASE}/${pathName}.csv`);
  if (!res.ok) return null;
  const text = await res.text();
  return parseCsv(text);
}

async function batched<T>(items: T[], size: number, fn: (item: T) => Promise<void>) {
  for (let i = 0; i < items.length; i += size) {
    const chunk = items.slice(i, i + size);
    await Promise.all(chunk.map(fn));
    console.log(`  ...processed ${Math.min(i + size, items.length)}/${items.length}`);
  }
}

async function main() {
  const startTime = Date.now();
  let symbolsSynced = 0;
  let rowsUpserted = 0;
  let symbolsFailed = 0;

  console.log('Fetching symbol list from GitHub...');
  const symbols = await fetchSymbolList();
  console.log(`Found ${symbols.length} symbols.`);

  console.log('Syncing market index...');
  const indexRows = await fetchCsvFor('NEPSE_INDEX');
  if (indexRows) {
    const recent = indexRows.filter((r) => new Date(r.date) >= FIVE_YEARS_AGO);
    const upsertRows = recent.map((r) => ({
      date: r.date,
      close: r.close,
      change_percent: r.perChange,
      turnover: r.volume,
    }));
    if (upsertRows.length > 0) {
      let indexErrors = 0;
      for (let i = 0; i < upsertRows.length; i += 500) {
        const slice = upsertRows.slice(i, i + 500);
        const { error } = await supabase.from('market_index').upsert(slice, {
          onConflict: 'date',
        });
        if (error) {
          console.error('market_index upsert error:', error.message);
          indexErrors++;
        }
      }
      if (indexErrors === 0) {
        console.log(`  Upserted ${upsertRows.length} index rows.`);
      }
    }
  } else {
    console.warn('  Could not fetch NEPSE_INDEX.csv — skipping index sync.');
  }

  console.log('Syncing per-symbol price history (5-year window)...');
  await batched(symbols, 12, async (symbol) => {
    try {
      const rows = await fetchCsvFor(symbol);
      if (!rows || rows.length === 0) {
        symbolsFailed++;
        return;
      }

      const recent = rows.filter((r) => new Date(r.date) >= FIVE_YEARS_AGO);
      if (recent.length === 0) return;

      // Ensure strictly chronological order (oldest-to-newest) to compute prevClose correctly.
      const chronological = [...recent].sort((a, b) => a.date.localeCompare(b.date));
      let prevClose: number | null = null;
      const upsertRows = chronological.map((r) => {
        const flagged = detectCorporateAction(r, prevClose);
        prevClose = r.close ?? prevClose;
        return {
          symbol,
          date: r.date,
          open: r.open,
          high: r.high,
          low: r.low,
          close: r.close,
          volume: r.volume,
          per_change: r.perChange,
          possible_corporate_action: flagged,
        };
      });

      await supabase.from('companies').upsert(
        { symbol, name: symbol, sector: 'Others', status: 'ACTIVE' },
        { onConflict: 'symbol', ignoreDuplicates: true }
      );

      for (let i = 0; i < upsertRows.length; i += 500) {
        const slice = upsertRows.slice(i, i + 500);
        const { error } = await supabase
          .from('daily_prices')
          .upsert(slice, { onConflict: 'symbol,date' });
        if (error) {
          console.error(`  ${symbol} upsert error:`, error.message);
          symbolsFailed++;
          return;
        }
        rowsUpserted += slice.length;
      }
      symbolsSynced++;
    } catch (e) {
      symbolsFailed++;
      console.error(`  ${symbol} failed:`, (e as Error).message);
    }
  });

  const seconds = ((Date.now() - startTime) / 1000).toFixed(1);
  console.log('\n--- Sync summary ---');
  console.log(`Symbols synced: ${symbolsSynced}`);
  console.log(`Symbols failed: ${symbolsFailed}`);
  console.log(`Rows upserted:  ${rowsUpserted}`);
  console.log(`Total time:     ${seconds}s`);
}

main().catch((e) => {
  console.error('Sync failed:', e);
  process.exit(1);
});
