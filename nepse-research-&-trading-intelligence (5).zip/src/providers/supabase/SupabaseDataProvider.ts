import { IMarketDataProvider, IStockDataProvider } from '../interfaces';
import {
  CompanyMaster,
  HistoricalPriceRecord,
  MarketIndexRecord,
  DailyMarketStatistics,
  ProviderStatusInfo,
} from '../../types/dataInfrastructure';
import { supabase } from '../../lib/supabaseClient';
import { OHLCVBar } from '../../types/technicalIndicators';

export class SupabaseDataProvider implements IMarketDataProvider, IStockDataProvider {
  public readonly providerName = 'Supabase NEPSE Data Provider';
  public readonly isLive = true;

  private isConnected = true;
  private lastError: string | null = null;

  // In-memory caches to ensure snappy responsiveness across UI components
  private companiesCache: CompanyMaster[] | null = null;
  private priceHistoryCache = new Map<string, HistoricalPriceRecord[]>();
  private barCache = new Map<string, OHLCVBar[]>();
  private indexCache: MarketIndexRecord[] | null = null;
  private latestDate: string | null = null;

  public getStatus(): ProviderStatusInfo {
    return {
      providerStatus: this.isConnected ? 'LIVE_DATA_CONNECTED' : 'LIVE_DATA_UNAVAILABLE',
      reason: this.isConnected
        ? 'Connected to Supabase NEPSE data warehouse (5-year historical prices & official indices).'
        : (this.lastError || 'Supabase connection unavailable.'),
      timestamp: new Date().toISOString(),
      gateway: this.providerName,
      authenticated: true,
    };
  }

  // ==========================================
  // Company & Stock Master
  // ==========================================
  public async fetchCompanies(): Promise<CompanyMaster[]> {
    if (this.companiesCache && this.companiesCache.length > 0) {
      return [...this.companiesCache];
    }

    try {
      const { data, error } = await supabase
        .from('companies')
        .select('symbol, name, sector, status')
        .order('symbol', { ascending: true });

      if (error) {
        this.isConnected = false;
        this.lastError = error.message;
        console.error('Supabase fetchCompanies error:', error);
        return [];
      }

      this.isConnected = true;
      const now = new Date().toISOString();
      const mapped: CompanyMaster[] = (data || []).map((row) => ({
        id: row.symbol,
        symbol: row.symbol,
        company_name: row.name || row.symbol,
        sector_id: row.sector || 'Others',
        security_type: 'EQ',
        status: (row.status === 'SUSPENDED' || row.status === 'DELISTED') ? row.status : 'ACTIVE',
        listed_date: '2020-01-01',
        paid_up_capital: 1_000_000_000,
        listed_shares: 10_000_000,
        face_value: 100,
        created_at: now,
        updated_at: now,
      }));

      this.companiesCache = mapped;
      return [...mapped];
    } catch (err: any) {
      this.isConnected = false;
      this.lastError = err?.message || 'Network error';
      console.error('Supabase fetchCompanies exception:', err);
      return [];
    }
  }

  // ==========================================
  // Stock Price History
  // ==========================================
  public async fetchPriceHistory(
    symbolOrId: string,
    limit?: number
  ): Promise<HistoricalPriceRecord[]> {
    const symbol = symbolOrId.toUpperCase().trim();
    const cached = this.priceHistoryCache.get(symbol);

    if (cached && (!limit || cached.length >= limit)) {
      return limit ? cached.slice(0, limit) : cached;
    }

    try {
      // Query up to 2000 rows (full 5-year daily history)
      const fetchLimit = limit && limit < 2000 ? Math.max(limit, 200) : 2000;
      const { data, error } = await supabase
        .from('daily_prices')
        .select('id, symbol, date, open, high, low, close, volume, per_change, possible_corporate_action, created_at')
        .eq('symbol', symbol)
        .order('date', { ascending: false })
        .limit(fetchLimit);

      if (error) {
        this.lastError = error.message;
        console.error(`Supabase fetchPriceHistory error for ${symbol}:`, error);
        return cached ? (limit ? cached.slice(0, limit) : cached) : [];
      }

      this.isConnected = true;

      const records: HistoricalPriceRecord[] = (data || []).map((row) => {
        const close = Number(row.close ?? 0);
        const perChange = row.per_change !== null && row.per_change !== undefined ? Number(row.per_change) : 0;
        const prevClose = perChange !== 0 ? Math.round((close / (1 + perChange / 100)) * 100) / 100 : close;
        const change = Math.round((close - prevClose) * 100) / 100;
        const vol = Number(row.volume ?? 0);

        return {
          id: `pr-${row.id || `${row.symbol}-${row.date}`}`,
          company_id: row.symbol,
          symbol: row.symbol,
          date: row.date,
          open: Number(row.open ?? close),
          high: Number(row.high ?? close),
          low: Number(row.low ?? close),
          close,
          previous_close: prevClose,
          change,
          change_percent: perChange,
          volume: vol,
          turnover: Math.round(close * vol),
          transactions: 0,
          possible_corporate_action: Boolean(row.possible_corporate_action),
          created_at: row.created_at || row.date,
        };
      });

      this.priceHistoryCache.set(symbol, records);

      // Cache as standard OHLCV bars sorted chronologically (oldest -> newest) for indicators
      const chronological = [...records]
        .sort((a, b) => a.date.localeCompare(b.date))
        .map((r) => ({
          date: r.date,
          open: r.open,
          high: r.high,
          low: r.low,
          close: r.close,
          volume: r.volume,
          turnover: r.turnover,
        }));
      this.barCache.set(symbol, chronological);

      return limit ? records.slice(0, limit) : records;
    } catch (err: any) {
      this.lastError = err?.message || 'Network error';
      console.error(`Supabase fetchPriceHistory exception for ${symbol}:`, err);
      return cached ? (limit ? cached.slice(0, limit) : cached) : [];
    }
  }

  public async fetchLatestPrice(symbolOrId: string): Promise<HistoricalPriceRecord | null> {
    const history = await this.fetchPriceHistory(symbolOrId, 1);
    return history.length > 0 ? history[0] : null;
  }

  public async fetchAllLatestPrices(): Promise<HistoricalPriceRecord[]> {
    try {
      const indices = await this.fetchIndices();
      const latestDate = indices.length > 0 ? indices[0].date : '2026-09-15';

      const { data, error } = await supabase
        .from('daily_prices')
        .select('id, symbol, date, open, high, low, close, volume, per_change, possible_corporate_action, created_at')
        .eq('date', latestDate);

      if (error || !data) {
        console.error('fetchAllLatestPrices error:', error);
        return [];
      }

      return data.map((row) => {
        const close = Number(row.close ?? 0);
        const perChange = row.per_change !== null && row.per_change !== undefined ? Number(row.per_change) : 0;
        const prevClose = perChange !== 0 ? Math.round((close / (1 + perChange / 100)) * 100) / 100 : close;
        const change = Math.round((close - prevClose) * 100) / 100;
        const vol = Number(row.volume ?? 0);

        return {
          id: `pr-${row.id || `${row.symbol}-${row.date}`}`,
          company_id: row.symbol,
          symbol: row.symbol,
          date: row.date,
          open: Number(row.open ?? close),
          high: Number(row.high ?? close),
          low: Number(row.low ?? close),
          close,
          previous_close: prevClose,
          change,
          change_percent: perChange,
          volume: vol,
          turnover: Math.round(close * vol),
          transactions: 0,
          possible_corporate_action: Boolean(row.possible_corporate_action),
          created_at: row.created_at || row.date,
        };
      });
    } catch (err) {
      console.error('fetchAllLatestPrices exception:', err);
      return [];
    }
  }

  // ==========================================
  // Synchronous Bar Access with Auto-Cache
  // ==========================================
  public getCachedBars(symbol: string): OHLCVBar[] | null {
    return this.barCache.get(symbol.toUpperCase().trim()) || null;
  }

  public setCachedBars(symbol: string, bars: OHLCVBar[]): void {
    this.barCache.set(symbol.toUpperCase().trim(), bars);
  }

  // ==========================================
  // Market Index & Statistics
  // ==========================================
  public async fetchIndices(date?: string): Promise<MarketIndexRecord[]> {
    if (this.indexCache && !date) {
      return [...this.indexCache];
    }

    try {
      let query = supabase
        .from('market_index')
        .select('date, close, change_percent, turnover')
        .order('date', { ascending: false });

      if (date) {
        query = query.eq('date', date);
      } else {
        query = query.limit(1200);
      }

      const { data, error } = await query;

      if (error) {
        this.lastError = error.message;
        console.error('Supabase fetchIndices error:', error);
        return [];
      }

      this.isConnected = true;
      const mapped: MarketIndexRecord[] = (data || []).map((row) => {
        const close = Number(row.close ?? 0);
        const perChange = row.change_percent !== null && row.change_percent !== undefined ? Number(row.change_percent) : 0;
        const change = perChange !== 0 ? Math.round(((close * perChange) / (100 + perChange)) * 100) / 100 : 0;
        const turnover = Number(row.turnover ?? 0);

        return {
          id: `idx-nepse-${row.date}`,
          index_id: 'NEPSE',
          name: 'NEPSE Index',
          date: row.date,
          open: close,
          high: close,
          low: close,
          close,
          change,
          change_percent: perChange,
          turnover,
          volume: Math.round(turnover / (close || 1)),
          transactions: 0,
          created_at: row.date,
        };
      });

      if (!date) {
        this.indexCache = mapped;
        if (mapped.length > 0) {
          this.latestDate = mapped[0].date;
        }
      }

      return mapped;
    } catch (err: any) {
      this.lastError = err?.message || 'Network error';
      console.error('Supabase fetchIndices exception:', err);
      return [];
    }
  }

  public async fetchDailyStatistics(date?: string): Promise<DailyMarketStatistics> {
    const now = new Date().toISOString();
    try {
      const indices = await this.fetchIndices(date);
      const targetDate = date || (indices.length > 0 ? indices[0].date : '2026-09-15');
      const latestIndex = indices.find((i) => i.date === targetDate) || indices[0];

      // Query daily prices on that date to compute accurate advance/decline/unchanged breadth
      const { data: dayPrices, error } = await supabase
        .from('daily_prices')
        .select('per_change, volume, close')
        .eq('date', targetDate);

      if (error) {
        console.error('Supabase daily_prices query error in fetchDailyStatistics:', error);
        return {
          id: `stat-${targetDate}`,
          date: targetDate,
          total_turnover: 0,
          total_volume: 0,
          total_transactions: 0,
          listed_companies: 0,
          traded_companies: 0,
          advancers: 0,
          decliners: 0,
          unchanged: 0,
          advance_decline_ratio: 0,
          market_breadth: null,
          stocks_above_20ema: 0,
          stocks_above_50sma: 0,
          stocks_above_200sma: 0,
          created_at: now,
          hasData: false,
        };
      }

      if (!dayPrices || dayPrices.length === 0) {
        return {
          id: `stat-${targetDate}`,
          date: targetDate,
          total_turnover: latestIndex ? latestIndex.turnover : 0,
          total_volume: latestIndex ? latestIndex.volume : 0,
          total_transactions: 0,
          listed_companies: 0,
          traded_companies: 0,
          advancers: 0,
          decliners: 0,
          unchanged: 0,
          advance_decline_ratio: 0,
          market_breadth: null,
          stocks_above_20ema: 0,
          stocks_above_50sma: 0,
          stocks_above_200sma: 0,
          created_at: now,
          hasData: false,
        };
      }

      let advancers = 0;
      let decliners = 0;
      let unchanged = 0;
      let totalVolume = 0;
      let totalTurnover = latestIndex ? latestIndex.turnover : 0;

      for (const p of dayPrices) {
        const chg = Number(p.per_change ?? 0);
        const vol = Number(p.volume ?? 0);
        const close = Number(p.close ?? 0);
        totalVolume += vol;
        if (!totalTurnover) {
          totalTurnover += close * vol;
        }
        if (chg > 0.001) advancers++;
        else if (chg < -0.001) decliners++;
        else unchanged++;
      }

      const adRatio = decliners > 0 ? Math.round((advancers / decliners) * 100) / 100 : (advancers > 0 ? advancers : 0);
      const totalTraded = advancers + decliners + unchanged;
      const breadth = adRatio >= 1.2 ? 'BULLISH' : adRatio <= 0.8 ? 'BEARISH' : 'NEUTRAL';

      return {
        id: `stat-${targetDate}`,
        date: targetDate,
        total_turnover: totalTurnover,
        total_volume: totalVolume || (latestIndex ? latestIndex.volume : 0),
        total_transactions: 0,
        listed_companies: 0,
        traded_companies: totalTraded,
        advancers,
        decliners,
        unchanged,
        advance_decline_ratio: adRatio,
        market_breadth: breadth,
        stocks_above_20ema: 0,
        stocks_above_50sma: 0,
        stocks_above_200sma: 0,
        created_at: now,
        hasData: true,
      };
    } catch (err) {
      console.error('Supabase fetchDailyStatistics error:', err);
      const fallbackDate = date || '2026-09-15';
      return {
        id: `stat-${fallbackDate}`,
        date: fallbackDate,
        total_turnover: 0,
        total_volume: 0,
        total_transactions: 0,
        listed_companies: 0,
        traded_companies: 0,
        advancers: 0,
        decliners: 0,
        unchanged: 0,
        advance_decline_ratio: 0,
        market_breadth: null,
        stocks_above_20ema: 0,
        stocks_above_50sma: 0,
        stocks_above_200sma: 0,
        created_at: now,
        hasData: false,
      };
    }
  }
}

export const supabaseDataProvider = new SupabaseDataProvider();
