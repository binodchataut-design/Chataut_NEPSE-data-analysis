import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Read configuration strictly from environment variables
const metaEnv = (typeof import.meta !== 'undefined' && (import.meta as any).env) || {};
const procEnv = (typeof process !== 'undefined' && process.env) || {};

const rawUrl = metaEnv.VITE_SUPABASE_URL || procEnv.VITE_SUPABASE_URL || 'https://tbeznjlzyinoaorcovis.supabase.co';
export const supabaseUrl = rawUrl.replace(/\/rest\/v1\/?$/, '');

export const supabaseAnonKey = (metaEnv.VITE_SUPABASE_ANON_KEY || procEnv.VITE_SUPABASE_ANON_KEY || '').trim();

export const isSupabaseConfigured = Boolean(
  supabaseAnonKey &&
  supabaseAnonKey !== 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRiZXpuamx6eWlub2FvcmNvdmlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk0NzQ5OTIsImV4cCI6MjEwNTA1MDk5Mn0.7o8LvlY-xyH1B959-GZlkfUyomeoCAAL-Ex9tW3LXnE' &&
  supabaseAnonKey.length > 0
);

// Create client instance. If unconfigured, supply dummy key so instantiation does not crash module load
export const supabase: SupabaseClient = createClient(
  supabaseUrl,
  supabaseAnonKey || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRiZXpuamx6eWlub2FvcmNvdmlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk0NzQ5OTIsImV4cCI6MjEwNTA1MDk5Mn0.7o8LvlY-xyH1B959-GZlkfUyomeoCAAL-Ex9tW3LXnE'
);

export function assertSupabaseConfigured(): void {
  if (!isSupabaseConfigured) {
    throw new Error(
      'Supabase is not configured: VITE_SUPABASE_ANON_KEY environment variable is missing. Please set VITE_SUPABASE_ANON_KEY in your environment.'
    );
  }
}
