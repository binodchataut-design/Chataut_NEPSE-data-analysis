import { IMarketDataProvider, IStockDataProvider } from '../interfaces';
import {
  CompanyMaster,
  HistoricalPriceRecord,
  MarketIndexRecord,
  DailyMarketStatistics,
  ProviderStatusInfo,
  SecurityType,
  EntityStatus,
} from '../../types/dataInfrastructure';
import { supabase, isSupabaseConfigured, assertSupabaseConfigured } from '../../lib/supabaseClient';
import { normalizedIndices, normalizedDailyStats } from '../../data/normalizedMasterData';
import { getCachedBars } from '../../data/liveBarsCache';

export class SupabaseDataProvider implements IStockDataProvider, IMarketDataProvider {
  public readonly providerName = 'SupabaseDataProvider';
  public readonly isLive = true;

  public getStatus(): ProviderStatusInfo {
    return {
      providerStatus: isSupabaseConfigured ? 'LIVE_DATA_CONNECTED' : 'LIVE_DATA_UNAVAILABLE',
      reason: isSupabaseConfigured
        ? 'Connected to Supabase PostgreSQL database (daily_prices, equity_companies).'
        : 'Supabase credentials not configured. Please set VITE_SUPABASE_ANON_KEY.',
      timestamp: new Date().toISOString(),
      gateway: this.providerName,
      authenticated: isSupabaseConfigured,
    };
  }

  // ==========================================
  // IStockDataProvider Implementation
  // ==========================================

  public async fetchCompanies(): Promise<CompanyMaster[]> {
    assertSupabaseConfigured();
    const { data, error } = await supabase
      .from('equity_companies')
      .select('symbol, name, sector, status, created_at, instrument_type')
      .order('symbol', { ascending: true });

    if (error) {
      throw new Error(`Failed to fetch companies from Supabase: ${error.message}`);
    }

    return (data || []).map((row: any) => ({
      id: `cmp-${String(row.symbol).toLowerCase().trim()}`,
      symbol: String(row.symbol).toUpperCase().trim(),
      company_name: row.name || row.symbol,
      sector_id: row.sector || 'Others',
      sector: row.sector || 'Others',
      security_type: 'EQ' as SecurityType,
      listed_date: '2020-01-01',
      listed_shares: 10000000,
      paid_up_capital: 1000000000,
      face_value: 100,
      status: (row.status || 'ACTIVE') as EntityStatus,
      created_at: row.created_at || new Date().toISOString(),
      updated_at: row.created_at || new Date().toISOString(),
    }));
  }

  public async fetchPriceHistory(symbolOrId: string, limit?: number): Promise<HistoricalPriceRecord[]> {
    assertSupabaseConfigured();
    const sym = (symbolOrId || '').toUpperCase().trim();

    // Check if in-memory bars cache already holds the historical bars for this symbol
    const cachedBars = getCachedBars(sym);
    if (cachedBars && cachedBars.length > 0) {
      const records: HistoricalPriceRecord[] = cachedBars.map((b, idx) => ({
        id: `${sym}-${b.date}`,
        company_id: `cmp-${sym.toLowerCase()}`,
        symbol: sym,
        date: b.date,
        open: b.open,
        high: b.high,
        low: b.low,
        close: b.close,
        previous_close: idx > 0 ? cachedBars[idx - 1].close : b.open,
        change: idx > 0 ? Math.round((b.close - cachedBars[idx - 1].close) * 100) / 100 : 0,
        change_percent: idx > 0 && cachedBars[idx - 1].close > 0
          ? Math.round(((b.close - cachedBars[idx - 1].close) / cachedBars[idx - 1].close) * 10000) / 100
          : 0,
        volume: b.volume,
        turnover: b.turnover || b.close * b.volume,
        transactions: 100,
        created_at: `${b.date}T15:00:00Z`,
      }));

      if (limit && limit > 0) {
        return records.slice(-limit);
      }
      return records;
    }

    // Direct Supabase query if not yet loaded in bars cache
    let query = supabase
      .from('daily_prices')
      .select('id, symbol, date, open, high, low, close, volume, created_at')
      .eq('symbol', sym)
      .order('date', { ascending: true });

    if (limit && limit > 0) {
      query = query.limit(limit);
    }

    const { data, error } = await query;
    if (error) {
      throw new Error(`Failed to fetch price history for ${sym} from Supabase: ${error.message}`);
    }

    const rows = data || [];
    return rows.map((row: any, idx: number) => {
      const close = Number(row.close ?? 0);
      const prevClose = idx > 0 ? Number(rows[idx - 1].close ?? close) : Number(row.open ?? close);
      return {
        id: String(row.id || `${sym}-${row.date}`),
        company_id: `cmp-${sym.toLowerCase()}`,
        symbol: sym,
        date: String(row.date),
        open: Number(row.open ?? close),
        high: Number(row.high ?? close),
        low: Number(row.low ?? close),
        close,
        previous_close: prevClose,
        change: Math.round((close - prevClose) * 100) / 100,
        change_percent: prevClose > 0 ? Math.round(((close - prevClose) / prevClose) * 10000) / 100 : 0,
        volume: Number(row.volume ?? 0),
        turnover: Number(row.volume ?? 0) * close,
        transactions: 100,
        created_at: String(row.created_at || `${row.date}T15:00:00Z`),
      };
    });
  }

  public async fetchLatestPrice(symbolOrId: string): Promise<HistoricalPriceRecord | null> {
    const history = await this.fetchPriceHistory(symbolOrId, 1);
    return history.length > 0 ? history[history.length - 1] : null;
  }

  // ==========================================
  // IMarketDataProvider Implementation
  // ==========================================

  public async fetchIndices(date?: string): Promise<MarketIndexRecord[]> {
    if (!date) return [...normalizedIndices];
    return normalizedIndices.filter(i => i.date === date);
  }

  public async fetchDailyStatistics(date?: string): Promise<DailyMarketStatistics> {
    return { ...normalizedDailyStats };
  }
}

export const supabaseDataProvider = new SupabaseDataProvider();
