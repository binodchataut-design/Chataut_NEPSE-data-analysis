/**
 * Canonical NEPSE Security Universe Master (Phase 4D)
 * Sourced from official NEPSE metadata & cross-referenced with:
 * - Aabishkar2/nepse-data (372 companies with sharesansar mappings)
 * - binayabaral/nepal-market-data (450 instruments, reference classification)
 * - shawinCreates/Nepse-Market-Data (closed days calendar)
 *
 * Distinguishes ACTIVE_ORDINARY_EQUITY from MERGED, DELISTED, DEBENTURE, MUTUAL_FUND, PROMOTER_SHARE.
 */

import { SecurityReference } from '../types/realData';

export const NEPSE_SECURITY_UNIVERSE: SecurityReference[] = [
  {
    "symbol": "ACLBSL",
    "name": "Aarambha Chautari Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1039
  },
  {
    "symbol": "ADBL",
    "name": "Agricultural Development Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 24
  },
  {
    "symbol": "ADBLB87",
    "name": "4% Agricultural Bond 2087",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "ADBLD83",
    "name": "10.35% Agricultural Bank Debenture 2083",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "AHL",
    "name": "Asian Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1010
  },
  {
    "symbol": "AHPC",
    "name": "Arun Valley Hydropower Development Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 121
  },
  {
    "symbol": "AKJCL",
    "name": "Ankhukhola Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 590
  },
  {
    "symbol": "AKPL",
    "name": "Arun Kabeli Power Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 514
  },
  {
    "symbol": "ALBSL",
    "name": "Asha Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 670
  },
  {
    "symbol": "ALICL",
    "name": "Asian Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 143
  },
  {
    "symbol": "ANLB",
    "name": "Aatmanirbhar Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 997
  },
  {
    "symbol": "APHL",
    "name": "Appolo Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1548
  },
  {
    "symbol": "API",
    "name": "Api Power Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 527
  },
  {
    "symbol": "AVYAN",
    "name": "Aviyan Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1033
  },
  {
    "symbol": "BANDIPUR",
    "name": "Bandipur Cable Car and Tourism Limited",
    "instrumentType": "ordinary",
    "sector": "Hotel & Tourism",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1387
  },
  {
    "symbol": "BARUN",
    "name": "Barun Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 493
  },
  {
    "symbol": "BBC",
    "name": "Bishal Bazar Company Limited",
    "instrumentType": "ordinary",
    "sector": "Trading",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 123
  },
  {
    "symbol": "BEDC",
    "name": "Bhugol Energy Development Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 851
  },
  {
    "symbol": "BFC",
    "name": "Best Finance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 40
  },
  {
    "symbol": "BGWT",
    "name": "Bhagawati Hydropower Development Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1138
  },
  {
    "symbol": "BHCL",
    "name": "Bikash Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1397
  },
  {
    "symbol": "BHDC",
    "name": "Bindhyabasini Hydropower Development Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 766
  },
  {
    "symbol": "BHL",
    "name": "Balephi Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 969
  },
  {
    "symbol": "BHPL",
    "name": "Barahi Hydropower Public Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 674
  },
  {
    "symbol": "BJHL",
    "name": "Bhujung Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1222
  },
  {
    "symbol": "BNHC",
    "name": "Buddha Bhumi Nepal Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 782
  },
  {
    "symbol": "BNL",
    "name": "Bottlers Nepal Limited (Balaju)",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true
  },
  {
    "symbol": "BNT",
    "name": "Bottlers Nepal (Terai) Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 106
  },
  {
    "symbol": "BOKD86",
    "name": "8.5% BOK Debenture 2086",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "BOKD86KA",
    "name": "10.5% BOK Debenture 2086",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "BOKL",
    "name": "Bank of Kathmandu Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "GBIME",
    "mergerEffectiveDate": "2023-01-09",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 634
  },
  {
    "symbol": "BPCL",
    "name": "Butwal Power Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 119
  },
  {
    "symbol": "BUNGAL",
    "name": "Bungal Hydro Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1179
  },
  {
    "symbol": "C30MF",
    "name": "Citizens Super 30 Mutual Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1123
  },
  {
    "symbol": "CBBL",
    "name": "Chhimek Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 159
  },
  {
    "symbol": "CBBLPO",
    "name": "Chhimek Laghubitta Bikas Bank Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "CBL",
    "name": "Civil Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "HBL",
    "mergerEffectiveDate": "2023-02-24",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 325
  },
  {
    "symbol": "CBLD88",
    "name": "10.25% Civil Bank Debenture 2088",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1130
  },
  {
    "symbol": "CCBD88",
    "name": "10.50% Century Debenture 2088",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "CCBL",
    "name": "Century Commercial Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "PRVU",
    "mergerEffectiveDate": "2023-01-10",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 335
  },
  {
    "symbol": "CFCL",
    "name": "Central Finance Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 54
  },
  {
    "symbol": "CFL",
    "name": "Crystal Finance Limited",
    "instrumentType": "ordinary",
    "sector": "Non Category",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 88
  },
  {
    "symbol": "CGH",
    "name": "Chandragiri Hills Limited",
    "instrumentType": "ordinary",
    "sector": "Hotel & Tourism",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 872
  },
  {
    "symbol": "CHCL",
    "name": "Chilime Hydro power Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 120
  },
  {
    "symbol": "CHDC",
    "name": "CEDB Holdings Limited",
    "instrumentType": "ordinary",
    "sector": "Investment",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 518
  },
  {
    "symbol": "CHL",
    "name": "Chhyangdi Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 628
  },
  {
    "symbol": "CIT",
    "name": "Citizen Investment Trust",
    "instrumentType": "ordinary",
    "sector": "Investment",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 33
  },
  {
    "symbol": "CITY",
    "name": "City Hotel Limited",
    "instrumentType": "ordinary",
    "sector": "Hotel & Tourism",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1166
  },
  {
    "symbol": "CIZBD86",
    "name": "10.25% Citizens Bank Debenture 2086",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "CIZBD90",
    "name": "10% Citizens Bank Debenture 2090",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1303
  },
  {
    "symbol": "CKHL",
    "name": "Chirkhwa Hydro Power Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1229
  },
  {
    "symbol": "CLI",
    "name": "Citizen Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 765
  },
  {
    "symbol": "CMB",
    "name": "Capital Merchant Banking & Finance Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 66
  },
  {
    "symbol": "CMF2",
    "name": "Citizens Mutual Fund - 2",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 890
  },
  {
    "symbol": "CORBL",
    "name": "Corporate Development Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 309
  },
  {
    "symbol": "CORBLP",
    "name": "Corporate Development Bank Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "CREST",
    "name": "Crest Micro Life Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1316
  },
  {
    "symbol": "CSY",
    "name": "Citizens Santulit Yojana",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1575
  },
  {
    "symbol": "CYCL",
    "name": "CYC Nepal Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1025
  },
  {
    "symbol": "CZBIL",
    "name": "Citizens Bank International Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 18
  },
  {
    "symbol": "CZBILP",
    "name": "Citizens Bank International Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "DDBL",
    "name": "Deprosc Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 162
  },
  {
    "symbol": "DHEL",
    "name": "Daramkhola Hydro Energy Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1125
  },
  {
    "symbol": "DHPL",
    "name": "Dibyashwari Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 542
  },
  {
    "symbol": "DLBS",
    "name": "Dhaulagiri Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 995
  },
  {
    "symbol": "DOLTI",
    "name": "Dolti Power Company Ltd",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1212
  },
  {
    "symbol": "DORDI",
    "name": "Dordi Khola Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 537
  },
  {
    "symbol": "EBL",
    "name": "Everest Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 10
  },
  {
    "symbol": "EBLD85",
    "name": "10.5% Everest Bank Ltd Rinpatra 2085",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1184
  },
  {
    "symbol": "EBLD86",
    "name": "8.5% Everest Bank Debenture",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "EBLD91",
    "name": "7.50% Everest Bank Limited Debenture  2091",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1516
  },
  {
    "symbol": "EBLEB89",
    "name": "\"Everest Bank Limited Energy Bond",
    "instrumentType": "ordinary",
    "sector": "debenture",
    "status": "listed",
    "classification": "UNKNOWN",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "ECL",
    "name": "Everest Colour Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true
  },
  {
    "symbol": "EDBL",
    "name": "Excel Development Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 182
  },
  {
    "symbol": "EHPL",
    "name": "Eastern Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 749
  },
  {
    "symbol": "ENL",
    "name": "Emerging Nepal Limited",
    "instrumentType": "ordinary",
    "sector": "Investment",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 883
  },
  {
    "symbol": "FMDBL",
    "name": "First Microfinance Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 392
  },
  {
    "symbol": "FOWAD",
    "name": "Forward Microfinance Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 465
  },
  {
    "symbol": "GBBD85",
    "name": "8.75% Garima Debenture 2085",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1108
  },
  {
    "symbol": "GBBL",
    "name": "Garima Bikas Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 150
  },
  {
    "symbol": "GBILD84-85",
    "name": "11.25% Global IME Bank Debenture 2084/85",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "GBILD86-87",
    "name": "8.5% Global IME Bank Ltd. Debenture 2086/87",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "GBIME",
    "name": "Global IME Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 404
  },
  {
    "symbol": "GBIMEP",
    "name": "Global IME Bank Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "GBIMESY2",
    "name": "Global IME Samunnat Yojana -II",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1273
  },
  {
    "symbol": "GBLBS",
    "name": "Grameen Bikas Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 508
  },
  {
    "symbol": "GCIL",
    "name": "Ghorahi Cement Industry Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1199
  },
  {
    "symbol": "GFCL",
    "name": "Goodwill Finance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 43
  },
  {
    "symbol": "GHL",
    "name": "Ghalemdi Hydro Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 579
  },
  {
    "symbol": "GIBF1",
    "name": "Global IME Balanced Fund-I",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 686
  },
  {
    "symbol": "GILB",
    "name": "Global IME Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 480
  },
  {
    "symbol": "GLBSL",
    "name": "Gurans Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 719
  },
  {
    "symbol": "GLH",
    "name": "Greenlife Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 755
  },
  {
    "symbol": "GLICL",
    "name": "Gurans Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "JLI",
    "mergerEffectiveDate": "2023-03-01",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 305
  },
  {
    "symbol": "GMFBS",
    "name": "Ganapati Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 658
  },
  {
    "symbol": "GMFIL",
    "name": "Guheswori Merchant Banking & Finance Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 71
  },
  {
    "symbol": "GMLI",
    "name": "Guardian Micro Life Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1323
  },
  {
    "symbol": "GRDBL",
    "name": "Green Development Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 487
  },
  {
    "symbol": "GSY",
    "name": "Garima Samriddhi Yojana",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1460
  },
  {
    "symbol": "GUFL",
    "name": "Gurkhas Finance Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 603
  },
  {
    "symbol": "GUFLPO",
    "name": "Gurkhas Finance Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "GVL",
    "name": "Green Ventures Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1094
  },
  {
    "symbol": "GWFD83",
    "name": "12% Goodwill Finance Limited Debenture 2083",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1004
  },
  {
    "symbol": "H8020",
    "name": "Himalayan 80-20",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1306
  },
  {
    "symbol": "HATHY",
    "name": "Hathway Investment Nepal Limited",
    "instrumentType": "ordinary",
    "sector": "Investment",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1022
  },
  {
    "symbol": "HBL",
    "name": "Himalayan Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 13
  },
  {
    "symbol": "HBLD86",
    "name": "Himalayan Bank Limited Bond 2086",
    "instrumentType": "ordinary",
    "sector": "Government Bonds",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "HBLPO",
    "name": "Himalayan Bank Limited Promoter",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "HDHPC",
    "name": "Himal Dolakha Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 722
  },
  {
    "symbol": "HDL",
    "name": "Himalayan Distillery Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 115
  },
  {
    "symbol": "HEI",
    "name": "Himalayan Everest Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1176
  },
  {
    "symbol": "HEIP",
    "name": "Himalayan Everest Insurance Limited Promoter",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1210
  },
  {
    "symbol": "HFIN",
    "name": "Hotel Forest Inn Limited",
    "instrumentType": "ordinary",
    "sector": "Hotel & Tourism",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1357
  },
  {
    "symbol": "HHL",
    "name": "Himalayan Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 963
  },
  {
    "symbol": "HIDCL",
    "name": "Hydroelectricity Investment and Development Company Limited",
    "instrumentType": "ordinary",
    "sector": "Investment",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 513
  },
  {
    "symbol": "HIDCLP",
    "name": "Hydroelectricity Investment and Development Company Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1183
  },
  {
    "symbol": "HIMSTAR",
    "name": "Him Star Urja Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1298
  },
  {
    "symbol": "HLBSL",
    "name": "Himalayan Laghubitta Bittiya Sanstha Limited (Former Civil Laghubitta)",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 427
  },
  {
    "symbol": "HLI",
    "name": "Himalayan Life Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1249
  },
  {
    "symbol": "HLICF",
    "name": "HLI Large Cap Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1606
  },
  {
    "symbol": "HPPL",
    "name": "Himalayan Power Partner Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 618
  },
  {
    "symbol": "HRL",
    "name": "Himalayan Reinsurance Limited",
    "instrumentType": "ordinary",
    "sector": "Others",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1119
  },
  {
    "symbol": "HURJA",
    "name": "Himalaya Urja Bikas Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 584
  },
  {
    "symbol": "ICFC",
    "name": "ICFC Finance Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 77
  },
  {
    "symbol": "ICFCD83",
    "name": "12% ICFC Finance Limited Debenture 2083",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "ICFCD88",
    "name": "9% ICFC Finance Limited Debenture 2088",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1504
  },
  {
    "symbol": "ICFCD89",
    "name": "8% ICFC  Finance Limited Debenture 2089",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1638
  },
  {
    "symbol": "IGI",
    "name": "IGI Prudential Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1264
  },
  {
    "symbol": "IHL",
    "name": "Ingwa Hydropower Ltd",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1189
  },
  {
    "symbol": "ILBS",
    "name": "Infinity Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 677
  },
  {
    "symbol": "ILBSP",
    "name": "Infinity Laghubitta Bittiya Sanstha Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "ILI",
    "name": "IME Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 735
  },
  {
    "symbol": "JBBD87",
    "name": "Jyoti Bikash Bank Bond 2087",
    "instrumentType": "ordinary",
    "sector": "Government Bonds",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "JBBL",
    "name": "Jyoti Bikash Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 151
  },
  {
    "symbol": "JBBLPO",
    "name": "Jyoti Bikas Bank Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "JBLB",
    "name": "Jeevan Bikas Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 934
  },
  {
    "symbol": "JFL",
    "name": "Janaki Finance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 59
  },
  {
    "symbol": "JHAPA",
    "name": "Jhapa Energy Limited",
    "instrumentType": "ordinary",
    "sector": "Others",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1445
  },
  {
    "symbol": "JLI",
    "name": "Jyoti Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "SJLIC",
    "mergerEffectiveDate": "2023-05-09",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 741
  },
  {
    "symbol": "JOSHI",
    "name": "Joshi Hydropower Development Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 665
  },
  {
    "symbol": "JSLBB",
    "name": "Janautthan Samudayic Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 423
  },
  {
    "symbol": "KAHL",
    "name": "Kalanga Hydro Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true
  },
  {
    "symbol": "KBL",
    "name": "Kumari Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 5
  },
  {
    "symbol": "KBLD86",
    "name": "10.25% Kumari Bank Debenture 2086",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "KBLD89",
    "name": "11% KBL Debenture 2089",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "KBLD90",
    "name": "10% KBL Debenture 2090",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1302
  },
  {
    "symbol": "KBLPO",
    "name": "Kumari Bank Limited Promotor Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "KBSH",
    "name": "Kutheli Bukhari Small Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1279
  },
  {
    "symbol": "KDBY",
    "name": "Kumari Dhanabriddhi Yojana",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1103
  },
  {
    "symbol": "KDL",
    "name": "Kalinchowk Darshan Limited",
    "instrumentType": "ordinary",
    "sector": "Hotel & Tourism",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1143
  },
  {
    "symbol": "KEF",
    "name": "Kumari Equity Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1059
  },
  {
    "symbol": "KHPL",
    "name": "Kalinchowk Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1376
  },
  {
    "symbol": "KKHC",
    "name": "Khani Khola Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 578
  },
  {
    "symbol": "KMCDB",
    "name": "Kalika Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 422
  },
  {
    "symbol": "KPCL",
    "name": "Kalika Power Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 701
  },
  {
    "symbol": "KRBL",
    "name": "Karnali Development Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 155
  },
  {
    "symbol": "KSBBL",
    "name": "Kamana Sewa Bikas Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 657
  },
  {
    "symbol": "KSBBLD87",
    "name": "9% Kamana Sewa Bikas Bank Limited Debenture 2087",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "KSY",
    "name": "Kumari Sabal Yojana",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1225
  },
  {
    "symbol": "LBBL",
    "name": "Lumbini Bikas Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 668
  },
  {
    "symbol": "LBBLD89",
    "name": "11% LBBL Debenture 2089",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "LBL",
    "name": "Laxmi Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "LXBL",
    "mergerEffectiveDate": "2023-07-14",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 6
  },
  {
    "symbol": "LBLD86",
    "name": "10% Laxmi Bank Debenture 2086",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "LBLD88",
    "name": "8.5% Laxmi Bank Debenture",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "LEC",
    "name": "Liberty Energy Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 874
  },
  {
    "symbol": "LICN",
    "name": "Life Insurance Corporation Nepal Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 138
  },
  {
    "symbol": "LLBS",
    "name": "Laxmi Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 426
  },
  {
    "symbol": "LSH12",
    "name": "LS Horizon 12",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "LSL",
    "name": "Laxmi Sunrise Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1280
  },
  {
    "symbol": "LUK",
    "name": "Laxmi Unnati Kosh",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 949
  },
  {
    "symbol": "LVF2",
    "name": "Laxmi Value Fund-II",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1174
  },
  {
    "symbol": "MABEL",
    "name": "Mabilung Energy Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1317
  },
  {
    "symbol": "MAKAR",
    "name": "Makar Jitumaya Suri Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1110
  },
  {
    "symbol": "MANDU",
    "name": "Mandu Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1243
  },
  {
    "symbol": "MATRI",
    "name": "Matribhumi Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1512
  },
  {
    "symbol": "MBJC",
    "name": "Madhya Bhotekoshi Jalavidyut Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 505
  },
  {
    "symbol": "MBL",
    "name": "Machhapuchchhre Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 7
  },
  {
    "symbol": "MBLD87",
    "name": "8.5% Machhapuchchhre Debenture 2087",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1106
  },
  {
    "symbol": "MBLEF",
    "name": "MBL Equity Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1541
  },
  {
    "symbol": "MCHL",
    "name": "Menchhiyam Hydropower  Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1221
  },
  {
    "symbol": "MDB",
    "name": "Miteri Development Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 149
  },
  {
    "symbol": "MDBPO",
    "name": "Miteri Development Bank Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "MEGA",
    "name": "Mega Bank Nepal Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "NIMB",
    "mergerEffectiveDate": "2023-01-11",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 301
  },
  {
    "symbol": "MEHL",
    "name": "Manakamana Engineering Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1250
  },
  {
    "symbol": "MEL",
    "name": "Modi Energy Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1144
  },
  {
    "symbol": "MEN",
    "name": "Mountain Energy Nepal Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 844
  },
  {
    "symbol": "MEPDL",
    "name": "Mount Everest Power Development Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true
  },
  {
    "symbol": "MERO",
    "name": "Mero Microfinance Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 478
  },
  {
    "symbol": "MFIL",
    "name": "Manjushree Finance Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 337
  },
  {
    "symbol": "MFLD85",
    "name": "9.5%  Manjushree Finance Ltd. Debenture 2085",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "MHCL",
    "name": "Molung Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1080
  },
  {
    "symbol": "MHL",
    "name": "Mandakini Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 541
  },
  {
    "symbol": "MHNL",
    "name": "Mountain Hydro Nepal Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 678
  },
  {
    "symbol": "MKCL",
    "name": "Muktinath Krishi Company Limited",
    "instrumentType": "ordinary",
    "sector": "Others",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1152
  },
  {
    "symbol": "MKHC",
    "name": "Maya Khola Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 725
  },
  {
    "symbol": "MKHL",
    "name": "Mai Khola Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1200
  },
  {
    "symbol": "MKJC",
    "name": "Mailung Khola Jal Vidhyut Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 535
  },
  {
    "symbol": "MLBBL",
    "name": "Mithila Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 424
  },
  {
    "symbol": "MLBL",
    "name": "Mahalaxmi Bikas Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 637
  },
  {
    "symbol": "MLBLD89",
    "name": "11% Mahalaxmi Debenture 2089",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1227
  },
  {
    "symbol": "MLBS",
    "name": "Manushi Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 865
  },
  {
    "symbol": "MLBSL",
    "name": "Mahila Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 882
  },
  {
    "symbol": "MMF1",
    "name": "Mega Mutual Fund - 1",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1100
  },
  {
    "symbol": "MMKJL",
    "name": "Mathillo Mailun Khola Jalvidhyut Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 966
  },
  {
    "symbol": "MNBBL",
    "name": "Muktinath Bikas Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 306
  },
  {
    "symbol": "MNBBLP",
    "name": "Muktinath Bikas Bank Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "MND84-85",
    "name": "8.75% Muktinath Debenture/Rinpatra 2084/85",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "MNMF1",
    "name": "Muktinath Mutual Fund 1",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1365
  },
  {
    "symbol": "MPFL",
    "name": "Multipurpose Finance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 318
  },
  {
    "symbol": "MSHL",
    "name": "Mid Solu Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1170
  },
  {
    "symbol": "MSLB",
    "name": "Mahuli Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 591
  },
  {
    "symbol": "NABBC",
    "name": "Narayani Development Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 167
  },
  {
    "symbol": "NABIL",
    "name": "Nabil Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 16
  },
  {
    "symbol": "NABILD2089",
    "name": "7% Nabil Debenture 2089",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NABILD87",
    "name": "9% Nabil Debenture 2087",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NADEP",
    "name": "NADEP Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 606
  },
  {
    "symbol": "NBB",
    "name": "Nepal Bangladesh Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "NABIL",
    "mergerEffectiveDate": "2022-07-11",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 11
  },
  {
    "symbol": "NBBD2085",
    "name": "10.25% NBBL Debenture 2085",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 917
  },
  {
    "symbol": "NBF2",
    "name": "Nabil Balanced Fund - 2",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 891
  },
  {
    "symbol": "NBF3",
    "name": "Nabil Balanced Fund III",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1117
  },
  {
    "symbol": "NBL",
    "name": "Nepal Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 341
  },
  {
    "symbol": "NBLD82",
    "name": "10% Nabil Bank Debenture 2082",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 978
  },
  {
    "symbol": "NBLD85",
    "name": "8% Nabil Debenture 2085",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1087
  },
  {
    "symbol": "NBLD87",
    "name": "8.5% Nepal Bank Debenture 2087",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1116
  },
  {
    "symbol": "NCCB",
    "name": "Nepal Credit and Commerce Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "KBL",
    "mergerEffectiveDate": "2023-01-01",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 3
  },
  {
    "symbol": "NCCD86",
    "name": "9.5%  NCC Rinpatra 2086",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NESDO",
    "name": "Nesdo Sambridha Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 964
  },
  {
    "symbol": "NFS",
    "name": "Nepal Finance Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 25
  },
  {
    "symbol": "NGPL",
    "name": "Ngadi Group Power Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 570
  },
  {
    "symbol": "NHDL",
    "name": "Nepal Hydro Developer Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 612
  },
  {
    "symbol": "NHPC",
    "name": "National Hydro Power Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 118
  },
  {
    "symbol": "NIB",
    "name": "Nepal Investment Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "NIMB",
    "mergerEffectiveDate": "2023-01-11",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 15
  },
  {
    "symbol": "NIBD84",
    "name": "8.5% Nepal Investment Bank Bond 2084",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NIBLGF",
    "name": "NIBL Growth Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1121
  },
  {
    "symbol": "NIBLSTF",
    "name": "NIBL Stable Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1237
  },
  {
    "symbol": "NIBSF2",
    "name": "NIBL Samriddhi Fund - 2",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1073
  },
  {
    "symbol": "NICA",
    "name": "NIC Asia Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 446
  },
  {
    "symbol": "NICAD2091",
    "name": "7% NIC Asia Debenture 2091",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NICAD85-86",
    "name": "10% NIC Asia Debenture 2085/86",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NICAP",
    "name": "NICA Bank Limited Promoter share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NICBF",
    "name": "NIC ASIA Balanced Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 888
  },
  {
    "symbol": "NICD83-84",
    "name": "10.25% NIC ASIA Debenture 2083/84",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NICD88",
    "name": "8.5% NIC Asia Debenture 2088",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NICFC",
    "name": "NIC Asia Flexi Cap Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1115
  },
  {
    "symbol": "NICGF2",
    "name": "NIC Asia Growth Fund 2",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1127
  },
  {
    "symbol": "NICL",
    "name": "Nepal Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 126
  },
  {
    "symbol": "NICLBSL",
    "name": "NIC Asia Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 775
  },
  {
    "symbol": "NICSF",
    "name": "NIC Asia Select-30",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1060
  },
  {
    "symbol": "NIFRA",
    "name": "Nepal Infrastructure Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Investment",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 896
  },
  {
    "symbol": "NIFRAGED",
    "name": "6% Nifra Harit Urja Debenture 2088/89",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1547
  },
  {
    "symbol": "NIFRAUR85-86",
    "name": "7% NIFRA Urja Rinpatra 2085/86",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NIL",
    "name": "Neco Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 133
  },
  {
    "symbol": "NIMB",
    "name": "Nepal Investment Mega Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1192
  },
  {
    "symbol": "NIMBD90",
    "name": "10% NIMB Debenture 2090",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NIMBPO",
    "name": "Nepal Investment Mega Bank Ltd. Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1265
  },
  {
    "symbol": "NLG",
    "name": "NLG Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 364
  },
  {
    "symbol": "NLIC",
    "name": "Nepal Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 137
  },
  {
    "symbol": "NLICL",
    "name": "National Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 128
  },
  {
    "symbol": "NLO",
    "name": "Nepal Lube Oil Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true
  },
  {
    "symbol": "NMB",
    "name": "NMB Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1
  },
  {
    "symbol": "NMB50",
    "name": "NMB 50",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 901
  },
  {
    "symbol": "NMBD2085",
    "name": "10% NMB Debenture 2085",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NMBD87-88",
    "name": "8.5% NMB Rinpatra 2087/88",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NMBD89-90",
    "name": "10.75% NMB Debenture  2089/2090",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NMBHF2",
    "name": "NMB Hybrid Fund L-II",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1178
  },
  {
    "symbol": "NMBMF",
    "name": "NMB Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 506
  },
  {
    "symbol": "NMBPO",
    "name": "NMB Bank Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NMBUR93-94",
    "name": "4% NMB Urja Rinpatra (Energy Bond II) 2093/94",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "NMFBS",
    "name": "National Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1313
  },
  {
    "symbol": "NMIC",
    "name": "Nepal Micro Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1324
  },
  {
    "symbol": "NMLBBL",
    "name": "Nerude Mirmire Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1272
  },
  {
    "symbol": "NRIC",
    "name": "Nepal Reinsurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Others",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 534
  },
  {
    "symbol": "NRM",
    "name": "Nepal Republic Media Limited",
    "instrumentType": "ordinary",
    "sector": "Others",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1228
  },
  {
    "symbol": "NRN",
    "name": "NRN Infrastructure and Development Limited",
    "instrumentType": "ordinary",
    "sector": "Investment",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 972
  },
  {
    "symbol": "NSIF2",
    "name": "NMB Sulav Investment Fund - II",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1113
  },
  {
    "symbol": "NSY",
    "name": "Nepal Life Samriddhi Lagani Yojana",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1630
  },
  {
    "symbol": "NTC",
    "name": "Nepal Doorsanchar Company Limited",
    "instrumentType": "ordinary",
    "sector": "Others",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 117
  },
  {
    "symbol": "NUBL",
    "name": "Nirdhan Utthan Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 158
  },
  {
    "symbol": "NWCL",
    "name": "Nepal Warehousing Company Limited",
    "instrumentType": "ordinary",
    "sector": "Others",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1211
  },
  {
    "symbol": "NYADI",
    "name": "Nyadi Hydropower  Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 544
  },
  {
    "symbol": "OHL",
    "name": "Oriental Hotel Limited",
    "instrumentType": "ordinary",
    "sector": "Hotel & Tourism",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 97
  },
  {
    "symbol": "OMPL",
    "name": "Om Megashree Pharmaceuticals Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1206
  },
  {
    "symbol": "PBD84",
    "name": "10.15% Prime Debenture 2084",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "PBD85",
    "name": "8.75% Prime Debenture 2085",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "PBD88",
    "name": "10% Prime Debenture 2088",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1142
  },
  {
    "symbol": "PBD93",
    "name": "6.25% Prime Bank Debenture 2093",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "PBLD84",
    "name": "10% Prabhu Bank Debenture 2084 (PBLD84)",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1057
  },
  {
    "symbol": "PBLD86",
    "name": "10.25% Prabhu Bank Debenture 2086",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "PBLD87",
    "name": "8.5% Prabhu Bank Debenture 2087",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1085
  },
  {
    "symbol": "PCBL",
    "name": "Prime Commercial Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 22
  },
  {
    "symbol": "PCBLP",
    "name": "Prime Commercial Bank Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "PCIL",
    "name": "Palpa Cements Industries Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 932
  },
  {
    "symbol": "PFL",
    "name": "Pokhara Finance Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 47
  },
  {
    "symbol": "PHCL",
    "name": "Peoples Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1020
  },
  {
    "symbol": "PLI",
    "name": "Prabhu Life Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "PCLI",
    "mergerEffectiveDate": "2023-07-09",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 758
  },
  {
    "symbol": "PLIC",
    "name": "Prime Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "SNLI",
    "mergerEffectiveDate": "2023-07-07",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 144
  },
  {
    "symbol": "PMHPL",
    "name": "Panchakanya Mai Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 681
  },
  {
    "symbol": "PMLI",
    "name": "Prabhu Mahalaxmi Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1296
  },
  {
    "symbol": "PPCL",
    "name": "Panchthar Power Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 720
  },
  {
    "symbol": "PPL",
    "name": "People's Power Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 973
  },
  {
    "symbol": "PRIN",
    "name": "Prabhu Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 556
  },
  {
    "symbol": "PROFL",
    "name": "Progressive Finance Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 323
  },
  {
    "symbol": "PRSF",
    "name": "Prabhu Smart Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1118
  },
  {
    "symbol": "PRVU",
    "name": "Prabhu Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 509
  },
  {
    "symbol": "PRVUPO",
    "name": "Prabhu Bank Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "PSF",
    "name": "Prabhu Select Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1076
  },
  {
    "symbol": "PURE",
    "name": "Pure Energy Limited",
    "instrumentType": "ordinary",
    "sector": "Others",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1300
  },
  {
    "symbol": "RADHI",
    "name": "Radhi Bidyut Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 574
  },
  {
    "symbol": "RAWA",
    "name": "Rawa Energy Development Ltd.",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1202
  },
  {
    "symbol": "RBBD2088",
    "name": "7% RBBL Debenture 2088",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1590
  },
  {
    "symbol": "RBBD83",
    "name": "8.5% RBBL Debenture 2083",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "RBBF40",
    "name": "RBB Focus 40",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1574
  },
  {
    "symbol": "RBCL",
    "name": "Rastriya Beema Company Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 523
  },
  {
    "symbol": "RBCLPO",
    "name": "Rastriya Beema Company Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 564
  },
  {
    "symbol": "RFPL",
    "name": "River Falls Power Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 770
  },
  {
    "symbol": "RHGCL",
    "name": "Rapti Hydro & General Construction Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 721
  },
  {
    "symbol": "RHPC",
    "name": "Ridi Hydropower Development Company Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "RHPC",
    "mergerEffectiveDate": "2022-10-21",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 468
  },
  {
    "symbol": "RHPL",
    "name": "Rasuwagadhi Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 474
  },
  {
    "symbol": "RIDI",
    "name": "Ridi Power Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1208
  },
  {
    "symbol": "RLEL",
    "name": "Ridge Line Energy Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1446
  },
  {
    "symbol": "RLFL",
    "name": "Reliance Finance Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 491
  },
  {
    "symbol": "RLI",
    "name": "Reliance Life Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "PCLI",
    "mergerEffectiveDate": "2023-07-09",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 764
  },
  {
    "symbol": "RMF1",
    "name": "RBB Mutual Fund 1",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1089
  },
  {
    "symbol": "RMF2",
    "name": "RBB Mutual Fund 2",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1223
  },
  {
    "symbol": "RNLI",
    "name": "Reliable Nepal Life Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 737
  },
  {
    "symbol": "RRHP",
    "name": "Rairang Hydropower Development Company Limited.",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "RHPC",
    "mergerEffectiveDate": "2022-10-21",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 654
  },
  {
    "symbol": "RSDC",
    "name": "RSDC Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 490
  },
  {
    "symbol": "RSML",
    "name": "Reliance Spinning Mills Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1090
  },
  {
    "symbol": "RSY",
    "name": "Reliable Samriddhi Yojana",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1556
  },
  {
    "symbol": "RSY2",
    "name": "Reliable Samriddhi Yojana-2",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "RURU",
    "name": "Ru Ru Jalbidhyut Pariyojana Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 742
  },
  {
    "symbol": "SABBL",
    "name": "Salapa Bikas Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 447
  },
  {
    "symbol": "SADBL",
    "name": "Shangrila Development Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 298
  },
  {
    "symbol": "SAEF2",
    "name": "Sanima Equity Fund II",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SAGAR",
    "name": "Sagar Distillery Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1369
  },
  {
    "symbol": "SAGF",
    "name": "Sanima Growth Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1112
  },
  {
    "symbol": "SAHAS",
    "name": "Sahas Urja Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 656
  },
  {
    "symbol": "SAIL",
    "name": "Shreenagar Agritech Industries Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1455
  },
  {
    "symbol": "SALICO",
    "name": "Sagarmatha Lumbini Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1258
  },
  {
    "symbol": "SALICOPO",
    "name": "Sagarmatha Lumbini Insurance Company Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SAND2085",
    "name": "10% Sanima Debenture 2085",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SANIMA",
    "name": "Sanima Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 166
  },
  {
    "symbol": "SANVI",
    "name": "Sanvi Energy Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1338
  },
  {
    "symbol": "SAPDBL",
    "name": "Saptakoshi Development Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 999
  },
  {
    "symbol": "SAPIL",
    "name": "Sarvottam Paints Industries Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true
  },
  {
    "symbol": "SARBTM",
    "name": "Sarbottam Cement Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1071
  },
  {
    "symbol": "SBCF",
    "name": "Sunrise Bluechip Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1074
  },
  {
    "symbol": "SBD87",
    "name": "8.5% Sanima Debenture 2087",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SBD89",
    "name": "10.25% Sanima Debenture 2089",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1187
  },
  {
    "symbol": "SBI",
    "name": "Nepal SBI Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 12
  },
  {
    "symbol": "SBIBD86",
    "name": "10% Nepal SBI Bank Debenture 2086",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SBID2090",
    "name": "7% Nepal SBI Bank Debenture 2090",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SBID83",
    "name": "10.25% Nepal SBI Bank Debenture 2083",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SBID89",
    "name": "9% Nepal SBI Bank Debenture 2089",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1234
  },
  {
    "symbol": "SBL",
    "name": "Siddhartha Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 2
  },
  {
    "symbol": "SBLD2091",
    "name": "7.25% SBL Debenture 2091",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1602
  },
  {
    "symbol": "SBLD83",
    "name": "10.25% SBL Debenture 2083",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SBLD84",
    "name": "8.5% SBL Debenture 2084",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SBLD89",
    "name": "10.75 % SBL Debenture 2089",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1173
  },
  {
    "symbol": "SCB",
    "name": "Standard Chartered Bank Nepal Limited",
    "instrumentType": "ordinary",
    "sector": "Commercial Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 14
  },
  {
    "symbol": "SCBD",
    "name": "10.30% Standard Chartered Bank Nepal Limited Debenture",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1307
  },
  {
    "symbol": "SDBD87",
    "name": "\"9% Shangrila Development Bank Debenture",
    "instrumentType": "ordinary",
    "sector": "debenture",
    "status": "listed",
    "classification": "UNKNOWN",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SEF",
    "name": "Siddhartha Equity Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 685
  },
  {
    "symbol": "SEF2",
    "name": "Siddhartha Equity Fund 2",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SFCL",
    "name": "Samriddhi Finance Company Limited (former World Merchant Banking)",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "SFCL",
    "mergerEffectiveDate": "2021-08-01",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 64
  },
  {
    "symbol": "SFEF",
    "name": "Sunrise Focused Equity Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1122
  },
  {
    "symbol": "SFMF",
    "name": "Sunrise First Mutual Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 962
  },
  {
    "symbol": "SGHC",
    "name": "Swet-Ganga Hydropower & Construction Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1009
  },
  {
    "symbol": "SGHL",
    "name": "Sanigad Hydro Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true
  },
  {
    "symbol": "SGIC",
    "name": "Sanima GIC Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1226
  },
  {
    "symbol": "SHBL",
    "name": "Sahara Bikas Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "GBIME",
    "mergerEffectiveDate": "2021-04-01",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 343
  },
  {
    "symbol": "SHEL",
    "name": "Singati Hydro Energy Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 832
  },
  {
    "symbol": "SHINE",
    "name": "Shine Resunga Development Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 440
  },
  {
    "symbol": "SHINED",
    "name": "Shine Resunga Debenture",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1543
  },
  {
    "symbol": "SHIVM",
    "name": "Shivam Cements Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 750
  },
  {
    "symbol": "SHL",
    "name": "Soaltee Hotel Limited",
    "instrumentType": "ordinary",
    "sector": "Hotel & Tourism",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 95
  },
  {
    "symbol": "SHLB",
    "name": "Shrijanshil Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 944
  },
  {
    "symbol": "SHPC",
    "name": "Sanima Mai Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 432
  },
  {
    "symbol": "SICL",
    "name": "Shikhar Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 141
  },
  {
    "symbol": "SIFC",
    "name": "Shree Investment Finance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Finance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 53
  },
  {
    "symbol": "SIGS2",
    "name": "Siddhartha Investment Growth Scheme-2",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 889
  },
  {
    "symbol": "SIGS3",
    "name": "Siddhartha Investment Growth Scheme 3",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1111
  },
  {
    "symbol": "SIKLES",
    "name": "Sikles Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1092
  },
  {
    "symbol": "SINDU",
    "name": "Sindhu Bikas Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Development Bank",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 313
  },
  {
    "symbol": "SIPD",
    "name": "Shikhar Power Development Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1239
  },
  {
    "symbol": "SJCL",
    "name": "Sanjen Jalavidhyut Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 380
  },
  {
    "symbol": "SJLIC",
    "name": "SuryaJyoti Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1240
  },
  {
    "symbol": "SKBBL",
    "name": "Sana Kisan Bikas Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 419
  },
  {
    "symbol": "SKHEL",
    "name": "Suryakunda Hydro Electric Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1459
  },
  {
    "symbol": "SKHL",
    "name": "Super Khudi Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1399
  },
  {
    "symbol": "SLBBL",
    "name": "Swarojgar Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 420
  },
  {
    "symbol": "SLBBLP",
    "name": "Swarojgar Laghubitta Bittiya Sanstha Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 630
  },
  {
    "symbol": "SLBSL",
    "name": "Samudayik Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 605
  },
  {
    "symbol": "SLCF",
    "name": "Sanima Large Cap Fund",
    "instrumentType": "mutual_fund",
    "sector": "Mutual Fund",
    "status": "listed",
    "classification": "MUTUAL_FUND",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 1005
  },
  {
    "symbol": "SLI",
    "name": "Sanima Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "SNLI",
    "mergerEffectiveDate": "2023-07-07",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 736
  },
  {
    "symbol": "SLICL",
    "name": "Surya Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "SNLI",
    "mergerEffectiveDate": "2023-07-07",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 145
  },
  {
    "symbol": "SMATA",
    "name": "Samata Gharelu Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 539
  },
  {
    "symbol": "SMB",
    "name": "Support Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 607
  },
  {
    "symbol": "SMFBS",
    "name": "Swabhimaan Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 705
  },
  {
    "symbol": "SMH",
    "name": "Supermai Hydropower  Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1046
  },
  {
    "symbol": "SMHL",
    "name": "Super Madi Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1194
  },
  {
    "symbol": "SMJC",
    "name": "Sagarmatha Jalbidhyut Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1201
  },
  {
    "symbol": "SMPDA",
    "name": "Sampada Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1511
  },
  {
    "symbol": "SNLI",
    "name": "Sun Nepal Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 760
  },
  {
    "symbol": "SNORL",
    "name": "Snow Rivers Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1327
  },
  {
    "symbol": "SOHL",
    "name": "Solu Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1362
  },
  {
    "symbol": "SONA",
    "name": "Sonapur Minerals and Oil Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1193
  },
  {
    "symbol": "SOPL",
    "name": "Sopan Pharmaceuticals Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1216
  },
  {
    "symbol": "SPC",
    "name": "Samling Power Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1008
  },
  {
    "symbol": "SPDL",
    "name": "Synergy Power Development Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 617
  },
  {
    "symbol": "SPHL",
    "name": "Sayapatri Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 838
  },
  {
    "symbol": "SPIL",
    "name": "Siddhartha Premier Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1256
  },
  {
    "symbol": "SPL",
    "name": "Shuvam Power Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 611
  },
  {
    "symbol": "SRBL",
    "name": "Sunrise Bank Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "LXBL",
    "mergerEffectiveDate": "2023-07-14",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 23
  },
  {
    "symbol": "SRBLD83",
    "name": "10.25% SRBL Debenture 2083",
    "instrumentType": "debenture",
    "sector": "Corporate Debentures",
    "status": "listed",
    "classification": "DEBENTURE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SRLI",
    "name": "Sanima Reliance Life Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1266
  },
  {
    "symbol": "SRLIP",
    "name": "Sanima Reliance Life Insurance Limited Promoter Share",
    "instrumentType": "promoter_share",
    "sector": "Promoter Share",
    "status": "listed",
    "classification": "PROMOTER_SHARE",
    "isEligibleForCurrentActive": false
  },
  {
    "symbol": "SSHL",
    "name": "Shiva Shree Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 740
  },
  {
    "symbol": "STC",
    "name": "Salt Trading Corporation Limited",
    "instrumentType": "ordinary",
    "sector": "Trading",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 122
  },
  {
    "symbol": "SWASTIK",
    "name": "Swastik Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 915
  },
  {
    "symbol": "SWBBL",
    "name": "Swabalamban Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 176
  },
  {
    "symbol": "SWMF",
    "name": "Suryodaya Womi Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1156
  },
  {
    "symbol": "SYPNL",
    "name": "SY Panel Nepal Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1355
  },
  {
    "symbol": "TAMOR",
    "name": "Sanima Middle Tamor Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 829
  },
  {
    "symbol": "TPC",
    "name": "Terhathum Power Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 968
  },
  {
    "symbol": "TPKHL",
    "name": "Taksar Pikhuwa Khola Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 887
  },
  {
    "symbol": "TRH",
    "name": "Taragaon Regency Hotel Limited",
    "instrumentType": "ordinary",
    "sector": "Hotel & Tourism",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 96
  },
  {
    "symbol": "TSHL",
    "name": "Three Star Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 871
  },
  {
    "symbol": "TTL",
    "name": "Trade Tower Limited",
    "instrumentType": "ordinary",
    "sector": "Others",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1145
  },
  {
    "symbol": "TVCL",
    "name": "Trishuli Jal Vidhyut Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 540
  },
  {
    "symbol": "UAIL",
    "name": "United Ajod Insurance Limited",
    "instrumentType": "ordinary",
    "sector": "Non-Life Insurance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1281
  },
  {
    "symbol": "UHEWA",
    "name": "Upper Hewakhola Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 961
  },
  {
    "symbol": "ULBSL",
    "name": "Upakar Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 947
  },
  {
    "symbol": "ULHC",
    "name": "Upper Lohore Khola Hydropower Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1224
  },
  {
    "symbol": "ULI",
    "name": "Union Life Insurance Company Limited",
    "instrumentType": "ordinary",
    "sector": "Merged",
    "status": "merged",
    "classification": "MERGED",
    "mergerTargetSymbol": "SJLIC",
    "mergerEffectiveDate": "2023-05-09",
    "isEligibleForCurrentActive": false,
    "sharesansarId": 717
  },
  {
    "symbol": "UMHL",
    "name": "United Modi Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 585
  },
  {
    "symbol": "UMRH",
    "name": "United Idi-Mardi and R.B. Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 956
  },
  {
    "symbol": "UNHPL",
    "name": "Union Hydro Holdings Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 683
  },
  {
    "symbol": "UNL",
    "name": "Unilever Nepal Limited",
    "instrumentType": "ordinary",
    "sector": "Manufacturing and Processing",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 109
  },
  {
    "symbol": "UNLB",
    "name": "Unique Nepal Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 971
  },
  {
    "symbol": "UPCL",
    "name": "Universal Power Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 610
  },
  {
    "symbol": "UPPER",
    "name": "Upper Tamakoshi Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 498
  },
  {
    "symbol": "USHEC",
    "name": "Upper Solu Hydro Electric Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 746
  },
  {
    "symbol": "USHL",
    "name": "Upper Syange Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 752
  },
  {
    "symbol": "USLB",
    "name": "Unnati Sahakarya Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 967
  },
  {
    "symbol": "VLBS",
    "name": "Vijaya Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 464
  },
  {
    "symbol": "VLUCL",
    "name": "Vision Lumbini Urja Company Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1260
  },
  {
    "symbol": "WNLB",
    "name": "Wean Nepal Laghubitta Bittiya Sanstha Limited",
    "instrumentType": "ordinary",
    "sector": "Microfinance",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1140
  },
  {
    "symbol": "YMHL",
    "name": "Yambaling Hydropower Limited",
    "instrumentType": "ordinary",
    "sector": "Hydropower",
    "status": "listed",
    "classification": "ACTIVE_ORDINARY_EQUITY",
    "isEligibleForCurrentActive": true,
    "sharesansarId": 1320
  }
];

export const NEPSE_CLOSED_DAYS: string[] = ["2010-01-01","2010-01-08","2010-01-15","2010-01-22","2010-01-24","2010-01-29","2010-02-05","2010-02-12","2010-02-14","2010-02-19","2010-02-21","2010-02-22","2010-02-23","2010-02-24","2010-02-25","2010-02-26","2010-02-28","2010-03-05","2010-03-08","2010-03-12","2010-03-15","2010-03-19","2010-03-21","2010-03-24","2010-03-26","2010-04-02","2010-04-09","2010-04-14","2010-04-16","2010-04-23","2010-04-30","2010-05-02","2010-05-03","2010-05-04","2010-05-05","2010-05-06","2010-05-07","2010-05-14","2010-05-21","2010-05-27","2010-05-28","2010-06-04","2010-06-11","2010-06-16","2010-06-18","2010-06-24","2010-06-25","2010-06-27","2010-06-28","2010-07-02","2010-07-09","2010-07-21","2010-07-23","2010-07-30","2010-08-01","2010-08-02","2010-08-03","2010-08-04","2010-08-05","2010-08-06","2010-08-08","2010-08-09","2010-08-10","2010-08-11","2010-08-12","2010-08-13","2010-08-15","2010-08-16","2010-08-17","2010-08-18","2010-08-19","2010-08-20","2010-08-22","2010-08-23","2010-08-24","2010-08-25","2010-08-26","2010-08-27","2010-08-29","2010-08-30","2010-08-31","2010-09-01","2010-09-03","2010-09-05","2010-09-06","2010-09-10","2010-09-17","2010-09-22","2010-09-24","2010-10-01","2010-10-08","2010-10-14","2010-10-15","2010-10-17","2010-10-18","2010-10-19","2010-10-22","2010-10-29","2010-11-05","2010-11-07","2010-11-08","2010-11-12","2010-11-17","2010-11-19","2010-11-26","2010-12-03","2010-12-10","2010-12-17","2010-12-21","2010-12-24","2010-12-30","2010-12-31","2011-01-07","2011-01-14","2011-01-21","2011-01-25","2011-01-26","2011-01-27","2011-01-28","2011-01-30","2011-02-04","2011-02-11","2011-02-18","2011-02-25","2011-03-01","2011-03-02","2011-03-04","2011-03-06","2011-03-08","2011-03-11","2011-03-18","2011-03-21","2011-03-22","2011-03-23","2011-04-01","2011-04-03","2011-04-08","2011-04-12","2011-04-14","2011-04-15","2011-04-22","2011-04-24","2011-04-29","2011-05-01","2011-05-06","2011-05-13","2011-05-17","2011-05-20","2011-05-27","2011-05-29","2011-06-03","2011-06-10","2011-06-17","2011-06-22","2011-06-24","2011-06-28","2011-07-01","2011-07-08","2011-07-15","2011-07-22","2011-07-29","2011-08-05","2011-08-12","2011-08-14","2011-08-19","2011-08-21","2011-08-26","2011-08-31","2011-09-02","2011-09-09","2011-09-11","2011-09-16","2011-09-23","2011-09-28","2011-09-30","2011-10-03","2011-10-04","2011-10-05","2011-10-06","2011-10-07","2011-10-11","2011-10-14","2011-10-21","2011-10-26","2011-10-27","2011-10-28","2011-11-01","2011-11-04","2011-11-07","2011-11-11","2011-11-18","2011-11-25","2011-11-30","2011-12-02","2011-12-09","2011-12-16","2011-12-23","2011-12-25","2011-12-30","2012-01-06","2012-01-13","2012-01-15","2012-01-20","2012-01-24","2012-01-27","2012-01-30","2012-02-03","2012-02-10","2012-02-17","2012-02-19","2012-02-20","2012-02-22","2012-02-24","2012-03-02","2012-03-07","2012-03-08","2012-03-09","2012-03-16","2012-03-22","2012-03-23","2012-03-30","2012-04-06","2012-04-13","2012-04-20","2012-04-23","2012-04-27","2012-05-01","2012-05-04","2012-05-06","2012-05-11","2012-05-18","2012-05-25","2012-05-28","2012-06-01","2012-06-08","2012-06-15","2012-06-22","2012-06-24","2012-06-29","2012-07-06","2012-07-13","2012-07-20","2012-07-27","2012-08-02","2012-08-03","2012-08-09","2012-08-10","2012-08-17","2012-08-20","2012-08-24","2012-08-31","2012-09-07","2012-09-14","2012-09-21","2012-09-27","2012-09-28","2012-10-05","2012-10-12","2012-10-16","2012-10-19","2012-10-21","2012-10-22","2012-10-23","2012-10-24","2012-10-25","2012-10-26","2012-10-28","2012-10-29","2012-11-02","2012-11-09","2012-11-13","2012-11-14","2012-11-15","2012-11-16","2012-11-19","2012-11-23","2012-11-30","2012-12-07","2012-12-14","2012-12-21","2012-12-25","2012-12-28","2012-12-30","2013-01-04","2013-01-11","2013-01-14","2013-01-18","2013-01-25","2013-01-29","2013-02-01","2013-02-08","2013-02-11","2013-02-15","2013-02-18","2013-02-22","2013-03-01","2013-03-08","2013-03-10","2013-03-12","2013-03-15","2013-03-22","2013-03-26","2013-03-29","2013-04-05","2013-04-10","2013-04-12","2013-04-14","2013-04-19","2013-04-24","2013-04-26","2013-05-01","2013-05-03","2013-05-10","2013-05-17","2013-05-24","2013-05-29","2013-05-31","2013-06-07","2013-06-14","2013-06-21","2013-06-28","2013-07-05","2013-07-12","2013-07-19","2013-07-26","2013-08-02","2013-08-09","2013-08-16","2013-08-21","2013-08-22","2013-08-23","2013-08-28","2013-08-30","2013-09-06","2013-09-13","2013-09-18","2013-09-20","2013-09-27","2013-10-04","2013-10-11","2013-10-13","2013-10-14","2013-10-15","2013-10-16","2013-10-18","2013-10-25","2013-11-01","2013-11-03","2013-11-04","2013-11-05","2013-11-08","2013-11-15","2013-11-17","2013-11-18","2013-11-19","2013-11-20","2013-11-22","2013-11-29","2013-12-06","2013-12-13","2013-12-17","2013-12-20","2013-12-25","2013-12-27","2013-12-30","2014-01-03","2014-01-10","2014-01-15","2014-01-17","2014-01-24","2014-01-30","2014-01-31","2014-02-05","2014-02-07","2014-02-14","2014-02-19","2014-02-21","2014-02-27","2014-02-28","2014-03-02","2014-03-07","2014-03-14","2014-03-16","2014-03-21","2014-03-28","2014-03-30","2014-04-04","2014-04-08","2014-04-11","2014-04-14","2014-04-18","2014-04-24","2014-04-25","2014-05-01","2014-05-02","2014-05-09","2014-05-14","2014-05-16","2014-05-23","2014-05-29","2014-05-30","2014-06-06","2014-06-13","2014-06-20","2014-06-22","2014-06-27","2014-07-04","2014-07-11","2014-07-18","2014-07-25","2014-07-29","2014-08-01","2014-08-08","2014-08-10","2014-08-11","2014-08-15","2014-08-17","2014-08-22","2014-08-29","2014-09-02","2014-09-05","2014-09-08","2014-09-12","2014-09-19","2014-09-25","2014-09-26","2014-10-01","2014-10-02","2014-10-03","2014-10-05","2014-10-06","2014-10-07","2014-10-10","2014-10-17","2014-10-23","2014-10-24","2014-10-29","2014-10-31","2014-11-07","2014-11-14","2014-11-21","2014-11-26","2014-11-27","2014-11-28","2014-12-05","2014-12-12","2014-12-19","2014-12-25","2014-12-26","2014-12-30","2015-01-02","2015-01-09","2015-01-15","2015-01-16","2015-01-21","2015-01-23","2015-01-30","2015-02-06","2015-02-13","2015-02-17","2015-02-19","2015-02-20","2015-02-27","2015-03-05","2015-03-06","2015-03-08","2015-03-13","2015-03-20","2015-03-27","2015-04-03","2015-04-10","2015-04-14","2015-04-17","2015-04-24","2015-04-26","2015-04-27","2015-04-28","2015-04-29","2015-04-30","2015-05-01","2015-05-03","2015-05-04","2015-05-05","2015-05-06","2015-05-07","2015-05-08","2015-05-10","2015-05-11","2015-05-12","2015-05-13","2015-05-14","2015-05-15","2015-05-17","2015-05-18","2015-05-19","2015-05-20","2015-05-21","2015-05-22","2015-05-29","2015-06-05","2015-06-12","2015-06-19","2015-06-26","2015-07-03","2015-07-10","2015-07-17","2015-07-19","2015-07-20","2015-07-21","2015-07-24","2015-07-31","2015-08-07","2015-08-14","2015-08-21","2015-08-28","2015-08-30","2015-09-04","2015-09-11","2015-09-18","2015-09-20","2015-09-21","2015-09-25","2015-09-27","2015-10-02","2015-10-09","2015-10-12","2015-10-13","2015-10-16","2015-10-20","2015-10-21","2015-10-22","2015-10-23","2015-10-26","2015-10-30","2015-11-06","2015-11-11","2015-11-12","2015-11-13","2015-11-17","2015-11-20","2015-11-27","2015-12-04","2015-12-11","2015-12-18","2015-12-25","2015-12-30","2016-01-01","2016-01-08","2016-01-15","2016-01-22","2016-01-29","2016-02-05","2016-02-09","2016-02-10","2016-02-12","2016-02-19","2016-02-26","2016-03-04","2016-03-07","2016-03-08","2016-03-09","2016-03-11","2016-03-18","2016-03-22","2016-03-25","2016-04-01","2016-04-07","2016-04-08","2016-04-13","2016-04-15","2016-04-22","2016-04-29","2016-05-01","2016-05-06","2016-05-13","2016-05-20","2016-05-27","2016-06-03","2016-06-10","2016-06-17","2016-06-24","2016-07-01","2016-07-07","2016-07-08","2016-07-15","2016-07-22","2016-07-24","2016-07-29","2016-08-05","2016-08-12","2016-08-18","2016-08-19","2016-08-25","2016-08-26","2016-09-02","2016-09-09","2016-09-13","2016-09-15","2016-09-16","2016-09-19","2016-09-23","2016-09-30","2016-10-07","2016-10-09","2016-10-10","2016-10-11","2016-10-12","2016-10-13","2016-10-14","2016-10-21","2016-10-28","2016-10-30","2016-10-31","2016-11-01","2016-11-02","2016-11-04","2016-11-06","2016-11-11","2016-11-18","2016-11-25","2016-12-02","2016-12-09","2016-12-13","2016-12-16","2016-12-23","2016-12-25","2016-12-30","2017-01-06","2017-01-13","2017-01-20","2017-01-27","2017-01-29","2017-02-03","2017-02-10","2017-02-17","2017-02-24","2017-02-27","2017-03-03","2017-03-08","2017-03-10","2017-03-12","2017-03-17","2017-03-24","2017-03-27","2017-03-31","2017-04-05","2017-04-07","2017-04-14","2017-04-17","2017-04-21","2017-04-28","2017-05-01","2017-05-05","2017-05-10","2017-05-12","2017-05-14","2017-05-19","2017-05-25","2017-05-26","2017-05-29","2017-06-02","2017-06-09","2017-06-16","2017-06-23","2017-06-26","2017-06-29","2017-06-30","2017-07-07","2017-07-14","2017-07-21","2017-07-28","2017-08-04","2017-08-08","2017-08-11","2017-08-14","2017-08-18","2017-08-25","2017-08-29","2017-09-01","2017-09-03","2017-09-05","2017-09-08","2017-09-15","2017-09-19","2017-09-21","2017-09-22","2017-09-27","2017-09-28","2017-09-29","2017-10-01","2017-10-02","2017-10-05","2017-10-06","2017-10-13","2017-10-19","2017-10-20","2017-10-26","2017-10-27","2017-11-03","2017-11-10","2017-11-17","2017-11-24","2017-12-01","2017-12-03","2017-12-07","2017-12-08","2017-12-15","2017-12-22","2017-12-25","2017-12-29","2018-01-05","2018-01-11","2018-01-12","2018-01-15","2018-01-18","2018-01-19","2018-01-26","2018-01-30","2018-02-02","2018-02-09","2018-02-13","2018-02-16","2018-02-19","2018-02-23","2018-03-01","2018-03-02","2018-03-08","2018-03-09","2018-03-16","2018-03-23","2018-03-25","2018-03-30","2018-04-06","2018-04-13","2018-04-20","2018-04-27","2018-04-30","2018-05-01","2018-05-04","2018-05-11","2018-05-13","2018-05-18","2018-05-25","2018-06-01","2018-06-05","2018-06-08","2018-06-15","2018-06-22","2018-06-29","2018-07-06","2018-07-13","2018-07-20","2018-07-27","2018-08-03","2018-08-10","2018-08-17","2018-08-24","2018-08-27","2018-08-31","2018-09-07","2018-09-14","2018-09-19","2018-09-21","2018-09-24","2018-09-28","2018-10-05","2018-10-12","2018-10-16","2018-10-17","2018-10-18","2018-10-19","2018-10-26","2018-11-02","2018-11-07","2018-11-08","2018-11-09","2018-11-16","2018-11-23","2018-11-30","2018-12-07","2018-12-14","2018-12-21","2018-12-28","2019-01-04","2019-01-11","2019-01-18","2019-01-25","2019-02-01","2019-02-08","2019-02-15","2019-02-22","2019-02-28","2019-03-01","2019-03-04","2019-03-08","2019-03-15","2019-03-20","2019-03-22","2019-03-29","2019-04-05","2019-04-12","2019-04-14","2019-04-19","2019-04-26","2019-05-01","2019-05-03","2019-05-10","2019-05-17","2019-05-24","2019-05-31","2019-06-05","2019-06-07","2019-06-09","2019-06-14","2019-06-21","2019-06-28","2019-07-05","2019-07-12","2019-07-19","2019-07-26","2019-08-02","2019-08-09","2019-08-16","2019-08-23","2019-08-30","2019-09-06","2019-09-13","2019-09-20","2019-09-27","2019-10-04","2019-10-06","2019-10-07","2019-10-08","2019-10-09","2019-10-11","2019-10-13","2019-10-18","2019-10-25","2019-10-27","2019-10-28","2019-10-29","2019-10-30","2019-11-01","2019-11-08","2019-11-15","2019-11-22","2019-11-29","2019-12-06","2019-12-13","2019-12-20","2019-12-27","2020-01-03","2020-01-10","2020-01-17","2020-01-24","2020-01-31","2020-02-07","2020-02-14","2020-02-21","2020-02-28","2020-03-06","2020-03-08","2020-03-09","2020-03-13","2020-03-20","2020-03-23","2020-03-24","2020-03-25","2020-03-26","2020-03-27","2020-03-29","2020-03-30","2020-03-31","2020-04-01","2020-04-02","2020-04-03","2020-04-05","2020-04-06","2020-04-07","2020-04-08","2020-04-09","2020-04-10","2020-04-12","2020-04-13","2020-04-14","2020-04-15","2020-04-16","2020-04-17","2020-04-19","2020-04-20","2020-04-21","2020-04-22","2020-04-23","2020-04-24","2020-04-26","2020-04-27","2020-04-28","2020-04-29","2020-04-30","2020-05-01","2020-05-03","2020-05-04","2020-05-05","2020-05-06","2020-05-07","2020-05-08","2020-05-10","2020-05-11","2020-05-14","2020-05-15","2020-05-17","2020-05-18","2020-05-19","2020-05-20","2020-05-21","2020-05-22","2020-05-24","2020-05-25","2020-05-26","2020-05-27","2020-05-28","2020-05-29","2020-05-31","2020-06-01","2020-06-02","2020-06-03","2020-06-04","2020-06-05","2020-06-07","2020-06-08","2020-06-09","2020-06-10","2020-06-11","2020-06-12","2020-06-14","2020-06-15","2020-06-16","2020-06-17","2020-06-18","2020-06-19","2020-06-21","2020-06-22","2020-06-23","2020-06-24","2020-06-25","2020-06-26","2020-06-28","2020-07-03","2020-07-10","2020-07-17","2020-07-24","2020-07-31","2020-08-04","2020-08-07","2020-08-14","2020-08-21","2020-08-28","2020-09-01","2020-09-04","2020-09-11","2020-09-18","2020-09-25","2020-10-02","2020-10-09","2020-10-16","2020-10-23","2020-10-25","2020-10-26","2020-10-27","2020-10-30","2020-11-06","2020-11-13","2020-11-15","2020-11-16","2020-11-17","2020-11-20","2020-11-27","2020-12-04","2020-12-11","2020-12-18","2020-12-25","2021-01-01","2021-01-08","2021-01-14","2021-01-15","2021-01-22","2021-01-29","2021-02-05","2021-02-12","2021-02-19","2021-02-26","2021-03-05","2021-03-08","2021-03-11","2021-03-12","2021-03-19","2021-03-26","2021-03-28","2021-04-02","2021-04-09","2021-04-11","2021-04-14","2021-04-16","2021-04-23","2021-04-30","2021-05-07","2021-05-14","2021-05-21","2021-05-26","2021-05-28","2021-06-04","2021-06-11","2021-06-18","2021-06-25","2021-07-02","2021-07-09","2021-07-16","2021-07-21","2021-07-23","2021-07-30","2021-08-06","2021-08-13","2021-08-20","2021-08-22","2021-08-23","2021-08-27","2021-08-30","2021-09-03","2021-09-10","2021-09-17","2021-09-19","2021-09-24","2021-10-01","2021-10-07","2021-10-08","2021-10-12","2021-10-13","2021-10-14","2021-10-15","2021-10-22","2021-10-29","2021-11-04","2021-11-05","2021-11-07","2021-11-10","2021-11-12","2021-11-19","2021-11-26","2021-12-03","2021-12-10","2021-12-17","2021-12-19","2021-12-24","2021-12-30","2021-12-31","2022-01-07","2022-01-14","2022-01-21","2022-01-28","2022-02-02","2022-02-04","2022-02-11","2022-02-18","2022-02-25","2022-03-01","2022-03-03","2022-03-04","2022-03-08","2022-03-11","2022-03-17","2022-03-18","2022-03-25","2022-04-01","2022-04-08","2022-04-10","2022-04-14","2022-04-15","2022-04-22","2022-04-29","2022-05-01","2022-05-03","2022-05-06","2022-05-13","2022-05-15","2022-05-16","2022-05-22","2022-05-29","2022-06-05","2022-06-12","2022-07-10","2022-08-12","2022-08-19","2022-09-09","2022-09-19","2022-09-23","2022-09-26","2022-09-30","2022-10-02","2022-10-03","2022-10-04","2022-10-05","2022-10-06","2022-10-07","2022-10-14","2022-10-18","2022-10-21","2022-10-24","2022-10-25","2022-10-26","2022-10-27","2022-10-28","2022-10-30","2022-11-04","2022-11-11","2022-11-18","2022-11-20","2022-11-21","2022-11-25","2022-12-02","2022-12-08","2022-12-09","2022-12-16","2022-12-23","2022-12-25","2022-12-30","2023-01-06","2023-01-11","2023-01-13","2023-01-15","2023-01-16","2023-01-20","2023-01-22","2023-01-27","2023-02-03","2023-02-10","2023-02-13","2023-02-17","2023-02-19","2023-02-21","2023-02-24","2023-03-03","2023-03-06","2023-03-08","2023-03-10","2023-03-17","2023-03-21","2023-03-24","2023-03-31","2023-04-07","2023-04-14","2023-04-21","2023-04-28","2023-05-01","2023-05-05","2023-05-12","2023-05-19","2023-05-25","2023-05-26","2023-05-29","2023-06-02","2023-06-09","2023-06-16","2023-06-23","2023-06-29","2023-06-30","2023-07-07","2023-07-14","2023-07-21","2023-07-28","2023-08-04","2023-08-11","2023-08-18","2023-08-25","2023-08-31","2023-09-01","2023-09-06","2023-09-08","2023-09-14","2023-09-15","2023-09-20","2023-09-22","2023-09-28","2023-09-29","2023-10-06","2023-10-13","2023-10-15","2023-10-20","2023-10-22","2023-10-23","2023-10-24","2023-10-25","2023-10-26","2023-10-27","2023-11-03","2023-11-10","2023-11-12","2023-11-13","2023-11-14","2023-11-15","2023-11-16","2023-11-17","2023-11-19","2023-11-24","2023-12-01","2023-12-08","2023-12-15","2023-12-22","2023-12-25","2023-12-26","2023-12-29","2023-12-31","2024-01-05","2024-01-12","2024-01-15","2024-01-19","2024-01-26","2024-02-02","2024-02-09","2024-02-16","2024-02-19","2024-02-23","2024-03-01","2024-03-08","2024-03-11","2024-03-15","2024-03-22","2024-03-24","2024-03-29","2024-04-05","2024-04-08","2024-04-11","2024-04-12","2024-04-17","2024-04-19","2024-04-23","2024-04-26","2024-05-01","2024-05-03","2024-05-10","2024-05-17","2024-05-23","2024-05-24","2024-05-28","2024-05-31","2024-06-07","2024-06-14","2024-06-17","2024-06-21","2024-06-28","2024-07-05","2024-07-12","2024-07-19","2024-07-26","2024-08-02","2024-08-04","2024-08-09","2024-08-16","2024-08-19","2024-08-20","2024-08-23","2024-08-26","2024-08-30","2024-09-06","2024-09-13","2024-09-17","2024-09-19","2024-09-20","2024-09-27","2024-10-03","2024-10-04","2024-10-10","2024-10-11","2024-10-13","2024-10-14","2024-10-18","2024-10-25","2024-10-31","2024-11-01","2024-11-03","2024-11-04","2024-11-07","2024-11-08","2024-11-15","2024-11-18","2024-11-22","2024-11-29","2024-12-06","2024-12-13","2024-12-15","2024-12-20","2024-12-25","2024-12-27","2024-12-30","2025-01-03","2025-01-10","2025-01-14","2025-01-17","2025-01-24","2025-01-29","2025-01-30","2025-01-31","2025-02-07","2025-02-14","2025-02-19","2025-02-21","2025-02-26","2025-02-28","2025-03-07","2025-03-13","2025-03-14","2025-03-21","2025-03-28","2025-03-31","2025-04-04","2025-04-06","2025-04-11","2025-04-14","2025-04-18","2025-04-25","2025-05-01","2025-05-02","2025-05-09","2025-05-12","2025-05-16","2025-05-23","2025-05-29","2025-05-30","2025-06-01","2025-06-06","2025-06-13","2025-06-20","2025-06-27","2025-07-04","2025-07-11","2025-07-18","2025-07-25","2025-08-01","2025-08-08","2025-08-10","2025-08-15","2025-08-22","2025-08-29","2025-09-05","2025-09-09","2025-09-10","2025-09-11","2025-09-12","2025-09-14","2025-09-15","2025-09-16","2025-09-17","2025-09-19","2025-09-22","2025-09-26","2025-09-29","2025-09-30","2025-10-01","2025-10-02","2025-10-03","2025-10-05","2025-10-06","2025-10-10","2025-10-17","2025-10-20","2025-10-21","2025-10-22","2025-10-23","2025-10-24","2025-10-27","2025-10-31","2025-11-07","2025-11-14","2025-11-21","2025-11-28","2025-12-04","2025-12-05","2025-12-12","2025-12-19","2025-12-25","2025-12-26","2025-12-30","2026-01-02","2026-01-09","2026-01-11","2026-01-15","2026-01-16","2026-01-19","2026-01-23","2026-01-30","2026-02-06","2026-02-13","2026-02-15","2026-02-18","2026-02-19","2026-02-20","2026-02-27","2026-03-02","2026-03-04","2026-03-05","2026-03-06","2026-03-08","2026-03-13","2026-03-18","2026-03-20","2026-03-27","2026-04-03","2026-04-12","2026-04-14","2026-04-19","2026-04-26","2026-05-01","2026-05-03","2026-05-10","2026-05-17","2026-05-24","2026-05-28","2026-05-29","2026-05-31","2026-06-07","2026-06-14","2026-06-21","2026-06-28","2026-07-05","2026-07-12","2026-07-19","2026-07-24","2026-07-26","2026-08-02","2026-08-09","2026-08-16","2026-08-23","2026-08-28","2026-08-30","2026-09-04","2026-09-06","2026-09-08"];
