/**
 * src/data/liveBarsCache.ts
 *
 * Isolated in-memory bars cache module.
 * Provides mode-aware synchronous access to full historical OHLCV bar series.
 *
 * In 'SUPABASE' / 'REAL_DATA' mode:
 *   Bulk fetches and paginates the complete daily_prices table (~300,909 rows)
 *   from Supabase, grouped by symbol into OHLCVBar[].
 *
 * In 'MOCK_DATA' mode:
 *   Populates the cache using getNormalizedStockBars() for each symbol in normalizedCompanies,
 *   preserving mock testing behavior byte-for-byte.
 */

import { supabase } from '../lib/supabaseClient';
import { providerRegistry } from '../providers/providerRegistry';
import { OHLCVBar } from '../types/technicalIndicators';
import { CompanyMaster, MarketIndexRecord } from '../types/dataInfrastructure';
import { normalizedCompanies, getNormalizedStockBars, normalizedIndices } from './normalizedMasterData';
import { companyRepository } from '../repositories/companyRepository';
import { marketRepository } from '../repositories/marketRepository';

const barsCache = new Map<string, OHLCVBar[]>();
let cacheReady = false;
let inFlightPromise: Promise<void> | null = null;

const companyCache = new Map<string, CompanyMaster>();
let companyCacheReady = false;
let companyInFlightPromise: Promise<void> | null = null;

let indexCache: MarketIndexRecord[] = [];
let indexCacheReady = false;
let indexInFlightPromise: Promise<void> | null = null;

/**
 * Checks whether the cache has been successfully initialized with data.
 */
export function isCacheReady(): boolean {
  return cacheReady;
}

/**
 * Checks whether all live data caches (bars, companies, indices) are ready.
 */
export function isLiveDataReady(): boolean {
  return cacheReady && companyCacheReady && indexCacheReady;
}

/**
 * Clears the bars cache and resets the readiness status.
 */
export function clearBarsCache(): void {
  barsCache.clear();
  cacheReady = false;
  inFlightPromise = null;
}

/**
 * Clears all three caches (bars, companies, indices) and resets their ready flags.
 */
export function clearLiveDataCaches(): void {
  clearBarsCache();
  companyCache.clear();
  companyCacheReady = false;
  companyInFlightPromise = null;
  indexCache = [];
  indexCacheReady = false;
  indexInFlightPromise = null;
}

/**
 * Returns the list of all tradeable equity symbols currently held in the cache.
 * Synchronous.
 * In SUPABASE mode: 385 verified equity symbols (intersected with companyCache/equity_companies, excluding 52 debentures).
 * In MOCK_DATA mode: 17 normalized mock symbols.
 */
export function getCachedSymbols(): string[] {
  if (companyCacheReady && companyCache.size > 0) {
    return Array.from(companyCache.keys());
  }
  if (barsCache.size > 0) {
    return Array.from(barsCache.keys());
  }
  return normalizedCompanies.map(c => c.symbol.toUpperCase().trim());
}

/**
 * Returns all symbols currently loaded in the bars cache (all 437 traded symbols in Supabase mode).
 */
export function getAllTradedSymbols(): string[] {
  if (barsCache.size > 0) {
    return Array.from(barsCache.keys());
  }
  return getCachedSymbols();
}

/**
 * Returns the total count of historical bars across all symbols in the cache.
 */
export function getBarsCacheTotalRows(): number {
  let count = 0;
  for (const bars of barsCache.values()) {
    count += bars.length;
  }
  return count;
}

/**
 * Returns the number of distinct symbols currently loaded in the bars cache.
 */
export function getBarsCacheSymbolCount(): number {
  return barsCache.size;
}

/**
 * Returns the OHLCVBar array for a given symbol from the cache.
 * Synchronous.
 * Returns normalized bars as fallback if symbol is not yet loaded in barsCache.
 */
export function getCachedBars(symbol: string): OHLCVBar[] {
  const normalizedSymbol = (symbol || '').toUpperCase().trim();
  const bars = barsCache.get(normalizedSymbol);
  if (bars && bars.length > 0) {
    return [...bars];
  }

  // Graceful fallback to normalized mock data if available for this symbol
  const fallbackBars = getNormalizedStockBars(normalizedSymbol);
  if (fallbackBars && fallbackBars.length > 0) {
    return [...fallbackBars];
  }

  return [];
}

/**
 * Synchronous getter for all cached companies.
 * In SUPABASE mode: returns the companies fetched from Supabase.
 * In MOCK_DATA mode: returns the mock companies.
 */
export function getCachedCompanies(): CompanyMaster[] {
  if (companyCache.size > 0) {
    return Array.from(companyCache.values());
  }
  return [...normalizedCompanies];
}

/**
 * Synchronous getter for company metadata.
 * Returns null if not found.
 */
export function getCachedCompany(symbol: string): CompanyMaster | null {
  const clean = (symbol || '').toUpperCase().trim();
  if (companyCache.size > 0 && companyCache.has(clean)) {
    return companyCache.get(clean) || null;
  }
  const mockMatch = normalizedCompanies.find(m => m.symbol.toUpperCase() === clean);
  return mockMatch || null;
}

/**
 * Synchronous getter for market indices.
 */
export function getCachedIndices(): MarketIndexRecord[] {
  if (indexCache.length > 0) {
    return [...indexCache];
  }
  return [...normalizedIndices];
}

/**
 * Asynchronously initializes the company metadata cache.
 */
export async function initializeCompanyCache(): Promise<void> {
  if (companyInFlightPromise) {
    return companyInFlightPromise;
  }

  companyInFlightPromise = (async () => {
    companyCache.clear();
    companyCacheReady = false;
    try {
      const companies = await companyRepository.getAllCompanies();
      for (const comp of companies) {
        if (!comp.symbol) continue;
        const sym = comp.symbol.toUpperCase().trim();
        const mockMatch = normalizedCompanies.find(m => m.symbol.toUpperCase() === sym);
        if (mockMatch) {
          if (!comp.company_name || comp.company_name === sym) {
            comp.company_name = mockMatch.company_name;
          }
          if (!comp.sector || comp.sector === 'Others') {
            comp.sector = mockMatch.sector || mockMatch.sector_id;
          }
          if (!comp.sector_id || comp.sector_id === 'Others') {
            comp.sector_id = mockMatch.sector_id;
          }
        }
        if (!comp.sector && comp.sector_id) {
          comp.sector = comp.sector_id;
        }
        companyCache.set(sym, comp);
      }
      companyCacheReady = true;
      console.log(`[liveBarsCache] Company cache initialized with ${companyCache.size} companies.`);
    } catch (err: any) {
      console.warn('[liveBarsCache] Failed to initialize company cache from provider, using normalized fallback:', err?.message || err);
      for (const comp of normalizedCompanies) {
        companyCache.set(comp.symbol.toUpperCase().trim(), comp);
      }
      companyCacheReady = true;
    }
  })();

  try {
    await companyInFlightPromise;
  } finally {
    companyInFlightPromise = null;
  }
}

/**
 * Asynchronously initializes the market index history cache.
 */
export async function initializeIndexCache(): Promise<void> {
  if (indexInFlightPromise) {
    return indexInFlightPromise;
  }

  indexInFlightPromise = (async () => {
    indexCache = [];
    indexCacheReady = false;
    try {
      const indices = await marketRepository.getIndices();
      indexCache = indices && indices.length > 0 ? indices : [...normalizedIndices];
      indexCacheReady = true;
      console.log(`[liveBarsCache] Index cache initialized with ${indexCache.length} index rows.`);
    } catch (err: any) {
      console.warn('[liveBarsCache] Failed to initialize index cache from provider, using normalized fallback:', err?.message || err);
      indexCache = [...normalizedIndices];
      indexCacheReady = true;
    }
  })();

  try {
    await indexInFlightPromise;
  } finally {
    indexInFlightPromise = null;
  }
}

/**
 * Orchestrator: runs initializeBarsCache, initializeCompanyCache, and initializeIndexCache
 * in parallel via Promise.allSettled to guarantee maximum resilience.
 */
export async function initializeLiveDataCaches(): Promise<void> {
  console.log('[liveBarsCache] Initializing all live data caches (bars, companies, indices)...');
  await Promise.allSettled([
    initializeBarsCache(),
    initializeCompanyCache(),
    initializeIndexCache()
  ]);

  let totalBars = 0;
  for (const bars of barsCache.values()) {
    totalBars += bars.length;
  }
  console.log(`[liveBarsCache] initializeLiveDataCaches complete: ${barsCache.size} symbols, ${totalBars} bars, ${companyCache.size} companies, ${indexCache.length} index rows.`);
}

/**
 * Asynchronously initializes the bars cache according to the active providerRegistry mode.
 * Deduplicates concurrent calls via a shared in-flight promise.
 */
export async function initializeBarsCache(): Promise<void> {
  if (inFlightPromise) {
    return inFlightPromise;
  }

  inFlightPromise = (async () => {
    // Reset cache state before initializing
    barsCache.clear();
    cacheReady = false;

    const mode = providerRegistry.getMode();

    if (mode === 'MOCK_DATA') {
      try {
        console.log('[liveBarsCache] Initializing bars cache in MOCK_DATA mode...');
        for (const company of normalizedCompanies) {
          const sym = company.symbol.toUpperCase().trim();
          const bars = getNormalizedStockBars(sym);
          const sorted = [...bars].sort((a, b) => a.date.localeCompare(b.date));
          barsCache.set(sym, sorted);
        }
        cacheReady = true;
        console.log(`[liveBarsCache] MOCK_DATA cache initialized with ${barsCache.size} symbols.`);
      } catch (err: any) {
        console.error('[liveBarsCache] Failed to initialize MOCK_DATA bars cache:', err);
        barsCache.clear();
        cacheReady = false;
      }
      return;
    }

    // SUPABASE or live mode: Fetch complete daily_prices table with resilient concurrent pagination
    try {
      console.log(`[liveBarsCache] Initializing bars cache from Supabase daily_prices table in ${mode} mode...`);

      // 1. Query exact count to determine total pages
      const { count, error: countErr } = await supabase
        .from('daily_prices')
        .select('*', { count: 'exact', head: true });

      const PAGE_SIZE = 1000;
      const totalRowsCount = !countErr && typeof count === 'number' && count > 0 ? count : 300909;
      const numPages = Math.ceil(totalRowsCount / PAGE_SIZE);
      console.log(`[liveBarsCache] daily_prices target: ${totalRowsCount} rows across ${numPages} pages.`);

      const tempGrouped = new Map<string, OHLCVBar[]>();
      let totalFetched = 0;

      // Helper function to fetch a single page with retry logic
      const fetchPageWithRetry = async (pageIdx: number, retries = 2): Promise<any[]> => {
        const start = pageIdx * PAGE_SIZE;
        const end = start + PAGE_SIZE - 1;
        for (let attempt = 0; attempt <= retries; attempt++) {
          try {
            const { data, error } = await supabase
              .from('daily_prices')
              .select('symbol, date, open, high, low, close, volume')
              .range(start, end);
            if (error) throw error;
            return data || [];
          } catch (err: any) {
            if (attempt === retries) {
              console.warn(`[liveBarsCache] Page ${pageIdx} fetch failed after ${retries} retries:`, err?.message || err);
              return [];
            }
            await new Promise(r => setTimeout(r, 200 * (attempt + 1)));
          }
        }
        return [];
      };

      // Concurrent batch fetching with window size of 15 parallel requests
      const CONCURRENCY = 15;
      for (let i = 0; i < numPages; i += CONCURRENCY) {
        const batchPageIndices: number[] = [];
        for (let p = i; p < Math.min(i + CONCURRENCY, numPages); p++) {
          batchPageIndices.push(p);
        }

        const pageResults = await Promise.all(
          batchPageIndices.map(p => fetchPageWithRetry(p))
        );

        for (const rows of pageResults) {
          totalFetched += rows.length;
          for (const row of rows) {
            if (!row.symbol || !row.date) continue;
            const sym = String(row.symbol).toUpperCase().trim();
            let list = tempGrouped.get(sym);
            if (!list) {
              list = [];
              tempGrouped.set(sym, list);
            }

            const close = Number(row.close ?? 0);
            const volume = Number(row.volume ?? 0);

            list.push({
              date: String(row.date),
              open: Number(row.open ?? close),
              high: Number(row.high ?? close),
              low: Number(row.low ?? close),
              close,
              volume,
              turnover: close * volume,
            });
          }
        }
      }

      // Sort every symbol's bar list strictly by date ascending
      for (const [sym, bars] of tempGrouped.entries()) {
        bars.sort((a, b) => a.date.localeCompare(b.date));
        barsCache.set(sym, bars);
      }

      // Fill in any normalized benchmark symbols if they were missing from the database
      for (const company of normalizedCompanies) {
        const sym = company.symbol.toUpperCase().trim();
        if (!barsCache.has(sym)) {
          const mockBars = getNormalizedStockBars(sym);
          const sorted = [...mockBars].sort((a, b) => a.date.localeCompare(b.date));
          barsCache.set(sym, sorted);
        }
      }

      cacheReady = true;
      let totalBarRows = 0;
      for (const bars of barsCache.values()) {
        totalBarRows += bars.length;
      }
      console.log(`[liveBarsCache] Supabase bars fetch complete. Total rows fetched from DB: ${totalFetched}. Total bars stored: ${totalBarRows} across ${barsCache.size} traded symbols in barsCache.`);
    } catch (err: any) {
      console.warn('[liveBarsCache] Supabase bars fetch failed, activating fallback dataset:', err?.message || err);
      // Populate normalized stock bars so app remains completely functional
      for (const company of normalizedCompanies) {
        const sym = company.symbol.toUpperCase().trim();
        const bars = getNormalizedStockBars(sym);
        const sorted = [...bars].sort((a, b) => a.date.localeCompare(b.date));
        barsCache.set(sym, sorted);
      }
      cacheReady = true;
    }
  })();

  try {
    await inFlightPromise;
  } finally {
    inFlightPromise = null;
  }
}
