import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Read configuration from environment variables
const metaEnv = (typeof import.meta !== 'undefined' && (import.meta as any).env) || {};
const procEnv = (typeof process !== 'undefined' && process.env) || {};

export const DEFAULT_SUPABASE_URL = 'https://tbeznjlzyinoaorcovis.supabase.co';

const rawUrl = metaEnv.VITE_SUPABASE_URL || procEnv.VITE_SUPABASE_URL || DEFAULT_SUPABASE_URL;
// Ensure no trailing slash or /rest/v1/ is appended to the root Supabase project URL
export const supabaseUrl = rawUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');

// Read ONLY from VITE_SUPABASE_ANON_KEY — do NOT hardcode anon key fallback literal in source
const rawAnonKey = metaEnv.VITE_SUPABASE_ANON_KEY || procEnv.VITE_SUPABASE_ANON_KEY || '';
export const supabaseAnonKey = (typeof rawAnonKey === 'string' ? rawAnonKey : '').trim();

export const isSupabaseConfigured: boolean = Boolean(
  supabaseAnonKey &&
  supabaseAnonKey.length > 20 &&
  supabaseUrl &&
  supabaseUrl.length > 0
);

export function assertSupabaseConfigured(): void {
  if (!isSupabaseConfigured) {
    throw new Error(
      'Supabase is not configured: VITE_SUPABASE_ANON_KEY environment variable is missing. Please set VITE_SUPABASE_ANON_KEY in your environment.'
    );
  }
}

// Create client instance. If not configured, provide dummy key to avoid crash on module import
export const supabase: SupabaseClient = createClient(
  supabaseUrl,
  isSupabaseConfigured ? supabaseAnonKey : 'unconfigured-placeholder-key'
);


