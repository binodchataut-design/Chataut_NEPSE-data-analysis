import { MarketIndexRecord, DailyMarketStatistics } from '../types/dataInfrastructure';
import { providerRegistry } from '../providers/providerRegistry';
import { normalizedIndices, normalizedDailyStats } from '../data/normalizedMasterData';

export class MarketRepository {
  public async getIndices(date?: string): Promise<MarketIndexRecord[]> {
    try {
      const indices = await providerRegistry.getMarketProvider().fetchIndices(date);
      if (indices && indices.length > 0) return indices;
    } catch {
      // Fallback
    }
    if (!date) return [...normalizedIndices];
    return normalizedIndices.filter(i => i.date === date);
  }

  public async getIndex(symbol: string): Promise<MarketIndexRecord | null> {
    const indices = await this.getIndices();
    const clean = (symbol || '').toUpperCase().trim();
    return indices.find(i => (i.index_id || '').toUpperCase() === clean || (i.name || '').toUpperCase().includes(clean)) || null;
  }

  public async getDailyStatistics(date?: string): Promise<DailyMarketStatistics> {
    try {
      return await providerRegistry.getMarketProvider().fetchDailyStatistics(date);
    } catch {
      return normalizedDailyStats;
    }
  }
}

export const marketRepository = new MarketRepository();
