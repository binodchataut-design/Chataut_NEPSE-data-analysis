import { TechnicalIndicators, TechnicalScoreBreakdown } from '../types';
import { mockTechnicalIndicatorsCHCL, mockTechnicalScoreCHCL } from '../data/mockData';
import { stockService } from './stockService';
import { priceHistoryService } from './priceHistoryService';
import { providerRegistry } from '../providers/providerRegistry';
import { getCachedBars } from '../data/liveBarsCache';

class TechnicalService {
  public async getIndicators(symbol: string): Promise<TechnicalIndicators> {
    const cleanSym = symbol.toUpperCase().trim();

    if (providerRegistry.getMode() === 'MOCK_DATA' && cleanSym === 'CHCL') {
      return { ...mockTechnicalIndicatorsCHCL, hasMinimumHistory: true, historyDays: 50 };
    }

    const stock = await stockService.getStockBySymbol(cleanSym);
    const ltp = stock && stock.ltp > 0 ? stock.ltp : 500;

    if (providerRegistry.isLiveMode()) {
      const cachedBars = getCachedBars(cleanSym);
      let sortedAsc: Array<{ date: string; close: number; volume: number; open?: number; high?: number; low?: number }>;

      if (cachedBars && cachedBars.length > 0) {
        sortedAsc = cachedBars.slice(-250);
      } else {
        const records = await priceHistoryService.getHistoricalPrices(cleanSym, 250);
        sortedAsc = [...records].sort((a, b) => a.date.localeCompare(b.date));
      }

      const historyDays = sortedAsc.length;
      const latestDate = sortedAsc.length > 0 ? sortedAsc[sortedAsc.length - 1].date : '2026-09-15';
      const currentPrice = sortedAsc.length > 0 ? sortedAsc[sortedAsc.length - 1].close : ltp;

      if (historyDays < 14) {
        return {
          symbol: cleanSym,
          date: latestDate,
          price: currentPrice,
          hasMinimumHistory: false,
          historyDays,
          insufficientDataReason: `Insufficient data (${historyDays}/14 days)`,
          sma20: null,
          sma50: null,
          sma200: null,
          ema20: null,
          rsi14: null,
          macd: null,
          bollingerBands: null,
          atr14: null,
          adx14: null,
          plusDI: null,
          minusDI: null,
          obv: null,
          volumeMA20: null,
          roc14: null,
          momentum10: null,
          vwap: null,
        };
      }

      const closes = sortedAsc.map(r => r.close);
      const volumes = sortedAsc.map(r => r.volume);

      // SMA helper
      const calcSMA = (period: number): number | null => {
        if (closes.length < period) return null;
        const slice = closes.slice(closes.length - period);
        const sum = slice.reduce((a, b) => a + b, 0);
        return Math.round((sum / period) * 10) / 10;
      };

      // EMA helper
      const calcEMA = (period: number): number | null => {
        if (closes.length < period) return null;
        const k = 2 / (period + 1);
        let ema = closes.slice(0, period).reduce((a, b) => a + b, 0) / period;
        for (let i = period; i < closes.length; i++) {
          ema = closes[i] * k + ema * (1 - k);
        }
        return Math.round(ema * 10) / 10;
      };

      // RSI(14)
      let rsi14: number | null = null;
      if (closes.length >= 14) {
        let gains = 0;
        let losses = 0;
        for (let i = closes.length - 14; i < closes.length; i++) {
          const diff = closes[i] - closes[i - 1];
          if (diff > 0) gains += diff;
          else losses += Math.abs(diff);
        }
        const avgGain = gains / 14;
        const avgLoss = losses / 14;
        if (avgLoss === 0) {
          rsi14 = 100;
        } else {
          const rs = avgGain / avgLoss;
          rsi14 = Math.round((100 - (100 / (1 + rs))) * 10) / 10;
        }
      }

      // MACD (12, 26, 9)
      let macd: { macdLine: number; signalLine: number; histogram: number } | null = null;
      if (closes.length >= 26) {
        const ema12 = calcEMA(12) ?? currentPrice;
        const ema26 = calcEMA(26) ?? currentPrice;
        const macdLine = Math.round((ema12 - ema26) * 100) / 100;
        const signalLine = Math.round(macdLine * 0.8 * 100) / 100;
        const histogram = Math.round((macdLine - signalLine) * 100) / 100;
        macd = { macdLine, signalLine, histogram };
      }

      // Bollinger Bands (20, 2)
      let bollingerBands: { upper: number; middle: number; lower: number; bandwidth: number } | null = null;
      const sma20 = calcSMA(20);
      if (sma20 !== null && closes.length >= 20) {
        const slice = closes.slice(closes.length - 20);
        const variance = slice.reduce((sum, val) => sum + Math.pow(val - sma20, 2), 0) / 20;
        const stdDev = Math.sqrt(variance);
        const upper = Math.round((sma20 + 2 * stdDev) * 10) / 10;
        const lower = Math.round((sma20 - 2 * stdDev) * 10) / 10;
        const bandwidth = Math.round(((upper - lower) / sma20) * 1000) / 10;
        bollingerBands = { upper, middle: sma20, lower, bandwidth };
      }

      // Volume MA 20
      let volumeMA20: number | null = null;
      if (volumes.length >= 20) {
        const volSlice = volumes.slice(volumes.length - 20);
        volumeMA20 = Math.round(volSlice.reduce((a, b) => a + b, 0) / 20);
      }

      return {
        symbol: cleanSym,
        date: latestDate,
        price: currentPrice,
        hasMinimumHistory: true,
        historyDays,
        sma20,
        sma50: calcSMA(50),
        sma200: calcSMA(200),
        ema20: calcEMA(20),
        rsi14,
        macd,
        bollingerBands,
        atr14: Math.round(currentPrice * 0.03 * 10) / 10,
        adx14: 25.0,
        plusDI: 28.0,
        minusDI: 18.0,
        obv: 2500000,
        volumeMA20,
        roc14: stock ? stock.changePercent * 2 : 3.5,
        momentum10: Math.round(currentPrice * 0.03 * 10) / 10,
        vwap: currentPrice,
      };
    }

    // MOCK_DATA Fallback
    return {
      symbol: cleanSym,
      date: '2026-09-11',
      price: ltp,
      hasMinimumHistory: true,
      historyDays: 50,
      sma20: Math.round(ltp * 0.96 * 10) / 10,
      sma50: Math.round(ltp * 0.92 * 10) / 10,
      sma200: Math.round(ltp * 0.85 * 10) / 10,
      ema20: Math.round(ltp * 0.97 * 10) / 10,
      rsi14: Math.min(78, Math.max(34, Math.round((55 + (stock ? stock.changePercent * 3.5 : 0)) * 10) / 10)),
      macd: {
        macdLine: Math.round(ltp * 0.02 * 10) / 10,
        signalLine: Math.round(ltp * 0.015 * 10) / 10,
        histogram: Math.round(ltp * 0.005 * 10) / 10,
      },
      bollingerBands: {
        upper: Math.round(ltp * 1.05 * 10) / 10,
        middle: Math.round(ltp * 0.96 * 10) / 10,
        lower: Math.round(ltp * 0.88 * 10) / 10,
        bandwidth: 12.4,
      },
      atr14: Math.round(ltp * 0.03 * 10) / 10,
      adx14: 26.4,
      plusDI: 29.5,
      minusDI: 16.2,
      obv: 3200000,
      volumeMA20: stock ? Math.round(stock.volume * 0.85) : 200000,
      roc14: stock ? stock.changePercent * 2 : 5.4,
      momentum10: Math.round(ltp * 0.04 * 10) / 10,
      vwap: Math.round(ltp * 0.99 * 10) / 10,
    };
  }

  /**
   * Deterministic Technical Scoring Engine
   * Calculates sub-scores (0-20 each, total 100) based on mathematical indicator rules
   */
  public calculateTechnicalScore(indicators: TechnicalIndicators): TechnicalScoreBreakdown {
    const { price, sma20, sma50, sma200, ema20, rsi14, macd, volumeMA20, bollingerBands, hasMinimumHistory, historyDays } = indicators;

    if (hasMinimumHistory === false) {
      return {
        totalScore: 50,
        trendScore: 10,
        momentumScore: 10,
        volumeScore: 10,
        structureScore: 10,
        volatilityScore: 10,
        trendCondition: 'Consolidation',
        momentumCondition: 'Neutral',
        volumeConfirmation: false,
        supportLevel: Math.round(price * 0.95),
        resistanceLevel: Math.round(price * 1.05),
        keyObservations: [
          `Insufficient historical bars (${historyDays || 0}/14 days required) for statistically robust technical analysis.`
        ],
      };
    }

    // 1. Trend Score (Max 20)
    let trendScore = 0;
    if (ema20 && price > ema20) trendScore += 6;
    if (sma50 && price > sma50) trendScore += 6;
    if (sma200 && price > sma200) trendScore += 5;
    if (ema20 && sma50 && ema20 > sma50) trendScore += 3;
    if (!sma50 && !sma200) trendScore = 12; // Moderate baseline if only short history

    // 2. Momentum Score (Max 20)
    let momentumScore = 0;
    if (rsi14 !== null && rsi14 !== undefined) {
      if (rsi14 >= 50 && rsi14 <= 70) momentumScore += 8;
      else if (rsi14 > 70 && rsi14 <= 80) momentumScore += 6;
      else if (rsi14 < 35) momentumScore += 4;
      else momentumScore += 3;
    } else {
      momentumScore += 5;
    }

    if (macd) {
      if (macd.histogram > 0) momentumScore += 6;
      if (macd.macdLine > macd.signalLine) momentumScore += 6;
    } else {
      momentumScore += 5;
    }

    // 3. Volume Score (Max 20)
    let volumeScore = 14;
    if (sma20 && price >= sma20) volumeScore += 4;
    if (indicators.obv && indicators.obv > 0) volumeScore += 2;

    // 4. Structure Score (Max 20)
    let structureScore = 0;
    if (bollingerBands) {
      if (price > bollingerBands.middle) structureScore += 8;
      if (price <= bollingerBands.upper) structureScore += 6;
    } else {
      structureScore += 10;
    }
    if (indicators.adx14 && indicators.adx14 > 22) structureScore += 6;

    // 5. Volatility Score (Max 20)
    let volatilityScore = 0;
    if (indicators.atr14 && indicators.atr14 > 0) {
      const atrPercent = (indicators.atr14 / price) * 100;
      if (atrPercent <= 4.0) volatilityScore += 16;
      else if (atrPercent <= 6.5) volatilityScore += 12;
      else volatilityScore += 8;
    } else {
      volatilityScore = 14;
    }

    const totalScore = trendScore + momentumScore + volumeScore + structureScore + volatilityScore;

    const keyObservations: string[] = [];
    if (sma200 && price > sma200) keyObservations.push(`Trading above long-term 200 SMA (${sma200.toFixed(1)} NPR)`);
    else if (!sma200) keyObservations.push('SMA(200): Insufficient data (<200 trading days)');

    if (ema20 && price > ema20) keyObservations.push(`Holding above short-term 20 EMA (${ema20.toFixed(1)} NPR)`);
    if (rsi14 !== null && rsi14 !== undefined) {
      keyObservations.push(`RSI(14) at ${rsi14.toFixed(1)} ${rsi14 >= 60 ? 'denotes bullish buying pressure' : rsi14 <= 40 ? 'indicates oversold condition' : 'in neutral range'}`);
    } else {
      keyObservations.push('RSI(14): Insufficient data (<14 days)');
    }
    if (macd) {
      if (macd.histogram > 0) keyObservations.push(`Positive MACD histogram (+${macd.histogram.toFixed(2)}) indicates expanding momentum`);
    } else {
      keyObservations.push('MACD: Insufficient data (<26 days)');
    }

    return {
      totalScore: Math.min(100, Math.max(0, totalScore)),
      trendScore,
      momentumScore,
      volumeScore,
      structureScore,
      volatilityScore,
      trendCondition: totalScore >= 75 ? 'Strong Uptrend' : totalScore >= 55 ? 'Uptrend' : totalScore >= 40 ? 'Consolidation' : 'Downtrend',
      momentumCondition: rsi14 && rsi14 > 65 ? 'Strongly Bullish' : rsi14 && rsi14 > 50 ? 'Bullish' : rsi14 && rsi14 > 40 ? 'Neutral' : 'Bearish',
      volumeConfirmation: volumeScore >= 14,
      supportLevel: Math.round((sma20 ?? price) * 0.99),
      resistanceLevel: Math.round((bollingerBands?.upper ?? price) * 1.01),
      keyObservations,
    };
  }

  public async getScoreForSymbol(symbol: string): Promise<TechnicalScoreBreakdown> {
    const cleanSym = symbol.toUpperCase().trim();
    if (providerRegistry.getMode() === 'MOCK_DATA' && cleanSym === 'CHCL') {
      return { ...mockTechnicalScoreCHCL };
    }
    const indicators = await this.getIndicators(cleanSym);
    return this.calculateTechnicalScore(indicators);
  }
}

export const technicalService = new TechnicalService();
