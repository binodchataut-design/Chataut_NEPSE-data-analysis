import React from 'react';
import { DecisionAssessment, DecisionIntelligenceEvent } from '../../types/decisionIntelligence';
import { ShieldCheck, Hash, Database, Clock, Terminal, Bell, Lock, CheckCircle2 } from 'lucide-react';

interface DecisionAuditViewProps {
  assessment: DecisionAssessment;
}

export const DecisionAuditView: React.FC<DecisionAuditViewProps> = ({ assessment }) => {
  const { audit, symbol, asOfDate, dataSource, engineVersion, probabilityEngineVersion, calculationTimestamp } = assessment;

  // Generate mock past/current alert-ready events for this setup (demonstrating Phase 5 contract foundation)
  const alertEvents: DecisionIntelligenceEvent[] = [
    {
      id: `evt-${symbol}-01`,
      type: 'EVIDENCE_ALIGNMENT_CHANGED',
      symbol,
      asOfDate,
      previousValue: 'NEUTRAL_OR_MIXED',
      currentValue: assessment.alignment.overallAlignment,
      reason: `Alignment upgraded to ${assessment.alignment.overallAlignment.replace(/_/g, ' ')} with score ${assessment.alignment.alignmentScore.toFixed(2)}`,
      timestamp: calculationTimestamp
    },
    {
      id: `evt-${symbol}-02`,
      type: 'TRADE_ELIGIBILITY_CHANGED',
      symbol,
      asOfDate,
      previousValue: 'WATCH',
      currentValue: assessment.eligibility.status,
      reason: assessment.eligibility.primaryReason,
      timestamp: calculationTimestamp
    },
    {
      id: `evt-${symbol}-03`,
      type: 'HISTORICAL_EDGE_CHANGED',
      symbol,
      asOfDate,
      previousValue: '58.0%',
      currentValue: `${assessment.probability.distributions['5D']?.pPositive.toFixed(1)}%`,
      reason: 'Empirical 5-session positive outcome probability recalculated on updated feature alignment',
      timestamp: calculationTimestamp
    }
  ];

  return (
    <div className="space-y-5 font-mono text-xs">
      {/* 1. Audit Header Card */}
      <div className="bg-[#0b101b] border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              Point-in-Time Causality &amp; Reproducibility Audit Trail
            </div>
            <div className="text-xs text-slate-400 mt-0.5 font-sans">
              Cryptographic snapshot of inputs, analytical engine versions, and empirical datasets for strict auditability.
            </div>
          </div>
          <span className="px-3 py-1 rounded bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-bold flex items-center gap-1.5 text-[11px]">
            <Lock className="w-3.5 h-3.5" /> ZERO LOOK-AHEAD VERIFIED
          </span>
        </div>

        {/* Audit Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          <div className="p-3 rounded bg-[#090d16] border border-slate-800 space-y-1">
            <div className="text-[10px] text-slate-400 flex items-center gap-1.5">
              <Hash className="w-3 h-3 text-cyan-400" /> Input Snapshot Hash
            </div>
            <div className="text-xs text-cyan-300 font-bold break-all">
              {audit.inputSnapshotHash}
            </div>
            <div className="text-[10px] text-slate-500">SHA-256 deterministic hash of all historical bars &lt;= {asOfDate}</div>
          </div>

          <div className="p-3 rounded bg-[#090d16] border border-slate-800 space-y-1">
            <div className="text-[10px] text-slate-400 flex items-center gap-1.5">
              <Database className="w-3 h-3 text-cyan-400" /> Data Provenance
            </div>
            <div className="text-xs text-slate-200 font-bold">{audit.dataProvenance}</div>
            <div className="text-[10px] text-slate-500">Mode: {dataSource} (NEPSE Adjusted Master Data)</div>
          </div>

          <div className="p-3 rounded bg-[#090d16] border border-slate-800 space-y-1">
            <div className="text-[10px] text-slate-400 flex items-center gap-1.5">
              <Clock className="w-3 h-3 text-cyan-400" /> Calculation Timestamp
            </div>
            <div className="text-xs text-slate-200 font-bold">{calculationTimestamp}</div>
            <div className="text-[10px] text-slate-500">Cutoff Date: {asOfDate} 23:59:59 NPT</div>
          </div>

          <div className="p-3 rounded bg-[#090d16] border border-slate-800 space-y-1">
            <div className="text-[10px] text-slate-400 flex items-center gap-1.5">
              <Terminal className="w-3 h-3 text-cyan-400" /> Evidence Engine Version
            </div>
            <div className="text-xs text-slate-200 font-bold">{engineVersion}</div>
            <div className="text-[10px] text-slate-500">Multi-Factor Aggregation &amp; De-correlation</div>
          </div>

          <div className="p-3 rounded bg-[#090d16] border border-slate-800 space-y-1">
            <div className="text-[10px] text-slate-400 flex items-center gap-1.5">
              <Terminal className="w-3 h-3 text-cyan-400" /> Probability Engine Version
            </div>
            <div className="text-xs text-slate-200 font-bold">{probabilityEngineVersion}</div>
            <div className="text-[10px] text-slate-500">Bayesian Beta-Binomial &amp; Wilson CI</div>
          </div>

          <div className="p-3 rounded bg-[#090d16] border border-slate-800 space-y-1">
            <div className="text-[10px] text-slate-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Historical Sample Matched
            </div>
            <div className="text-xs text-emerald-400 font-bold">{audit.totalObservationsMatched} Observations</div>
            <div className="text-[10px] text-slate-500">Strictly filtered: date &lt; {asOfDate}</div>
          </div>
        </div>
      </div>

      {/* 2. Alert-Ready Architecture Event Stream (Phase 5 Foundation) */}
      <div className="bg-[#0b101b] border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-cyan-400" />
            <span className="text-sm font-bold text-slate-100">
              Alert-Ready Architecture: Subscribed State Changes (Phase 5 Event Contracts)
            </span>
          </div>
          <span className="px-2 py-0.5 rounded text-[10px] bg-cyan-950 text-cyan-400 border border-cyan-800/40">
            EVENT CONTRACTS ACTIVE
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0e1628] text-slate-400 border-b border-slate-800 uppercase font-mono tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-3">Event ID</th>
                <th className="py-2.5 px-3">Event Type</th>
                <th className="py-2.5 px-3">Symbol</th>
                <th className="py-2.5 px-3">Previous Value</th>
                <th className="py-2.5 px-3">Current Value</th>
                <th className="py-2.5 px-3">Trigger Rationale</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
              {alertEvents.map(evt => (
                <tr key={evt.id} className="hover:bg-slate-850/40">
                  <td className="py-2.5 px-3 text-slate-400 font-bold">{evt.id}</td>
                  <td className="py-2.5 px-3 text-cyan-400 font-semibold">{evt.type}</td>
                  <td className="py-2.5 px-3 font-bold text-slate-200">{evt.symbol}</td>
                  <td className="py-2.5 px-3 text-slate-400">{String(evt.previousValue)}</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">{String(evt.currentValue)}</td>
                  <td className="py-2.5 px-3 text-slate-300 font-sans text-xs">{evt.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
