import React from 'react';
import { DecisionAssessment } from '../../types/decisionIntelligence';
import { CheckCircle2, AlertTriangle, Clock, ShieldAlert } from 'lucide-react';

interface DecisionEvidenceCardProps {
  assessment: DecisionAssessment;
  className?: string;
  onNavigateTab?: (tab: string) => void;
}

export const DecisionEvidenceCard: React.FC<DecisionEvidenceCardProps> = ({
  assessment,
  className = '',
  onNavigateTab
}) => {
  const {
    symbol,
    companyName,
    sectorName,
    asOfDate,
    evidenceItems,
    alignment,
    probability,
    eligibility,
    researchEvidenceGrade
  } = assessment;

  // Extract primary evidence states from normalized items
  const getEvidenceState = (category: string) => {
    const item = evidenceItems.find(i => i.category === category);
    if (!item) return { label: 'NEUTRAL', color: 'text-slate-400' };

    switch (item.direction) {
      case 'BULLISH':
        return { label: item.formattedValue || 'BULLISH', color: 'text-emerald-400' };
      case 'BEARISH':
        return { label: item.formattedValue || 'BEARISH', color: 'text-rose-400' };
      case 'NEUTRAL':
        return { label: item.formattedValue || 'NEUTRAL', color: 'text-slate-400' };
      case 'MIXED':
        return { label: item.formattedValue || 'MIXED', color: 'text-amber-400' };
      default:
        return { label: 'UNKNOWN', color: 'text-slate-500' };
    }
  };

  const marketState = getEvidenceState('MARKET_REGIME');
  const sectorState = getEvidenceState('SECTOR');
  const trendState = getEvidenceState('TREND');
  const momentumState = getEvidenceState('MOMENTUM');
  const volumeState = getEvidenceState('VOLUME');
  const structureState = getEvidenceState('PRICE_STRUCTURE');
  const fundamentalState = getEvidenceState('FUNDAMENTAL');
  const brokerState = getEvidenceState('BROKER');
  const liquidityState = getEvidenceState('LIQUIDITY');

  // Primary 5D horizon probability stats
  const dist5d = probability.distributions['5D'] || Object.values(probability.distributions)[0];

  const getStatusDisplay = () => {
    switch (eligibility.status) {
      case 'ELIGIBLE':
        return {
          text: 'STATUS: ELIGIBLE',
          bg: 'bg-emerald-950/80 border-emerald-500/60 text-emerald-300',
          icon: <CheckCircle2 className="w-4 h-4 text-emerald-400" />
        };
      case 'ELIGIBLE_WITH_WARNING':
        return {
          text: 'STATUS: ELIGIBLE WITH WARNING',
          bg: 'bg-amber-950/80 border-amber-500/60 text-amber-300',
          icon: <AlertTriangle className="w-4 h-4 text-amber-400" />
        };
      case 'WATCH':
        return {
          text: 'STATUS: ACTIVE WATCHLIST',
          bg: 'bg-cyan-950/80 border-cyan-500/60 text-cyan-300',
          icon: <Clock className="w-4 h-4 text-cyan-400" />
        };
      case 'BLOCKED':
        return {
          text: 'STATUS: BLOCKED BY SAFETY GATE',
          bg: 'bg-rose-950/80 border-rose-500/60 text-rose-300',
          icon: <ShieldAlert className="w-4 h-4 text-rose-400" />
        };
      default:
        return {
          text: `STATUS: ${eligibility.status.replace(/_/g, ' ')}`,
          bg: 'bg-slate-800 border-slate-700 text-slate-300',
          icon: <AlertTriangle className="w-4 h-4 text-slate-400" />
        };
    }
  };

  const statusBadge = getStatusDisplay();

  const alignmentGrade = alignment.alignmentScore >= 0.75
    ? 'HIGH'
    : alignment.alignmentScore >= 0.5
    ? 'MODERATE'
    : 'LOW';

  const qualityGrade = researchEvidenceGrade === 'A' || researchEvidenceGrade === 'B'
    ? 'HIGH'
    : researchEvidenceGrade === 'C'
    ? 'MODERATE'
    : 'LOW';

  const riskLevel = assessment.conflicts.hasCriticalConflict || !dist5d.isReliable
    ? 'HIGH'
    : assessment.conflicts.conflictCount > 0
    ? 'MODERATE'
    : 'LOW';

  return (
    <div
      className={`bg-[#0b101b] border border-slate-700/80 rounded-lg p-4 font-mono text-xs shadow-lg space-y-3.5 max-w-md ${className}`}
    >
      {/* 1. Header */}
      <div className="border-b border-slate-800 pb-2.5">
        <div className="flex items-center justify-between">
          <div className="text-base font-bold text-slate-100 flex items-center gap-2">
            <span className="text-cyan-400 font-black">{symbol}</span>
            <span className="text-xs font-normal text-slate-400 truncate max-w-[180px]">
              {companyName}
            </span>
          </div>
          <span className="text-[10px] text-slate-500 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
            {asOfDate}
          </span>
        </div>
        <div className="text-[11px] text-slate-400 mt-0.5">
          Evidence-Based Setup Assessment • {sectorName}
        </div>
      </div>

      {/* 2. Evidence Dimensions Matrix */}
      <div className="space-y-1 text-xs border-b border-slate-800 pb-2.5">
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Market</span>
          <span className={`font-semibold ${marketState.color}`}>{marketState.label}</span>
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Sector</span>
          <span className={`font-semibold ${sectorState.color}`}>{sectorState.label}</span>
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Trend</span>
          <span className={`font-semibold ${trendState.color}`}>{trendState.label}</span>
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Momentum</span>
          <span className={`font-semibold ${momentumState.color}`}>{momentumState.label}</span>
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Volume</span>
          <span className={`font-semibold ${volumeState.color}`}>{volumeState.label}</span>
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Structure</span>
          <span className={`font-semibold ${structureState.color}`}>{structureState.label}</span>
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Fundamentals</span>
          <span className={`font-semibold ${fundamentalState.color}`}>{fundamentalState.label}</span>
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Broker</span>
          <span className={`font-semibold ${brokerState.color}`}>{brokerState.label}</span>
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Liquidity</span>
          <span className={`font-semibold ${liquidityState.color}`}>{liquidityState.label}</span>
        </div>
      </div>

      {/* 3. Historical Conditional Evidence */}
      <div className="space-y-1.5 border-b border-slate-800 pb-2.5">
        <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
          Historical Evidence (Empirical)
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Observations</span>
          <span className="font-bold text-slate-200">{dist5d.observations}</span>
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">P(Positive 5D)</span>
          <span className="font-bold text-cyan-400">{dist5d.pPositive.toFixed(1)}%</span>
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">95% Wilson CI</span>
          <span className="font-mono text-slate-300">
            {dist5d.wilsonInterval.lower.toFixed(1)}% – {dist5d.wilsonInterval.upper.toFixed(1)}%
          </span>
        </div>
      </div>

      {/* 4. Alignment, Quality, Risk */}
      <div className="space-y-1 border-b border-slate-800 pb-2.5">
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Evidence Alignment</span>
          <span className="font-bold text-slate-200">{alignmentGrade}</span>
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Evidence Quality</span>
          <span className="font-bold text-slate-200">{qualityGrade} (Grade {researchEvidenceGrade})</span>
        </div>
        <div className="flex items-center justify-between py-0.5">
          <span className="text-slate-400">Risk Level</span>
          <span className={`font-bold ${riskLevel === 'HIGH' ? 'text-rose-400' : riskLevel === 'MODERATE' ? 'text-amber-400' : 'text-emerald-400'}`}>
            {riskLevel}
          </span>
        </div>
      </div>

      {/* 5. Status Footer */}
      <div className={`p-2.5 rounded border flex items-center justify-between gap-2 ${statusBadge.bg}`}>
        <div className="flex items-center gap-2 font-bold text-xs tracking-tight">
          {statusBadge.icon}
          <span>{statusBadge.text}</span>
        </div>
        {onNavigateTab && (
          <button
            onClick={() => onNavigateTab('EXPLANATION')}
            className="text-[10px] text-cyan-400 hover:underline uppercase tracking-wide shrink-0"
          >
            Details →
          </button>
        )}
      </div>
    </div>
  );
};
