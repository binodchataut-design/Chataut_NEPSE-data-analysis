import React from 'react';
import { DecisionAssessment } from '../../types/decisionIntelligence';
import { HelpCircle, CheckCircle2, AlertTriangle, ShieldCheck, Info, TrendingUp, AlertCircle, FileText } from 'lucide-react';

interface DecisionExplanationViewProps {
  assessment: DecisionAssessment;
}

export const DecisionExplanationView: React.FC<DecisionExplanationViewProps> = ({ assessment }) => {
  const { explanation, alignment, researchEvidenceGrade, symbol, asOfDate, probability, eligibility } = assessment;
  const dist5d = probability.distributions['5D'] || Object.values(probability.distributions)[0];

  return (
    <div className="space-y-5 font-mono text-xs">
      {/* 1. Decision Headline and Executive Verdict */}
      <div className="bg-[#0b101b] border border-slate-800 rounded-lg p-5 space-y-3">
        <div className="flex items-center gap-2 pb-2.5 border-b border-slate-800">
          <FileText className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
            Natural-Language Decision Rationale &amp; Explainability
          </h2>
          <span className="px-2 py-0.5 rounded text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-800/40">
            DETERMINISTIC
          </span>
        </div>

        <div>
          <div className="text-base font-bold text-slate-100">
            {explanation.headline}
          </div>
          <p className="text-xs text-slate-300 font-sans mt-1 leading-relaxed">
            {explanation.verdictRationale}
          </p>
        </div>
      </div>

      {/* 2. Structured Dual Columns: WHY THIS SETUP IS INTERESTING vs WHY CAUTION IS REQUIRED (Section 16) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Left Column: WHY THIS SETUP IS INTERESTING */}
        <div className="bg-[#0b101b] border border-emerald-500/30 rounded-lg p-5 space-y-3 bg-emerald-950/5">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider">
            <CheckCircle2 className="w-4 h-4" /> WHY THIS SETUP IS INTERESTING
          </div>
          <ul className="space-y-2.5 text-xs text-slate-200 font-sans">
            {explanation.whyInteresting.map((item, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold font-mono shrink-0 mt-0.5">{i + 1}.</span>
                <span className="leading-snug">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Right Column: WHY CAUTION IS REQUIRED */}
        <div className="bg-[#0b101b] border border-amber-500/30 rounded-lg p-5 space-y-3 bg-amber-950/5">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
            <AlertTriangle className="w-4 h-4" /> WHY CAUTION IS REQUIRED
          </div>
          <ul className="space-y-2.5 text-xs text-slate-300 font-sans">
            {explanation.whyCautionRequired.map((item, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-amber-400 font-bold font-mono shrink-0 mt-0.5">⚠</span>
                <span className="leading-snug">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* 3. Concise Decision Summary (Section 32) */}
      <div className="bg-[#0b101b] border border-slate-800 rounded-lg p-5 space-y-3">
        <div className="text-xs font-bold text-slate-200 uppercase tracking-wider border-b border-slate-800 pb-2">
          Concise Setup Executive Summary
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-2 border-b border-slate-800/80">
          <div>
            <div className="text-slate-400 text-[11px]">Evidence Alignment:</div>
            <div className="font-bold text-cyan-300 mt-0.5">
              {alignment.overallAlignment.replace(/_/g, ' ')} ({Math.round(alignment.alignmentScore * 100)}%)
            </div>
          </div>
          <div>
            <div className="text-slate-400 text-[11px]">Research Grade:</div>
            <div className="font-bold text-slate-100 mt-0.5">
              Grade {researchEvidenceGrade}
            </div>
          </div>
          <div>
            <div className="text-slate-400 text-[11px]">Historical 5D Win Rate:</div>
            <div className="font-bold text-emerald-400 mt-0.5">
              {dist5d.pPositive.toFixed(1)}% (N={dist5d.observations})
            </div>
          </div>
          <div>
            <div className="text-slate-400 text-[11px]">Decision Status:</div>
            <div className="font-bold text-amber-300 mt-0.5">
              {eligibility.status.replace(/_/g, ' ')}
            </div>
          </div>
        </div>

        <div className="text-xs text-slate-300 space-y-1 pt-1 font-sans">
          <div>
            <strong className="text-slate-200 font-mono">Primary Risk Factor: </strong>
            {explanation.primaryRiskFactor}
          </div>
          <div>
            <strong className="text-slate-200 font-mono">Evidence Basis: </strong>
            Historical comparable conditions obeying strict cutoff date {asOfDate}, not future prediction.
          </div>
        </div>
      </div>

      {/* 4. Critical Statistical Principle Callout (Section 33) */}
      <div className="p-4 rounded-lg bg-slate-900/80 border border-slate-700/80 text-xs text-slate-300 space-y-2">
        <div className="flex items-center gap-2 text-cyan-400 font-bold uppercase tracking-wider text-[11px]">
          <Info className="w-4 h-4" /> Core Statistical Rigor Principle
        </div>
        <p className="font-sans text-xs leading-relaxed text-slate-300">
          This system never states that a setup &ldquo;will win.&rdquo; Instead, it reports:
          <em className="text-slate-100 font-medium">
            {' '}&ldquo;In the historical sample of {dist5d.observations} observations matching these exact multi-dimensional conditions,{' '}
            {dist5d.pPositive.toFixed(1)}% produced a positive outcome over 5 sessions (95% Wilson confidence interval: {dist5d.wilsonInterval.lower.toFixed(1)}%–{dist5d.wilsonInterval.upper.toFixed(1)}%).&rdquo;
          </em>
        </p>
        <div className="text-[11px] text-slate-400 font-mono">
          Strict isolation: Zero look-ahead bias • Sample size tier: {dist5d.sampleTier} • Out-of-sample verified
        </div>
      </div>
    </div>
  );
};
