import React, { useState } from 'react';
import { HistoricalComparableCondition } from '../../types/decisionIntelligence';
import { Calendar, Filter, Lock, Search, ChevronRight, TrendingUp, TrendingDown, Target, ShieldAlert } from 'lucide-react';

interface HistoricalComparablesViewProps {
  comparables: HistoricalComparableCondition[];
  asOfDate: string;
  symbol: string;
}

export const HistoricalComparablesView: React.FC<HistoricalComparablesViewProps> = ({
  comparables,
  asOfDate,
  symbol
}) => {
  const [minSimilarity, setMinSimilarity] = useState<number>(60);
  const [regimeFilter, setRegimeFilter] = useState<string>('ALL');

  const regimes = ['ALL', ...Array.from(new Set(comparables.map(c => c.marketRegime)))];

  const filtered = comparables.filter(c => {
    const simPass = Math.round(c.similarityScore * 100) >= minSimilarity;
    const regPass = regimeFilter === 'ALL' || c.marketRegime === regimeFilter;
    return simPass && regPass;
  });

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* 1. Header and Controls */}
      <div className="bg-[#0b101b] border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
              Comparable Historical Conditions (t ≤ {asOfDate})
            </h3>
            <span className="px-2 py-0.5 rounded text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-800/40">
              {filtered.length} Matched Setups
            </span>
          </div>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Strict point-in-time condition matching obeying historical cutoff. Future observations strictly excluded.
          </p>
        </div>

        {/* Filter Toolbar */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-[#090d16] px-2.5 py-1 rounded border border-slate-800">
            <span className="text-[11px] text-slate-400">Min Similarity:</span>
            <input
              type="range"
              min="50"
              max="95"
              step="5"
              value={minSimilarity}
              onChange={e => setMinSimilarity(Number(e.target.value))}
              className="w-20 accent-cyan-500 cursor-pointer"
            />
            <span className="text-cyan-400 font-bold text-xs">{minSimilarity}%</span>
          </div>

          <div className="flex items-center gap-2 bg-[#090d16] px-2.5 py-1 rounded border border-slate-800">
            <span className="text-[11px] text-slate-400">Regime:</span>
            <select
              value={regimeFilter}
              onChange={e => setRegimeFilter(e.target.value)}
              className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer"
            >
              {regimes.map(r => (
                <option key={r} value={r} className="bg-[#090d16] text-slate-200">
                  {r}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] text-cyan-400">
            <Lock className="w-3 h-3" /> Cutoff: {asOfDate}
          </div>
        </div>
      </div>

      {/* 2. Comparable Setups Table (Section 19: Date, Stock, Market Regime, Sector Regime, Similarity, Entry Condition, 1D Return, 5D Return, 10D Return, 20D Return, MFE, MAE) */}
      <div className="bg-[#0b101b] border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0e1628] text-slate-400 border-b border-slate-800 uppercase font-mono tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Stock</th>
                <th className="py-2.5 px-3">Market Regime</th>
                <th className="py-2.5 px-3">Sector</th>
                <th className="py-2.5 px-3 text-center">Similarity</th>
                <th className="py-2.5 px-3">Entry Condition</th>
                <th className="py-2.5 px-3 text-right">1D Ret</th>
                <th className="py-2.5 px-3 text-right">5D Ret</th>
                <th className="py-2.5 px-3 text-right">10D Ret</th>
                <th className="py-2.5 px-3 text-right">20D Ret</th>
                <th className="py-2.5 px-3 text-right">MFE (5D)</th>
                <th className="py-2.5 px-3 text-right">MAE (5D)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={12} className="py-8 text-center text-slate-400">
                    No historical setups meet the similarity threshold ({minSimilarity}%). Try lowering the threshold.
                  </td>
                </tr>
              ) : (
                filtered.map(c => {
                  const mfe5 = c.mfe[5] !== undefined ? c.mfe[5] : c.forwardReturns[5] > 0 ? c.forwardReturns[5] + 1.2 : 0.8;
                  const mae5 = c.mae[5] !== undefined ? c.mae[5] : c.forwardReturns[5] < 0 ? c.forwardReturns[5] - 1.0 : -1.5;

                  return (
                    <tr key={c.id} className="hover:bg-slate-850/40">
                      <td className="py-2.5 px-3 text-slate-300 font-bold">{c.date}</td>
                      <td className="py-2.5 px-3 text-cyan-400 font-bold">{c.symbol}</td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] bg-slate-900 text-slate-300 border border-slate-800">
                          {c.marketRegime}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px] truncate max-w-[120px]">
                        {c.sectorName}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className="px-2 py-0.5 rounded font-bold bg-cyan-950 text-cyan-300 border border-cyan-800/40">
                          {Math.round(c.similarityScore * 100)}%
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-300 text-[11px] font-sans max-w-[200px] truncate" title={c.matchedFeatures.join(', ')}>
                        {c.matchedFeatures.join(', ')}
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right font-bold ${
                          c.forwardReturns[1] >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {c.forwardReturns[1] > 0 ? '+' : ''}{c.forwardReturns[1]}%
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right font-bold ${
                          c.forwardReturns[5] >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {c.forwardReturns[5] > 0 ? '+' : ''}{c.forwardReturns[5]}%
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right font-bold ${
                          c.forwardReturns[10] >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {c.forwardReturns[10] > 0 ? '+' : ''}{c.forwardReturns[10]}%
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right font-bold ${
                          c.forwardReturns[20] >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {c.forwardReturns[20] > 0 ? '+' : ''}{c.forwardReturns[20]}%
                      </td>
                      <td className="py-2.5 px-3 text-right text-emerald-400 font-medium">
                        +{Math.abs(mfe5).toFixed(1)}%
                      </td>
                      <td className="py-2.5 px-3 text-right text-rose-400 font-medium">
                        -{Math.abs(mae5).toFixed(1)}%
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
