import React from 'react';
import { DecisionEligibilityResult, RiskRewardParameters } from '../../types/decisionIntelligence';
import { ShieldCheck, ShieldAlert, AlertTriangle, CheckCircle2, Lock, Percent, DollarSign, Activity, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface RiskEligibilityViewProps {
  eligibility: DecisionEligibilityResult;
  riskReward: RiskRewardParameters;
  symbol: string;
  asOfDate: string;
}

export const RiskEligibilityView: React.FC<RiskEligibilityViewProps> = ({
  eligibility,
  riskReward,
  symbol,
  asOfDate
}) => {
  const getStatusBadge = () => {
    switch (eligibility.status) {
      case 'ELIGIBLE':
        return (
          <div className="p-3 rounded-lg bg-emerald-950/80 border border-emerald-500/60 flex items-center justify-between">
            <div className="flex items-center gap-2 text-emerald-300 font-bold text-sm">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              STATUS: ELIGIBLE
            </div>
            <span className="text-xs text-emerald-400 font-mono">All Safety Gates Cleared</span>
          </div>
        );
      case 'ELIGIBLE_WITH_WARNING':
        return (
          <div className="p-3 rounded-lg bg-amber-950/80 border border-amber-500/60 flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
              STATUS: ELIGIBLE WITH WARNING
            </div>
            <span className="text-xs text-amber-400 font-mono">Caution Required (Non-Blocking)</span>
          </div>
        );
      case 'WATCH':
        return (
          <div className="p-3 rounded-lg bg-yellow-950/80 border border-yellow-500/60 flex items-center justify-between">
            <div className="flex items-center gap-2 text-yellow-300 font-bold text-sm">
              <Activity className="w-5 h-5 text-yellow-400" />
              STATUS: ACTIVE WATCHLIST
            </div>
            <span className="text-xs text-yellow-400 font-mono">Setup Incomplete / Maturing</span>
          </div>
        );
      case 'BLOCKED':
        return (
          <div className="p-3 rounded-lg bg-rose-950/80 border border-rose-500/60 flex items-center justify-between">
            <div className="flex items-center gap-2 text-rose-300 font-bold text-sm">
              <ShieldAlert className="w-5 h-5 text-rose-400" />
              STATUS: BLOCKED BY SAFETY GATE
            </div>
            <span className="text-xs text-rose-400 font-mono">Hard Blocker Enforced</span>
          </div>
        );
      default:
        return (
          <div className="p-3 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-300 font-bold text-sm">
              <AlertTriangle className="w-5 h-5 text-slate-400" />
              STATUS: {eligibility.status.replace(/_/g, ' ')}
            </div>
            <span className="text-xs text-slate-400 font-mono">Insufficient Verification</span>
          </div>
        );
    }
  };

  return (
    <div className="space-y-5 font-mono text-xs">
      {/* 1. Status Headline */}
      {getStatusBadge()}

      {/* 2. Hard Blockers Enforcement Gate (Section 13 & 14) */}
      <div className="bg-[#0b101b] border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between pb-2.5 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
              Hard Blocker &amp; Safety Gate Enforcement
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">
            {eligibility.blockers.filter(b => b.triggered).length} Triggered / {eligibility.blockers.length} Monitored
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0e1628] text-slate-400 border-b border-slate-800 uppercase font-mono tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-3">Gate Code</th>
                <th className="py-2.5 px-3">Safety Check Name</th>
                <th className="py-2.5 px-3">Severity</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Evaluation Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
              {eligibility.blockers.map(b => (
                <tr key={b.id} className="hover:bg-slate-850/40">
                  <td className="py-2.5 px-3 text-slate-400 font-bold">{b.code}</td>
                  <td className="py-2.5 px-3 font-semibold text-slate-200">{b.name}</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        b.severity === 'BLOCKER'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {b.severity}
                    </span>
                  </td>
                  <td className="py-2.5 px-3">
                    {b.triggered ? (
                      <span className="px-2 py-0.5 rounded text-[10px] bg-rose-950 text-rose-400 border border-rose-500/40 font-bold flex items-center gap-1 w-fit">
                        <AlertTriangle className="w-3 h-3" /> TRIGGERED
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-500/40 font-bold flex items-center gap-1 w-fit">
                        <CheckCircle2 className="w-3 h-3" /> PASS
                      </span>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-slate-300 font-sans text-xs">{b.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. Passed Criteria & Active Warnings */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Passed Criteria */}
        <div className="bg-[#0b101b] border border-slate-800 rounded-lg p-4 space-y-2.5">
          <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" /> Passed Eligibility Criteria
          </div>
          <ul className="space-y-1.5 text-xs text-slate-300 font-sans">
            {eligibility.passedCriteria.map((c, i) => (
              <li key={i} className="flex items-start gap-1.5 font-mono text-xs">
                <span className="text-emerald-400 font-bold shrink-0">✓</span>
                <span>{c}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Active Warnings */}
        <div className="bg-[#0b101b] border border-slate-800 rounded-lg p-4 space-y-2.5">
          <div className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" /> Active Non-Blocking Warnings
          </div>
          {eligibility.warnings.length === 0 ? (
            <div className="text-xs text-slate-400 font-sans py-2">
              No active warnings. Setup exhibits consistent alignment across monitored dimensions.
            </div>
          ) : (
            <ul className="space-y-1.5 text-xs text-slate-300 font-sans">
              {eligibility.warnings.map((w, i) => (
                <li key={i} className="flex items-start gap-1.5 font-mono text-xs">
                  <span className="text-amber-400 font-bold shrink-0">⚠</span>
                  <span>{w}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* 4. Risk/Reward & Execution Realism (Section 15) */}
      <div className="bg-[#0b101b] border border-slate-800 rounded-lg p-4 space-y-4">
        <div className="flex items-center justify-between pb-2.5 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
              Execution Realism &amp; Risk/Reward Model
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">
            NEPSE Slippage, Brokerage &amp; Liquidity Absorption
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          <div className="p-3 rounded bg-[#090d16] border border-slate-800">
            <div className="text-[10px] text-slate-400">Current Price</div>
            <div className="font-bold text-slate-100 text-sm mt-0.5">
              NPR {riskReward.currentPrice.toFixed(1)}
            </div>
            <div className="text-[10px] text-slate-500">
              Entry: {riskReward.recommendedEntryZone.low} - {riskReward.recommendedEntryZone.high}
            </div>
          </div>

          <div className="p-3 rounded bg-[#090d16] border border-slate-800">
            <div className="text-[10px] text-rose-400">Stop Loss</div>
            <div className="font-bold text-rose-400 text-sm mt-0.5">
              NPR {riskReward.suggestedStopLoss.toFixed(1)}
            </div>
            <div className="text-[10px] text-rose-500">
              -{riskReward.stopDistancePercent.toFixed(1)}% (1.5x ATR)
            </div>
          </div>

          <div className="p-3 rounded bg-[#090d16] border border-slate-800">
            <div className="text-[10px] text-emerald-400">Target 1</div>
            <div className="font-bold text-emerald-400 text-sm mt-0.5">
              NPR {riskReward.target1.toFixed(1)}
            </div>
            <div className="text-[10px] text-emerald-500">
              +{riskReward.target1Percent.toFixed(1)}%
            </div>
          </div>

          <div className="p-3 rounded bg-[#090d16] border border-slate-800">
            <div className="text-[10px] text-cyan-400">Target 2 (Runner)</div>
            <div className="font-bold text-cyan-400 text-sm mt-0.5">
              NPR {riskReward.target2.toFixed(1)}
            </div>
            <div className="text-[10px] text-cyan-500">
              +{riskReward.target2Percent.toFixed(1)}%
            </div>
          </div>

          <div className="p-3 rounded bg-[#090d16] border border-slate-800">
            <div className="text-[10px] text-slate-400">Risk : Reward</div>
            <div className="font-bold text-cyan-300 text-sm mt-0.5">
              1 : {riskReward.riskRewardRatio.toFixed(2)}
            </div>
            <div className="text-[10px] text-slate-500">
              Net: {riskReward.estimatedNetExpectancyPercent > 0 ? '+' : ''}{riskReward.estimatedNetExpectancyPercent}%
            </div>
          </div>

          <div className="p-3 rounded bg-[#090d16] border border-slate-800">
            <div className="text-[10px] text-slate-400">Execution Friction</div>
            <div className="font-bold text-slate-300 text-sm mt-0.5">
              {(riskReward.estimatedSlippagePercent + riskReward.estimatedBrokerageRoundTripPercent).toFixed(2)}%
            </div>
            <div className="text-[10px] text-slate-500">
              Slippage: {riskReward.estimatedSlippagePercent}% • Com: {riskReward.estimatedBrokerageRoundTripPercent}%
            </div>
          </div>
        </div>

        <div className="p-3 rounded bg-[#090d16] border border-slate-800 flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-400">Liquidity Absorption Capacity Score: </span>
            <span className="text-cyan-300 font-bold">{riskReward.liquidityAbsorptionScore}/100</span>
          </div>
          <div className="text-[11px] text-slate-500 font-sans">
            Conservative NEPSE lot sizing advised if order exceeds 10% of ADT20 turnover.
          </div>
        </div>
      </div>
    </div>
  );
};
