import React from 'react';
import { OpportunityBreadthStats } from '../../types/opportunityScanner';
import {
  Activity,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Layers,
  ShieldAlert,
  Flame,
  Info
} from 'lucide-react';

interface OpportunityBreadthBarProps {
  stats: OpportunityBreadthStats;
}

export function OpportunityBreadthBar({ stats }: OpportunityBreadthBarProps) {
  return (
    <div className="space-y-3">
      {/* Crowding Advisory Banner (Section 35) */}
      {stats.crowdingState.isCrowded && (
        <div className="bg-amber-950/30 border border-amber-500/50 rounded-lg p-3 flex items-start gap-3">
          <Flame className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs">
            <div className="font-bold text-amber-300 uppercase tracking-wider font-mono">
              Setup Crowding Detected ({stats.crowdingState.crowdedCategory})
            </div>
            <div className="text-amber-200/90 font-sans mt-0.5">
              {stats.crowdingState.advisoryMessage}
            </div>
          </div>
        </div>
      )}

      {/* Breadth Metric Counters Grid (Section 33) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#0e131f] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Universe Scanned</span>
            <Layers className="w-3.5 h-3.5 text-slate-500" />
          </div>
          <div className="text-lg font-bold font-mono text-slate-100 mt-1">
            {stats.totalSecuritiesScanned}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">
            Active NEPSE listings
          </div>
        </div>

        <div className="bg-[#0e131f] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Active Setups</span>
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-lg font-bold font-mono text-cyan-400 mt-1">
            {stats.securitiesWithSetups}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">
            Distinct symbols
          </div>
        </div>

        <div className="bg-[#0e131f] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Confirmed</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-lg font-bold font-mono text-emerald-400 mt-1">
            {stats.confirmedSetupsCount}
          </div>
          <div className="text-[10px] text-emerald-500/80 mt-0.5">
            Trigger + Confirmation
          </div>
        </div>

        <div className="bg-[#0e131f] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Forming Setups</span>
            <Clock className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-lg font-bold font-mono text-amber-400 mt-1">
            {stats.formingSetupsCount}
          </div>
          <div className="text-[10px] text-amber-500/80 mt-0.5">
            Early structure developing
          </div>
        </div>

        <div className="bg-[#0e131f] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Triggered</span>
            <Flame className="w-3.5 h-3.5 text-cyan-300" />
          </div>
          <div className="text-lg font-bold font-mono text-cyan-300 mt-1">
            {stats.triggeredSetupsCount}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">
            Awaiting confirmation
          </div>
        </div>

        <div className="bg-[#0e131f] border border-slate-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Safety Blocked</span>
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-lg font-bold font-mono text-rose-400 mt-1">
            {stats.blockedSetupsCount}
          </div>
          <div className="text-[10px] text-rose-500/80 mt-0.5">
            Liquidity / Gate failures
          </div>
        </div>
      </div>
    </div>
  );
}
