import React, { useState, useEffect } from 'react';
import {
  ScannedOpportunity,
  OpportunityScannerFilterParams,
  OpportunityBreadthStats,
  SetupCategory,
  SetupStage,
  OpportunityClassification,
  ResearchUserStatus
} from '../../types/opportunityScanner';
import { OpportunityScannerService } from '../../services/opportunity/opportunityScannerService';
import { OpportunityBreadthBar } from './OpportunityBreadthBar';
import { OpportunityHeatmap } from './OpportunityHeatmap';
import { OpportunitySnapshotCard } from './OpportunitySnapshotCard';
import { OpportunityDetailPanel } from './OpportunityDetailPanel';
import { DataSourceIndicator } from '../layout/DataSourceIndicator';
import {
  Crosshair,
  Filter,
  Search,
  LayoutGrid,
  Table,
  RefreshCw,
  Flame,
  ArrowUpRight,
  ShieldCheck,
  Calendar,
  Layers,
  Star,
  CheckCircle2,
  AlertTriangle,
  Bookmark
} from 'lucide-react';
import { EvidenceGrade } from '../../types/researchValidation';

interface OpportunityScannerViewProps {
  onSelectStock: (symbol: string) => void;
  onNavigateToDecision?: (symbol: string) => void;
  initialSymbol?: string;
}

export function OpportunityScannerView({
  onSelectStock,
  onNavigateToDecision,
  initialSymbol
}: OpportunityScannerViewProps) {
  const [opportunities, setOpportunities] = useState<ScannedOpportunity[]>([]);
  const [breadthStats, setBreadthStats] = useState<OpportunityBreadthStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedOpportunity, setSelectedOpportunity] = useState<ScannedOpportunity | null>(null);
  const [viewMode, setViewMode] = useState<'TABLE' | 'CARDS' | 'HEATMAP'>('TABLE');

  // Filter parameters state
  const [asOfDate, setAsOfDate] = useState('2026-08-30');
  const [universe, setUniverse] = useState<'ALL_NEPSE' | 'COMMERCIAL_BANKS' | 'HYDROPOWER' | 'INSURANCE' | 'MANUFACTURING' | 'FINANCE'>('ALL_NEPSE');
  const [selectedCategory, setSelectedCategory] = useState<SetupCategory | 'ALL'>('ALL');
  const [selectedStage, setSelectedStage] = useState<SetupStage | 'ALL'>('ALL');
  const [minGrade, setMinGrade] = useState<EvidenceGrade | 'ALL'>('ALL');
  const [liquidityFilter, setLiquidityFilter] = useState<'ALL' | 'PASS_ONLY'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const loadOpportunities = async () => {
    setLoading(true);
    try {
      const filters: OpportunityScannerFilterParams = {
        asOfDate,
        universe,
        setupCategory: selectedCategory,
        setupStage: selectedStage,
        minimumEvidenceGrade: minGrade,
        liquidityFilter,
        searchQuery: searchQuery.trim() || undefined
      };

      const results = await OpportunityScannerService.scanUniverse(filters);
      setOpportunities(results);

      const stats = OpportunityScannerService.getBreadthStats(results, asOfDate);
      setBreadthStats(stats);

      if (initialSymbol) {
        const match = results.find(r => r.symbol.toUpperCase() === initialSymbol.toUpperCase());
        if (match) setSelectedOpportunity(match);
      }
    } catch (err) {
      console.error('Failed to load opportunities:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOpportunities();
  }, [asOfDate, universe, selectedCategory, selectedStage, minGrade, liquidityFilter]);

  const handleToggleUserStatus = (symbol: string, setupId: string, current: string) => {
    const nextStatus: ResearchUserStatus = current === 'HIGH_PRIORITY' ? 'RESEARCH' : 'HIGH_PRIORITY';
    OpportunityScannerService.setUserStatus(symbol, setupId, nextStatus);
    setOpportunities(prev =>
      prev.map(opp =>
        opp.symbol === symbol && opp.setup.id === setupId
          ? { ...opp, userStatus: nextStatus }
          : opp
      )
    );
  };

  const handleHeatmapCellClick = (sector: string, category: SetupCategory | 'ALL') => {
    setSelectedCategory(category);
    setViewMode('TABLE');
  };

  return (
    <div className="p-6 space-y-6 max-w-[1700px] mx-auto font-mono text-xs">
      {/* Header & Mode Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              <Crosshair className="w-5 h-5 text-cyan-400" />
              <span>OPPORTUNITY DISCOVERY &amp; SETUP SCANNER</span>
            </h1>
            <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-cyan-950 border border-cyan-800 text-cyan-300">
              Phase 4C
            </span>
          </div>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Deterministic point-in-time scanning of NEPSE universe against validated setup registry condition trees.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* As-Of Date Selector */}
          <div className="flex items-center gap-1.5 bg-[#111722] border border-slate-800 rounded px-2.5 py-1 text-slate-300">
            <Calendar className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-400 text-[10px]">As-Of:</span>
            <select
              value={asOfDate}
              onChange={e => setAsOfDate(e.target.value)}
              className="bg-transparent border-none text-cyan-300 font-bold outline-none cursor-pointer text-xs"
            >
              <option value="2026-08-30" className="bg-slate-900">2026-08-30 (Live)</option>
              <option value="2026-07-15" className="bg-slate-900">2026-07-15 (Replay T1)</option>
              <option value="2026-06-01" className="bg-slate-900">2026-06-01 (Replay T0)</option>
            </select>
          </div>

          {/* View Mode Buttons */}
          <div className="flex items-center bg-[#111722] border border-slate-800 rounded p-1 gap-1">
            <button
              onClick={() => setViewMode('TABLE')}
              className={`px-2.5 py-1 rounded text-xs flex items-center gap-1.5 transition-colors ${
                viewMode === 'TABLE' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Table className="w-3.5 h-3.5" /> Table
            </button>
            <button
              onClick={() => setViewMode('CARDS')}
              className={`px-2.5 py-1 rounded text-xs flex items-center gap-1.5 transition-colors ${
                viewMode === 'CARDS' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" /> Cards
            </button>
            <button
              onClick={() => setViewMode('HEATMAP')}
              className={`px-2.5 py-1 rounded text-xs flex items-center gap-1.5 transition-colors ${
                viewMode === 'HEATMAP' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" /> Heatmap
            </button>
          </div>

          <button
            onClick={loadOpportunities}
            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            title="Refresh Scan"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-cyan-400' : ''}`} />
          </button>

          <DataSourceIndicator variant="pill" />
        </div>
      </div>

      <DataSourceIndicator variant="banner" />

      {/* Market Breadth & Crowding Summary (Section 33 & 35) */}
      {breadthStats && <OpportunityBreadthBar stats={breadthStats} />}

      {/* Filter Toolbar (Section 22) */}
      <div className="bg-[#0e131f] border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-slate-400 uppercase text-[11px] font-bold flex items-center gap-1 mr-1">
              <Filter className="w-3.5 h-3.5 text-cyan-400" /> Filters:
            </span>

            {/* Universe Selector */}
            <select
              value={universe}
              onChange={e => setUniverse(e.target.value as any)}
              className="bg-[#111722] border border-slate-800 rounded px-2.5 py-1 text-slate-200 outline-none"
            >
              <option value="ALL_NEPSE">All NEPSE Universe</option>
              <option value="COMMERCIAL_BANKS">Commercial Banks</option>
              <option value="HYDROPOWER">Hydropower</option>
              <option value="INSURANCE">Insurance</option>
              <option value="MANUFACTURING">Manufacturing</option>
            </select>

            {/* Category Selector */}
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value as any)}
              className="bg-[#111722] border border-slate-800 rounded px-2.5 py-1 text-slate-200 outline-none"
            >
              <option value="ALL">All Setup Types</option>
              <option value="BREAKOUT">Resistance Breakout</option>
              <option value="RANGE_BREAK">Breakout Retest</option>
              <option value="TREND_CONTINUATION">Trend Continuation</option>
              <option value="PULLBACK">Pullback to 20 EMA</option>
              <option value="MOMENTUM">Momentum Expansion</option>
              <option value="SQUEEZE">Volatility Squeeze</option>
              <option value="MEAN_REVERSION">Mean Reversion</option>
              <option value="RELATIVE_STRENGTH">Relative Strength Leadership</option>
              <option value="VOLUME_EXPANSION">Volume Accumulation</option>
            </select>

            {/* Stage Selector */}
            <select
              value={selectedStage}
              onChange={e => setSelectedStage(e.target.value as any)}
              className="bg-[#111722] border border-slate-800 rounded px-2.5 py-1 text-slate-200 outline-none"
            >
              <option value="ALL">All Setup Stages</option>
              <option value="CONFIRMED">CONFIRMED (Trigger + Vol)</option>
              <option value="TRIGGERED">TRIGGERED (Awaiting Vol)</option>
              <option value="FORMING">FORMING (Structure Ready)</option>
              <option value="WATCH">WATCH (Early Alignment)</option>
              <option value="INVALIDATED">INVALIDATED (Risk Exit)</option>
            </select>

            {/* Evidence Grade */}
            <select
              value={minGrade}
              onChange={e => setMinGrade(e.target.value as any)}
              className="bg-[#111722] border border-slate-800 rounded px-2.5 py-1 text-slate-200 outline-none"
            >
              <option value="ALL">All Evidence Grades</option>
              <option value="A">Grade A Only</option>
              <option value="B">Grade B and Above</option>
              <option value="C">Grade C and Above</option>
            </select>

            {/* Liquidity Gate */}
            <button
              onClick={() => setLiquidityFilter(prev => (prev === 'ALL' ? 'PASS_ONLY' : 'ALL'))}
              className={`px-2.5 py-1 rounded border transition-colors ${
                liquidityFilter === 'PASS_ONLY'
                  ? 'bg-emerald-950 border-emerald-500/50 text-emerald-300 font-bold'
                  : 'bg-[#111722] border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Liquidity Pass Only
            </button>
          </div>

          {/* Quick Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search ticker, setup..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && loadOpportunities()}
              className="bg-[#111722] border border-slate-800 rounded pl-8 pr-3 py-1 text-slate-200 placeholder-slate-500 outline-none focus:border-cyan-500 text-xs w-48"
            />
          </div>
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans">
          <div>
            Showing <strong className="text-slate-200">{opportunities.length}</strong> active setup candidates
            {selectedCategory !== 'ALL' && ` in ${selectedCategory}`}
            {selectedStage !== 'ALL' && ` [${selectedStage}]`}
          </div>
          <div className="text-slate-500">
            Click any row or card to inspect complete condition trees, risk maps, and historical evidence
          </div>
        </div>
      </div>

      {/* Main View Display */}
      {loading ? (
        <div className="p-12 text-center text-slate-400 space-y-2 bg-[#0d121d] border border-slate-800 rounded-lg">
          <RefreshCw className="w-6 h-6 animate-spin mx-auto text-cyan-400" />
          <div className="font-bold">Evaluating Universe State &amp; Condition Trees...</div>
          <div className="text-[11px] text-slate-500 font-sans">
            Enforcing point-in-time data isolation (t ≤ {asOfDate})
          </div>
        </div>
      ) : opportunities.length === 0 ? (
        <div className="p-12 text-center text-slate-400 space-y-2 bg-[#0d121d] border border-slate-800 rounded-lg">
          <Crosshair className="w-8 h-8 mx-auto text-slate-600" />
          <div className="font-bold text-slate-300">No active setups match current filters</div>
          <div className="text-xs text-slate-500 font-sans">
            Try relaxing minimum evidence grade or switching universe to ALL NEPSE.
          </div>
        </div>
      ) : (
        <>
          {/* VIEW 1: TABLE (Section 23) */}
          {viewMode === 'TABLE' && (
            <div className="bg-[#0e131f] border border-slate-800 rounded-lg overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase bg-[#090d14]">
                    <th className="py-2.5 px-3">Rank</th>
                    <th className="py-2.5 px-3">Security</th>
                    <th className="py-2.5 px-3">Setup Name</th>
                    <th className="py-2.5 px-3">Stage</th>
                    <th className="py-2.5 px-3">LTP / Entry</th>
                    <th className="py-2.5 px-3">Stop / Target</th>
                    <th className="py-2.5 px-3">R/R</th>
                    <th className="py-2.5 px-3">5D Hist Edge</th>
                    <th className="py-2.5 px-3">Robustness</th>
                    <th className="py-2.5 px-3">Macro Align</th>
                    <th className="py-2.5 px-3">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
                  {opportunities.map(opp => {
                    const isConfirmed = opp.stage === 'CONFIRMED';
                    const isTriggered = opp.stage === 'TRIGGERED';
                    const isForming = opp.stage === 'FORMING';
                    const isInvalidated = opp.stage === 'INVALIDATED';

                    const stageBadge = isConfirmed
                      ? 'bg-emerald-950 text-emerald-400 border-emerald-500/40'
                      : isTriggered
                      ? 'bg-cyan-950 text-cyan-400 border-cyan-500/40'
                      : isForming
                      ? 'bg-amber-950 text-amber-400 border-amber-500/40'
                      : isInvalidated
                      ? 'bg-rose-950 text-rose-400 border-rose-500/40'
                      : 'bg-slate-800 text-slate-400 border-slate-700';

                    return (
                      <tr
                        key={opp.id}
                        className={`hover:bg-slate-800/40 transition-colors ${
                          selectedOpportunity?.id === opp.id ? 'bg-cyan-950/20' : ''
                        }`}
                      >
                        <td className="py-3 px-3 font-bold text-slate-300">
                          #{opp.rank}
                        </td>
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => setSelectedOpportunity(opp)}
                              className="font-bold text-cyan-400 hover:underline text-sm"
                            >
                              {opp.symbol}
                            </button>
                            <button
                              onClick={() => handleToggleUserStatus(opp.symbol, opp.setup.id, opp.userStatus)}
                              className="text-slate-500 hover:text-amber-400"
                            >
                              <Bookmark className={`w-3 h-3 ${opp.userStatus === 'HIGH_PRIORITY' ? 'text-amber-400 fill-amber-400' : ''}`} />
                            </button>
                          </div>
                          <div className="text-[10px] text-slate-500 font-sans truncate max-w-[140px]">
                            {opp.sectorName}
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          <div className="font-semibold text-slate-200">{opp.setup.name}</div>
                          <div className="text-[10px] text-slate-500 font-sans truncate max-w-[200px]">
                            {opp.rankingExplanation.whyRankedHighly[0] || opp.setup.description}
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded border ${stageBadge}`}>
                            {opp.stage}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <div className="font-bold text-slate-200">Rs {opp.detectionResult.currentPrice}</div>
                          <div className="text-[10px] text-slate-500">
                            Rs {opp.detectionResult.entryZone.low}-{opp.detectionResult.entryZone.high}
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          <div className="text-rose-400 font-bold">Rs {opp.detectionResult.suggestedStopLoss}</div>
                          <div className="text-emerald-400 text-[10px]">T1: Rs {opp.detectionResult.target1}</div>
                        </td>
                        <td className="py-3 px-3 font-bold text-cyan-300">
                          {opp.detectionResult.riskRewardRatio} : 1
                        </td>
                        <td className="py-3 px-3">
                          <div className="font-bold text-emerald-400 flex items-center gap-1">
                            <span>{opp.historicalEvidence.pPositive5D}%</span>
                            <span className="text-[10px] text-slate-500 font-normal">
                              (N={opp.historicalEvidence.observations})
                            </span>
                          </div>
                          <div className="text-[9px] text-slate-500">
                            [{opp.historicalEvidence.wilsonInterval5D.lower}% - {opp.historicalEvidence.wilsonInterval5D.upper}%]
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-300">
                            Grade {opp.robustness.researchGrade}
                          </span>
                          <div className="text-[9px] text-slate-500 mt-0.5">{opp.robustness.walkForwardResult} WFO</div>
                        </td>
                        <td className="py-3 px-3">
                          <div className={`text-[10px] font-bold ${
                            opp.marketCompatibility === 'FAVORABLE' ? 'text-emerald-400' :
                            opp.marketCompatibility === 'UNFAVORABLE' ? 'text-rose-400' : 'text-slate-400'
                          }`}>
                            {opp.marketCompatibility}
                          </div>
                          <div className="text-[9px] text-slate-500">{opp.sectorRegime}</div>
                        </td>
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => setSelectedOpportunity(opp)}
                              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition-colors"
                            >
                              Inspect
                            </button>
                            {onNavigateToDecision && (
                              <button
                                onClick={() => onNavigateToDecision(opp.symbol)}
                                className="p-1 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-800/40"
                                title="Open in Decision Intelligence"
                              >
                                <ArrowUpRight className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* VIEW 2: CARDS GRID (Section 31) */}
          {viewMode === 'CARDS' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {opportunities.map(opp => (
                <OpportunitySnapshotCard
                  key={opp.id}
                  opportunity={opp}
                  onInspect={setSelectedOpportunity}
                  onNavigateToDecision={onNavigateToDecision}
                  onToggleUserStatus={handleToggleUserStatus}
                />
              ))}
            </div>
          )}

          {/* VIEW 3: HEATMAP (Section 32) */}
          {viewMode === 'HEATMAP' && (
            <OpportunityHeatmap
              opportunities={opportunities}
              selectedCategory={selectedCategory}
              onSelectCell={handleHeatmapCellClick}
            />
          )}
        </>
      )}

      {/* Opportunity Detail Drawer (Section 24) */}
      {selectedOpportunity && (
        <OpportunityDetailPanel
          opportunity={selectedOpportunity}
          onClose={() => setSelectedOpportunity(null)}
          onNavigateToDecision={onNavigateToDecision}
          onNavigateToStock={onSelectStock}
        />
      )}
    </div>
  );
}
