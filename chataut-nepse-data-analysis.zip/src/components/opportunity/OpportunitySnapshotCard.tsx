import React from 'react';
import { ScannedOpportunity } from '../../types/opportunityScanner';
import {
  ShieldCheck,
  AlertTriangle,
  ArrowUpRight,
  Crosshair,
  TrendingUp,
  Percent,
  CheckCircle2,
  Clock,
  ExternalLink,
  Bookmark,
  Star
} from 'lucide-react';

interface OpportunitySnapshotCardProps {
  opportunity: ScannedOpportunity;
  onInspect: (opp: ScannedOpportunity) => void;
  onNavigateToDecision?: (symbol: string) => void;
  onToggleUserStatus?: (symbol: string, setupId: string, current: string) => void;
  compact?: boolean;
}

export const OpportunitySnapshotCard: React.FC<OpportunitySnapshotCardProps> = ({
  opportunity: opp,
  onInspect,
  onNavigateToDecision,
  onToggleUserStatus,
  compact = false
}) => {
  const isHighConviction = opp.classification === 'HIGH_CONVICTION_RESEARCH';
  const isConfirmed = opp.stage === 'CONFIRMED';
  const isTriggered = opp.stage === 'TRIGGERED';
  const isForming = opp.stage === 'FORMING';
  const isInvalidated = opp.stage === 'INVALIDATED';

  const stageBadgeClasses = isConfirmed
    ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
    : isTriggered
    ? 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40'
    : isForming
    ? 'bg-amber-950/80 text-amber-300 border-amber-500/40'
    : isInvalidated
    ? 'bg-rose-950/80 text-rose-300 border-rose-500/40'
    : 'bg-slate-800 text-slate-400 border-slate-700';

  const gradeBadgeClasses =
    opp.robustness.researchGrade === 'A'
      ? 'bg-emerald-950 text-emerald-400 border-emerald-500/50'
      : opp.robustness.researchGrade === 'B'
      ? 'bg-cyan-950 text-cyan-400 border-cyan-500/50'
      : opp.robustness.researchGrade === 'C'
      ? 'bg-amber-950 text-amber-400 border-amber-500/50'
      : 'bg-rose-950 text-rose-400 border-rose-500/50';

  return (
    <div
      className={`bg-[#0d121d] border rounded-lg p-4 transition-all duration-150 hover:border-slate-700 flex flex-col justify-between ${
        isHighConviction
          ? 'border-cyan-500/40 shadow-[0_0_15px_rgba(6,182,212,0.06)]'
          : isInvalidated
          ? 'border-rose-900/30 opacity-75'
          : 'border-slate-800/80'
      }`}
    >
      <div>
        {/* Top Header */}
        <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-800/70">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs px-1.5 py-0.5 rounded font-mono font-bold bg-slate-800 text-slate-300">
                #{opp.rank}
              </span>
              <button
                onClick={() => onInspect(opp)}
                className="text-base font-bold text-cyan-400 hover:text-cyan-300 hover:underline tracking-wide font-mono"
              >
                {opp.symbol}
              </button>
              <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded border ${stageBadgeClasses}`}>
                {opp.stage}
              </span>
              {opp.userStatus === 'HIGH_PRIORITY' && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-950 border border-amber-500/40 text-amber-300 font-semibold flex items-center gap-1">
                  <Star className="w-2.5 h-2.5 fill-amber-400" /> Starred
                </span>
              )}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5 font-sans truncate max-w-[240px]">
              {opp.companyName} • <span className="text-slate-500">{opp.sectorName}</span>
            </div>
          </div>

          <div className="flex flex-col items-end">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-slate-400 font-mono">Score:</span>
              <span className="text-sm font-bold font-mono text-emerald-400">
                {opp.compositeOpportunityScore}/100
              </span>
            </div>
            <span className={`text-[9px] uppercase font-mono px-1.5 py-0.5 rounded border ${gradeBadgeClasses} mt-0.5`}>
              Grade {opp.robustness.researchGrade}
            </span>
          </div>
        </div>

        {/* Setup Identity */}
        <div className="my-3">
          <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5 font-mono">
            <Crosshair className="w-3.5 h-3.5 text-cyan-400" />
            <span>{opp.setup.name}</span>
          </div>
          <p className="text-[11px] text-slate-400 font-sans mt-1 line-clamp-2 leading-relaxed">
            {opp.setup.description}
          </p>
        </div>

        {/* Price & Execution Metrics Grid */}
        <div className="grid grid-cols-4 gap-1.5 bg-[#090d14] p-2.5 rounded border border-slate-800/80 font-mono text-center mb-3">
          <div>
            <div className="text-[9px] text-slate-500 uppercase">LTP</div>
            <div className="text-xs font-bold text-slate-200">Rs {opp.detectionResult.currentPrice}</div>
          </div>
          <div>
            <div className="text-[9px] text-slate-500 uppercase">Stop Loss</div>
            <div className="text-xs font-bold text-rose-400">Rs {opp.detectionResult.suggestedStopLoss}</div>
            <div className="text-[9px] text-rose-500/80">-{opp.detectionResult.stopDistancePercent}%</div>
          </div>
          <div>
            <div className="text-[9px] text-slate-500 uppercase">Target 1</div>
            <div className="text-xs font-bold text-emerald-400">Rs {opp.detectionResult.target1}</div>
            <div className="text-[9px] text-emerald-500/80">+{opp.detectionResult.target1Percent}%</div>
          </div>
          <div>
            <div className="text-[9px] text-slate-500 uppercase">R/R</div>
            <div className="text-xs font-bold text-cyan-300">{opp.detectionResult.riskRewardRatio}:1</div>
          </div>
        </div>

        {/* Historical Edge Benchmark */}
        <div className="bg-[#090d14]/70 p-2 rounded border border-slate-800/70 flex items-center justify-between text-[11px] font-mono mb-3">
          <div className="flex items-center gap-1 text-slate-400">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>5D Hist Edge:</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-emerald-400">{opp.historicalEvidence.pPositive5D}%</span>
            <span className="text-[10px] text-slate-500">
              (95% CI: {opp.historicalEvidence.wilsonInterval5D.lower}% - {opp.historicalEvidence.wilsonInterval5D.upper}%, N={opp.historicalEvidence.observations})
            </span>
          </div>
        </div>

        {/* Primary Explainability Bullet */}
        <div className="text-[11px] text-slate-300 font-sans border-l-2 border-cyan-500/60 pl-2.5 py-0.5 line-clamp-2">
          {opp.rankingExplanation.whyRankedHighly[0] || opp.detectionResult.explanation}
        </div>
      </div>

      {/* Bottom Action Footer */}
      <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => onInspect(opp)}
            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors flex items-center gap-1"
          >
            Inspect Setup
          </button>
          {onToggleUserStatus && (
            <button
              onClick={() => onToggleUserStatus(opp.symbol, opp.setup.id, opp.userStatus)}
              className="p-1 rounded text-slate-400 hover:text-amber-400 hover:bg-slate-800 transition-colors"
              title="Bookmark / Priority Watch"
            >
              <Bookmark className={`w-3.5 h-3.5 ${opp.userStatus === 'HIGH_PRIORITY' ? 'text-amber-400 fill-amber-400' : ''}`} />
            </button>
          )}
        </div>

        {onNavigateToDecision && (
          <button
            onClick={() => onNavigateToDecision(opp.symbol)}
            className="px-2.5 py-1 rounded bg-cyan-950 hover:bg-cyan-900 border border-cyan-700/50 text-cyan-300 text-xs font-medium transition-colors flex items-center gap-1"
          >
            Decision View <ArrowUpRight className="w-3 h-3" />
          </button>
        )}
      </div>
    </div>
  );
}
