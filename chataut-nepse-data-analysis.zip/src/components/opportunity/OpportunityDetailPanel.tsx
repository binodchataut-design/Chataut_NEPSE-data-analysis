import React, { useState } from 'react';
import { ScannedOpportunity } from '../../types/opportunityScanner';
import {
  X,
  Crosshair,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  Percent,
  Clock,
  ExternalLink,
  Layers,
  Activity,
  FileCode,
  DollarSign,
  Copy,
  Check
} from 'lucide-react';
import { OpportunityTransitionService } from '../../services/opportunity/opportunityTransitionService';
import { OpportunityScannerService } from '../../services/opportunity/opportunityScannerService';

interface OpportunityDetailPanelProps {
  opportunity: ScannedOpportunity;
  onClose: () => void;
  onNavigateToDecision?: (symbol: string) => void;
  onNavigateToStock?: (symbol: string) => void;
}

type DetailTab = 'OVERVIEW' | 'CONDITIONS' | 'HISTORICAL' | 'EXPLANATION' | 'AUDIT';

export function OpportunityDetailPanel({
  opportunity: opp,
  onClose,
  onNavigateToDecision,
  onNavigateToStock
}: OpportunityDetailPanelProps) {
  const [activeTab, setActiveTab] = useState<DetailTab>('OVERVIEW');
  const [copiedHash, setCopiedHash] = useState(false);

  const transitions = OpportunityTransitionService.getTransitionsForSymbol(opp.symbol);
  const auditRecord = OpportunityScannerService.getOpportunityAuditRecord(opp);

  const handleCopyHash = () => {
    navigator.clipboard.writeText(opp.auditSnapshotHash);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  // Trigger / Invalidation Map Steps (Section 25)
  const isForming = opp.stage === 'FORMING' || opp.stage === 'TRIGGERED' || opp.stage === 'CONFIRMED';
  const isTriggered = opp.stage === 'TRIGGERED' || opp.stage === 'CONFIRMED';
  const isConfirmed = opp.stage === 'CONFIRMED';
  const isInvalidated = opp.stage === 'INVALIDATED';

  return (
    <div className="fixed inset-y-0 right-0 w-full max-w-2xl bg-[#0a0e16] border-l border-slate-800 shadow-2xl z-50 flex flex-col font-mono text-xs overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 bg-[#0d121d] flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs px-2 py-0.5 rounded font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
              Rank #{opp.rank}
            </span>
            <span className="text-lg font-bold text-slate-100">{opp.symbol}</span>
            <span className="text-xs text-slate-400 font-sans">• {opp.companyName}</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5 font-sans">
            {opp.sectorName} | As-Of: {opp.asOfDate} | Engine: 4C_SCANNER_v1
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onNavigateToDecision && (
            <button
              onClick={() => onNavigateToDecision(opp.symbol)}
              className="px-2.5 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-sans text-xs font-semibold flex items-center gap-1 transition-colors"
            >
              Open Decision Intel <ExternalLink className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Setup Trigger / Invalidation Map (Section 25) */}
      <div className="bg-[#090d14] p-3 border-b border-slate-800">
        <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-2 font-bold flex items-center gap-1.5">
          <Activity className="w-3.5 h-3.5 text-cyan-400" />
          <span>Deterministic Setup Stage Progression</span>
        </div>

        <div className="grid grid-cols-5 gap-1 text-center text-[10px]">
          <div className="p-1.5 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-300">
            <div className="font-bold">1. BASE</div>
            <div className="text-[9px] opacity-80">Snapshot t≤T</div>
          </div>
          <div
            className={`p-1.5 rounded border transition-colors ${
              isForming
                ? 'bg-cyan-950/60 border-cyan-500/50 text-cyan-300 font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <div>2. FORMING</div>
            <div className="text-[9px] opacity-80">
              {opp.detectionResult.conditionsSatisfactionPercent}% Met
            </div>
          </div>
          <div
            className={`p-1.5 rounded border transition-colors ${
              isTriggered
                ? 'bg-cyan-900 border-cyan-400 text-white font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <div>3. TRIGGER</div>
            <div className="text-[9px] opacity-80">Key Level</div>
          </div>
          <div
            className={`p-1.5 rounded border transition-colors ${
              isConfirmed
                ? 'bg-emerald-900 border-emerald-400 text-white font-bold'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <div>4. CONFIRMED</div>
            <div className="text-[9px] opacity-80">Vol + Regime</div>
          </div>
          <div
            className={`p-1.5 rounded border transition-colors ${
              isInvalidated
                ? 'bg-rose-900 border-rose-400 text-white font-bold animate-pulse'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <div>5. RISK EXIT</div>
            <div className="text-[9px] opacity-80">Stop Level</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 bg-[#0e131f] border-b border-slate-800 px-4 pt-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('OVERVIEW')}
          className={`px-3 py-2 text-xs font-semibold rounded-t border-t border-x transition-colors whitespace-nowrap ${
            activeTab === 'OVERVIEW'
              ? 'bg-[#0a0e16] border-slate-800 text-cyan-400 border-b-transparent'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Overview & Execution
        </button>
        <button
          onClick={() => setActiveTab('CONDITIONS')}
          className={`px-3 py-2 text-xs font-semibold rounded-t border-t border-x transition-colors whitespace-nowrap ${
            activeTab === 'CONDITIONS'
              ? 'bg-[#0a0e16] border-slate-800 text-cyan-400 border-b-transparent'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Condition Tree ({opp.detectionResult.triggerConditions.length})
        </button>
        <button
          onClick={() => setActiveTab('HISTORICAL')}
          className={`px-3 py-2 text-xs font-semibold rounded-t border-t border-x transition-colors whitespace-nowrap ${
            activeTab === 'HISTORICAL'
              ? 'bg-[#0a0e16] border-slate-800 text-cyan-400 border-b-transparent'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Historical Evidence
        </button>
        <button
          onClick={() => setActiveTab('EXPLANATION')}
          className={`px-3 py-2 text-xs font-semibold rounded-t border-t border-x transition-colors whitespace-nowrap ${
            activeTab === 'EXPLANATION'
              ? 'bg-[#0a0e16] border-slate-800 text-cyan-400 border-b-transparent'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Ranking Explanation
        </button>
        <button
          onClick={() => setActiveTab('AUDIT')}
          className={`px-3 py-2 text-xs font-semibold rounded-t border-t border-x transition-colors whitespace-nowrap ${
            activeTab === 'AUDIT'
              ? 'bg-[#0a0e16] border-slate-800 text-cyan-400 border-b-transparent'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Lifecycle & Audit
        </button>
      </div>

      {/* Tab Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* TAB 1: OVERVIEW & EXECUTION */}
        {activeTab === 'OVERVIEW' && (
          <div className="space-y-4">
            {/* Setup Description */}
            <div className="p-3 bg-[#0e131f] border border-slate-800 rounded-lg">
              <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Crosshair className="w-4 h-4 text-cyan-400" />
                <span>{opp.setup.name}</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-300">
                  {opp.setup.category}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-sans mt-1.5 leading-relaxed">
                {opp.setup.description}
              </p>
            </div>

            {/* Price & Order Execution Boundaries */}
            <div className="p-4 bg-[#0e131f] border border-slate-800 rounded-lg space-y-3">
              <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Price Structure & Order Execution Zones
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="p-2.5 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">Entry Reference</div>
                  <div className="text-sm font-bold text-slate-100 mt-0.5">
                    Rs {opp.detectionResult.entryZone.low} - {opp.detectionResult.entryZone.high}
                  </div>
                </div>

                <div className="p-2.5 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">Stop Loss Reference</div>
                  <div className="text-sm font-bold text-rose-400 mt-0.5">
                    Rs {opp.detectionResult.suggestedStopLoss}
                  </div>
                  <div className="text-[10px] text-rose-500/80">-{opp.detectionResult.stopDistancePercent}%</div>
                </div>

                <div className="p-2.5 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">Target 1 & 2</div>
                  <div className="text-sm font-bold text-emerald-400 mt-0.5">
                    Rs {opp.detectionResult.target1} / {opp.detectionResult.target2}
                  </div>
                  <div className="text-[10px] text-emerald-500/80">+{opp.detectionResult.target1Percent}% / +{opp.detectionResult.target2Percent}%</div>
                </div>

                <div className="p-2.5 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">Risk/Reward</div>
                  <div className="text-sm font-bold text-cyan-300 mt-0.5">
                    {opp.detectionResult.riskRewardRatio} : 1
                  </div>
                </div>
              </div>

              {/* NEPSE Friction Reality Breakdown (Section 17) */}
              <div className="p-3 bg-[#090d14] rounded border border-slate-800/80 space-y-1.5 text-[11px]">
                <div className="text-slate-400 font-bold">NEPSE Transactional Friction Model:</div>
                <div className="flex justify-between text-slate-400">
                  <span>Estimated Brokerage (Round-Trip):</span>
                  <span className="text-slate-200">{(opp.execution.estimatedBrokeragePercent * 2).toFixed(2)}%</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>SEBON Regulatory Fee:</span>
                  <span className="text-slate-200">{(opp.execution.estimatedSebonFeePercent * 2).toFixed(3)}%</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Slippage & Impact Model:</span>
                  <span className="text-slate-200">{(opp.execution.estimatedSlippagePercent * 2).toFixed(2)}%</span>
                </div>
                <div className="flex justify-between text-slate-300 pt-1 border-t border-slate-800 font-bold">
                  <span>Total Estimated Friction:</span>
                  <span className="text-amber-400">{opp.execution.totalRoundTripFrictionPercent}%</span>
                </div>
              </div>

              {opp.execution.circuitConstraintWarning && (
                <div className="p-2.5 bg-amber-950/30 border border-amber-500/40 rounded text-amber-300 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Price trading near daily 10% circuit limit. Circuit breaker constraint active.</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: CONDITION TREE (Section 6) */}
        {activeTab === 'CONDITIONS' && (
          <div className="space-y-4">
            <div className="text-xs text-slate-400 font-sans">
              Explicit condition tree evaluation against snapshot metrics. No hidden black-box magic numbers.
            </div>

            {/* Triggers & Gates */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-300 uppercase">
                Active Setup Conditions ({opp.detectionResult.triggerConditions.length})
              </div>
              {opp.detectionResult.triggerConditions.map((cond, idx) => (
                <div
                  key={idx}
                  className={`p-2.5 rounded border flex items-start justify-between gap-3 ${
                    cond.passed
                      ? 'bg-[#090d14] border-emerald-900/40 text-slate-200'
                      : 'bg-[#090d14] border-slate-800 text-slate-400'
                  }`}
                >
                  <div>
                    <div className="font-bold flex items-center gap-1.5">
                      {cond.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <span className="w-3.5 h-3.5 text-slate-500 font-bold">○</span>
                      )}
                      <span>{cond.label}</span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                        {cond.category}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 font-sans mt-0.5">
                      {cond.explanation}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-bold">{String(cond.actualValue)}</div>
                    <div className="text-[10px] text-slate-500">{cond.operator} {String(cond.threshold)}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Missing Conditions if any */}
            {opp.detectionResult.missingConditions.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="text-xs font-bold text-amber-400 uppercase">
                  Missing Prerequisite Conditions ({opp.detectionResult.missingConditions.length})
                </div>
                {opp.detectionResult.missingConditions.map((cond, idx) => (
                  <div key={idx} className="p-2.5 rounded border border-amber-900/30 bg-amber-950/10 text-amber-200">
                    <div className="font-bold">{cond.label}</div>
                    <div className="text-[11px] text-amber-300/80 font-sans mt-0.5">{cond.explanation}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: HISTORICAL EVIDENCE (Section 11 & 12) */}
        {activeTab === 'HISTORICAL' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div className="p-2.5 bg-[#0e131f] rounded border border-slate-800">
                <div className="text-[10px] text-slate-500">Sample Size</div>
                <div className="text-sm font-bold text-slate-200 mt-0.5">
                  N={opp.historicalEvidence.observations}
                </div>
                <div className="text-[9px] text-slate-400">Tier: {opp.historicalEvidence.sampleTier}</div>
              </div>

              <div className="p-2.5 bg-[#0e131f] rounded border border-slate-800">
                <div className="text-[10px] text-slate-500">5D Positive Rate</div>
                <div className="text-sm font-bold text-emerald-400 mt-0.5">
                  {opp.historicalEvidence.pPositive5D}%
                </div>
                <div className="text-[9px] text-slate-400">
                  95% CI: [{opp.historicalEvidence.wilsonInterval5D.lower}% - {opp.historicalEvidence.wilsonInterval5D.upper}%]
                </div>
              </div>

              <div className="p-2.5 bg-[#0e131f] rounded border border-slate-800">
                <div className="text-[10px] text-slate-500">Expected 5D Return</div>
                <div className="text-sm font-bold text-cyan-300 mt-0.5">
                  +{opp.historicalEvidence.meanReturn5D}%
                </div>
                <div className="text-[9px] text-slate-400">Median: +{opp.historicalEvidence.medianReturn5D}%</div>
              </div>

              <div className="p-2.5 bg-[#0e131f] rounded border border-slate-800">
                <div className="text-[10px] text-slate-500">Evidence Grade</div>
                <div className="text-sm font-bold text-emerald-400 mt-0.5">
                  Grade {opp.robustness.researchGrade}
                </div>
                <div className="text-[9px] text-slate-400">{opp.robustness.walkForwardResult} WFO</div>
              </div>
            </div>

            {/* Holding Horizon Rates */}
            <div className="p-3 bg-[#0e131f] border border-slate-800 rounded-lg space-y-2">
              <div className="text-xs font-bold text-slate-300 uppercase">
                Success Rates Across Holding Horizons
              </div>
              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="p-2 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">1 Day</div>
                  <div className="font-bold text-slate-200">{opp.historicalEvidence.pPositive1D}%</div>
                </div>
                <div className="p-2 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">5 Days</div>
                  <div className="font-bold text-emerald-400">{opp.historicalEvidence.pPositive5D}%</div>
                </div>
                <div className="p-2 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">10 Days</div>
                  <div className="font-bold text-cyan-400">{opp.historicalEvidence.pPositive10D}%</div>
                </div>
                <div className="p-2 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">20 Days</div>
                  <div className="font-bold text-cyan-300">{opp.historicalEvidence.pPositive20D}%</div>
                </div>
              </div>
            </div>

            {/* Regime Performance Breakdown (Section 34) */}
            <div className="p-3 bg-[#0e131f] border border-slate-800 rounded-lg space-y-2">
              <div className="text-xs font-bold text-slate-300 uppercase">
                Historical Performance by Market Regime
              </div>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="p-2 bg-[#090d14] rounded border border-emerald-900/30">
                  <div className="text-[10px] text-emerald-400 font-bold">BULL REGIME</div>
                  <div className="text-sm font-bold text-slate-100 mt-1">
                    {opp.historicalEvidence.regimePerformance.bull.winRate}%
                  </div>
                  <div className="text-[9px] text-slate-400">
                    Mean: +{opp.historicalEvidence.regimePerformance.bull.meanReturn}% (N={opp.historicalEvidence.regimePerformance.bull.observations})
                  </div>
                </div>

                <div className="p-2 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-bold">SIDEWAYS REGIME</div>
                  <div className="text-sm font-bold text-slate-100 mt-1">
                    {opp.historicalEvidence.regimePerformance.sideways.winRate}%
                  </div>
                  <div className="text-[9px] text-slate-400">
                    Mean: +{opp.historicalEvidence.regimePerformance.sideways.meanReturn}% (N={opp.historicalEvidence.regimePerformance.sideways.observations})
                  </div>
                </div>

                <div className="p-2 bg-[#090d14] rounded border border-rose-900/30">
                  <div className="text-[10px] text-rose-400 font-bold">BEAR REGIME</div>
                  <div className="text-sm font-bold text-slate-100 mt-1">
                    {opp.historicalEvidence.regimePerformance.bear.winRate}%
                  </div>
                  <div className="text-[9px] text-slate-400">
                    Mean: {opp.historicalEvidence.regimePerformance.bear.meanReturn}% (N={opp.historicalEvidence.regimePerformance.bear.observations})
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: EXPLANATION (Section 21) */}
        {activeTab === 'EXPLANATION' && (
          <div className="space-y-4">
            {/* Why Ranked Highly */}
            <div className="p-3 bg-emerald-950/20 border border-emerald-900/40 rounded-lg space-y-2">
              <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 uppercase tracking-wider">
                <CheckCircle2 className="w-4 h-4" />
                <span>Why This Setup is Ranked Highly</span>
              </div>
              <ul className="space-y-1.5 font-sans text-xs text-slate-200">
                {opp.rankingExplanation.whyRankedHighly.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Reasons Preventing Higher Rank */}
            <div className="p-3 bg-amber-950/20 border border-amber-900/40 rounded-lg space-y-2">
              <div className="text-xs font-bold text-amber-400 flex items-center gap-1.5 uppercase tracking-wider">
                <AlertTriangle className="w-4 h-4" />
                <span>Factors Preventing Higher Rank</span>
              </div>
              <ul className="space-y-1.5 font-sans text-xs text-slate-300">
                {opp.rankingExplanation.reasonsPreventingHigherRank.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {/* TAB 5: LIFECYCLE & AUDIT (Section 26, 27, 45) */}
        {activeTab === 'AUDIT' && (
          <div className="space-y-4">
            {/* Validity Window */}
            <div className="p-3 bg-[#0e131f] border border-slate-800 rounded-lg space-y-1.5">
              <div className="text-xs font-bold text-slate-300 uppercase">
                Setup Validity Window (Section 26)
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-[11px] pt-1">
                <div className="p-2 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">Triggered On</div>
                  <div className="font-bold text-slate-200">{opp.detectionResult.validityWindow.triggeredDate}</div>
                </div>
                <div className="p-2 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">Valid Through</div>
                  <div className="font-bold text-slate-200">{opp.detectionResult.validityWindow.validThroughDate}</div>
                </div>
                <div className="p-2 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">Sessions Remaining</div>
                  <div className="font-bold text-cyan-300">{opp.detectionResult.validityWindow.sessionsRemaining} Days</div>
                </div>
              </div>
            </div>

            {/* Transition Log (Section 27) */}
            <div className="p-3 bg-[#0e131f] border border-slate-800 rounded-lg space-y-2">
              <div className="text-xs font-bold text-slate-300 uppercase">
                Stage Transition History
              </div>
              {transitions.length > 0 ? (
                <div className="space-y-2">
                  {transitions.map((t, idx) => (
                    <div key={idx} className="p-2 bg-[#090d14] rounded border border-slate-800 text-[11px]">
                      <div className="flex items-center justify-between text-slate-400">
                        <span className="font-bold text-cyan-400">
                          {t.fromStage} → {t.toStage}
                        </span>
                        <span>{t.asOfDate}</span>
                      </div>
                      <div className="text-slate-300 font-sans mt-0.5">{t.reason}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-slate-500 text-xs">No prior transitions recorded for this symbol.</div>
              )}
            </div>

            {/* Cryptographic Audit Hash (Section 45) */}
            <div className="p-3 bg-[#0e131f] border border-slate-800 rounded-lg space-y-2">
              <div className="text-xs font-bold text-slate-300 uppercase flex items-center justify-between">
                <span>Cryptographic Snapshot Hash</span>
                <button
                  onClick={handleCopyHash}
                  className="text-cyan-400 hover:text-cyan-300 text-[10px] flex items-center gap-1"
                >
                  {copiedHash ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedHash ? 'Copied' : 'Copy Hash'}</span>
                </button>
              </div>
              <div className="p-2 bg-[#090d14] rounded border border-slate-800 text-[10px] text-slate-400 break-all select-all">
                {opp.auditSnapshotHash}
              </div>
              <div className="text-[10px] text-slate-500 font-sans">
                Point-in-time state hash generated at t≤{opp.asOfDate}. Replay verification guarantees future mutation invariance.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
