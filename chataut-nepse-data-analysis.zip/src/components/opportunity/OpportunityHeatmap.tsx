import React from 'react';
import { ScannedOpportunity, SetupCategory } from '../../types/opportunityScanner';
import { LayoutGrid, Filter } from 'lucide-react';

interface OpportunityHeatmapProps {
  opportunities: ScannedOpportunity[];
  selectedSector?: string;
  selectedCategory?: SetupCategory | 'ALL';
  onSelectCell: (sector: string, category: SetupCategory | 'ALL') => void;
}

export function OpportunityHeatmap({
  opportunities,
  selectedSector,
  selectedCategory,
  onSelectCell
}: OpportunityHeatmapProps) {
  const categories: SetupCategory[] = [
    'BREAKOUT',
    'RANGE_BREAK',
    'TREND_CONTINUATION',
    'PULLBACK',
    'MOMENTUM',
    'SQUEEZE',
    'MEAN_REVERSION',
    'RELATIVE_STRENGTH',
    'VOLUME_EXPANSION'
  ];

  // Distinct sectors from scanned opportunities (fallback to common NEPSE sectors)
  const sectors = Array.from(
    new Set(opportunities.map(o => o.sectorName))
  ).filter(Boolean);

  if (sectors.length === 0) {
    sectors.push('Commercial Banks', 'Hydropower', 'Manufacturing & Processing', 'Life Insurance');
  }

  // Build matrix count map: sector -> category -> count
  const matrix: Record<string, Record<string, number>> = {};
  sectors.forEach(s => {
    matrix[s] = {};
    categories.forEach(c => {
      matrix[s][c] = 0;
    });
  });

  opportunities.forEach(opp => {
    if (matrix[opp.sectorName] && matrix[opp.sectorName][opp.setup.category] !== undefined) {
      matrix[opp.sectorName][opp.setup.category]++;
    }
  });

  const getCellColor = (count: number) => {
    if (count === 0) return 'bg-[#090d14] text-slate-600 border-slate-900';
    if (count === 1) return 'bg-cyan-950/40 text-cyan-300 border-cyan-800/40 font-bold';
    if (count === 2) return 'bg-cyan-900/60 text-cyan-200 border-cyan-600/50 font-bold';
    return 'bg-cyan-700 text-white border-cyan-400 font-extrabold shadow-[0_0_8px_rgba(6,182,212,0.3)]';
  };

  return (
    <div className="bg-[#0e131f] border border-slate-800 rounded-lg p-4 font-mono text-xs overflow-x-auto">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
        <div className="flex items-center gap-2">
          <LayoutGrid className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-200 uppercase tracking-wider">
            Sector × Setup Opportunity Heatmap
          </span>
        </div>
        <div className="text-[11px] text-slate-400 font-sans">
          Click any cell to filter the scanner workstation
        </div>
      </div>

      <table className="w-full border-collapse text-center">
        <thead>
          <tr className="border-b border-slate-800">
            <th className="text-left py-2 px-3 text-slate-400 font-semibold text-[11px] min-w-[160px]">
              Sector / Setup Category
            </th>
            {categories.map(cat => (
              <th
                key={cat}
                className="py-2 px-2 text-slate-400 font-semibold text-[10px] whitespace-nowrap"
              >
                {cat.replace('_', ' ')}
              </th>
            ))}
            <th className="py-2 px-3 text-slate-300 font-bold text-[11px]">Total</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800/60">
          {sectors.map(sector => {
            const rowTotal = categories.reduce((sum, cat) => sum + (matrix[sector]?.[cat] || 0), 0);
            const isSectorSelected = selectedSector === sector;

            return (
              <tr key={sector} className={`hover:bg-slate-800/30 ${isSectorSelected ? 'bg-slate-800/50' : ''}`}>
                <td className="text-left py-2 px-3 font-sans text-xs text-slate-300 font-medium whitespace-nowrap">
                  {sector}
                </td>
                {categories.map(cat => {
                  const count = matrix[sector]?.[cat] || 0;
                  const isCellActive = isSectorSelected && selectedCategory === cat;

                  return (
                    <td key={cat} className="p-1">
                      <button
                        onClick={() => onSelectCell(sector, cat)}
                        className={`w-full py-1.5 px-2 rounded border text-xs transition-all ${getCellColor(
                          count
                        )} ${isCellActive ? 'ring-2 ring-cyan-400' : ''}`}
                        title={`${sector} • ${cat}: ${count} opportunities`}
                      >
                        {count > 0 ? count : '—'}
                      </button>
                    </td>
                  );
                })}
                <td className="py-2 px-3 font-bold text-slate-200">
                  <button
                    onClick={() => onSelectCell(sector, 'ALL')}
                    className="hover:underline text-cyan-400"
                  >
                    {rowTotal}
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
