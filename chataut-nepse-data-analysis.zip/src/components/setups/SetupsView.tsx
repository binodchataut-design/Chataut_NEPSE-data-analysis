import { useState, useEffect } from 'react';
import { SetupDetection, SetupType } from '../../types';
import { setupService } from '../../services/setupService';
import { SetupDefinitionService } from '../../services/opportunity/setupDefinitionService';
import { SetupDefinition } from '../../types/opportunityScanner';
import {
  Crosshair,
  AlertTriangle,
  ArrowRight,
  Filter,
  Sliders,
  BookOpen,
  Layers,
  CheckCircle2,
  TrendingUp,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { formatNPR } from '../../utils/formatters';
import { DataSourceIndicator } from '../layout/DataSourceIndicator';

interface SetupsViewProps {
  onSelectStock: (symbol: string) => void;
  onNavigateToScanner?: () => void;
}

export function SetupsView({ onSelectStock, onNavigateToScanner }: SetupsViewProps) {
  const [activeTab, setActiveTab] = useState<'DEFINITIONS' | 'CANDIDATES'>('DEFINITIONS');
  const [setups, setSetups] = useState<SetupDetection[]>([]);
  const [setupDefinitions, setSetupDefinitions] = useState<SetupDefinition[]>([]);
  const [setupTypes, setSetupTypes] = useState<Array<{ type: SetupType; label: string; description: string }>>([]);
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [selectedDefinition, setSelectedDefinition] = useState<SetupDefinition | null>(null);

  useEffect(() => {
    setupService.getDetectedSetups().then(setSetups);
    setupService.getSetupTypes().then(setSetupTypes);
    const defs = SetupDefinitionService.getAllSetups();
    setSetupDefinitions(defs);
    if (defs.length > 0) setSelectedDefinition(defs[0]);
  }, []);

  const filteredSetups = selectedType === 'ALL'
    ? setups
    : setups.filter(s => s.setupType === selectedType);

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto font-mono text-xs">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Crosshair className="w-5 h-5 text-cyan-400" />
            <span>TRADING SETUP REGISTRY &amp; DEFINITIONS</span>
          </h1>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Single source of truth for setup definitions, explicit condition trees, invalidation rules, and historical validity benchmarks.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {onNavigateToScanner && (
            <button
              onClick={onNavigateToScanner}
              className="px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-sans text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-lg shadow-cyan-950"
            >
              <Zap className="w-4 h-4" />
              <span>Launch Opportunity Scanner</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
          <DataSourceIndicator variant="pill" />
        </div>
      </div>

      <DataSourceIndicator variant="banner" />

      {/* Mode Switcher */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('DEFINITIONS')}
          className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors ${
            activeTab === 'DEFINITIONS'
              ? 'bg-cyan-600 text-white shadow'
              : 'bg-[#111722] text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Setup Registry &amp; Condition Trees ({setupDefinitions.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('CANDIDATES')}
          className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors ${
            activeTab === 'CANDIDATES'
              ? 'bg-cyan-600 text-white shadow'
              : 'bg-[#111722] text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Historical Setup Analysis &amp; Candidates ({setups.length})</span>
        </button>
      </div>

      {/* VIEW 1: SETUP REGISTRY & CONDITION TREES */}
      {activeTab === 'DEFINITIONS' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Setup List Sidebar */}
          <div className="lg:col-span-1 space-y-2">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
              Standardized Setup Library (9 Patterns)
            </div>
            {setupDefinitions.map(def => {
              const isSelected = selectedDefinition?.id === def.id;
              return (
                <div
                  key={def.id}
                  onClick={() => setSelectedDefinition(def)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#141d2c] border-cyan-500/60 shadow-md'
                      : 'bg-[#0e131f] border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-100">{def.name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800/60">
                      {def.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-sans mt-1 line-clamp-2">
                    {def.description}
                  </p>
                  <div className="flex items-center gap-3 mt-2 text-[10px] text-slate-500">
                    <span>Horizon: {def.recommendedHorizonDays}D</span>
                    <span>Min Win: {def.minimumHistoricalEvidence?.minimumWinRate5D}%</span>
                    <span>Grade: {def.minimumHistoricalEvidence?.minimumEvidenceGrade}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Setup Detail & Condition Tree */}
          {selectedDefinition && (
            <div className="lg:col-span-2 space-y-4 bg-[#0e131f] border border-slate-800 rounded-lg p-5">
              <div className="flex items-start justify-between pb-3 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-slate-100">{selectedDefinition.name}</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-300">
                      Category: {selectedDefinition.category}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                      v{selectedDefinition.version}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 font-sans mt-1">
                    {selectedDefinition.description}
                  </p>
                </div>

                {onNavigateToScanner && (
                  <button
                    onClick={onNavigateToScanner}
                    className="px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-1 shrink-0"
                  >
                    Scan Universe <ArrowRight className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* Requirements Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                <div className="p-2.5 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">Max Stop Distance</div>
                  <div className="text-sm font-bold text-rose-400 mt-0.5">
                    {selectedDefinition.riskRequirements.maxStopLossPercent}%
                  </div>
                </div>
                <div className="p-2.5 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">Min Risk / Reward</div>
                  <div className="text-sm font-bold text-cyan-300 mt-0.5">
                    {selectedDefinition.riskRequirements.minimumRiskRewardRatio} : 1
                  </div>
                </div>
                <div className="p-2.5 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">Min Observations</div>
                  <div className="text-sm font-bold text-slate-200 mt-0.5">
                    N={selectedDefinition.minimumHistoricalEvidence?.minimumObservations}
                  </div>
                </div>
                <div className="p-2.5 bg-[#090d14] rounded border border-slate-800">
                  <div className="text-[10px] text-slate-500">Benchmark Win Rate</div>
                  <div className="text-sm font-bold text-emerald-400 mt-0.5">
                    {selectedDefinition.minimumHistoricalEvidence?.minimumWinRate5D}%
                  </div>
                </div>
              </div>

              {/* Condition Tree Node Structure */}
              <div className="p-4 bg-[#090d14] rounded border border-slate-800 space-y-3">
                <div className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Deterministic Rule Nodes (Logical Condition Tree: AND)</span>
                </div>

                <div className="space-y-2">
                  {selectedDefinition.conditions.children?.map((child, idx) => {
                    const leaf = child.leaf;
                    if (!leaf) return null;
                    return (
                      <div
                        key={idx}
                        className="p-2.5 bg-[#0e131f] rounded border border-slate-800/90 flex items-center justify-between gap-3 text-xs"
                      >
                        <div>
                          <div className="font-bold text-slate-200 flex items-center gap-2">
                            <span className="text-cyan-400 font-mono">[{leaf.category}]</span>
                            <span>{leaf.label}</span>
                          </div>
                          <div className="text-[11px] text-slate-400 font-sans mt-0.5">
                            {leaf.description}
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="font-mono text-cyan-300 font-bold">
                            {leaf.field} {leaf.operator} {String(leaf.threshold)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Invalidation Rules */}
              <div className="p-4 bg-rose-950/20 rounded border border-rose-900/30 space-y-2">
                <div className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                  <span>Deterministic Invalidation Criteria (Logical Tree: OR)</span>
                </div>
                <div className="space-y-1.5">
                  {selectedDefinition.invalidationRules.children?.map((child, idx) => {
                    const leaf = child.leaf;
                    if (!leaf) return null;
                    return (
                      <div key={idx} className="text-xs text-rose-200 flex items-start gap-2">
                        <span className="text-rose-400 font-bold">✕</span>
                        <div>
                          <strong>{leaf.label}:</strong> {leaf.description}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: HISTORICAL SETUP ANALYSIS & CANDIDATES */}
      {activeTab === 'CANDIDATES' && (
        <div className="space-y-4">
          {/* Filter Tabs */}
          <div className="bg-[#111722] border border-slate-800 rounded-lg p-3 flex items-center gap-2 overflow-x-auto scrollbar-none">
            <span className="text-slate-400 text-[11px] uppercase mr-2 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-cyan-400" /> Pattern:
            </span>
            <button
              onClick={() => setSelectedType('ALL')}
              className={`px-2.5 py-1 rounded text-xs font-semibold ${
                selectedType === 'ALL' ? 'bg-cyan-600 text-white' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
              }`}
            >
              All Detected ({setups.length})
            </button>
            {setupTypes.map(st => (
              <button
                key={st.type}
                onClick={() => setSelectedType(st.type)}
                className={`px-2.5 py-1 rounded text-xs whitespace-nowrap ${
                  selectedType === st.type ? 'bg-cyan-600 text-white' : 'bg-slate-900 text-slate-400 hover:bg-slate-800'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>

          {/* Setup Cards Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredSetups.map(setup => (
              <div
                key={setup.id}
                className="bg-[#111722] border border-slate-800 rounded-lg p-5 flex flex-col justify-between hover:border-slate-700 transition-colors"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between pb-3 border-b border-slate-800">
                    <div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onSelectStock(setup.symbol)}
                          className="text-lg font-bold text-cyan-400 hover:underline"
                        >
                          {setup.symbol}
                        </button>
                        <span className="text-slate-400 text-xs">{setup.companyName}</span>
                      </div>
                      <div className="text-slate-500 text-[11px] mt-0.5">
                        Sector: {setup.sectorName} | Detected: {setup.detectionDate}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-base font-bold text-emerald-400">
                        Score: {setup.scores.overall}/100
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded uppercase font-semibold bg-cyan-950 border border-cyan-800 text-cyan-300">
                        {setup.setupName}
                      </span>
                    </div>
                  </div>

                  {/* Price Zones */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    <div className="bg-[#0b0f17] p-2 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-400">Entry Zone</div>
                      <div className="font-bold text-slate-100 mt-0.5">
                        Rs. {setup.entryZoneLow} - {setup.entryZoneHigh}
                      </div>
                    </div>
                    <div className="bg-[#0b0f17] p-2 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-400">Stop Loss</div>
                      <div className="font-bold text-rose-400 mt-0.5">
                        Rs. {setup.stopLoss}
                      </div>
                    </div>
                    <div className="bg-[#0b0f17] p-2 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-400">Target 1 &amp; 2</div>
                      <div className="font-bold text-emerald-400 mt-0.5">
                        Rs. {setup.target1} / {setup.target2}
                      </div>
                    </div>
                    <div className="bg-[#0b0f17] p-2 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-400">Risk/Reward</div>
                      <div className="font-bold text-cyan-300 mt-0.5">
                        {setup.riskRewardRatio} : 1
                      </div>
                    </div>
                  </div>

                  {/* Conditions / Reasons */}
                  <div className="p-3 bg-[#0b0f17] rounded border border-slate-800 space-y-1">
                    <div className="text-[11px] font-bold text-slate-300">CONFIRMATION CRITERIA:</div>
                    {setup.reasons.map((r, i) => (
                      <div key={i} className="text-[11px] text-slate-300 flex items-start gap-1.5">
                        <span className="text-emerald-400 font-bold">✓</span>
                        <span>{r}</span>
                      </div>
                    ))}
                  </div>

                  {/* Invalidation Rule */}
                  <div className="p-2.5 bg-rose-950/20 border border-rose-900/30 rounded text-[11px] text-rose-300 flex items-start gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                    <div>
                      <strong>Deterministic Invalidation:</strong> {setup.invalidationCriteria}
                    </div>
                  </div>
                </div>

                <div className="pt-3 mt-3 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">Confidence: {setup.confidencePercent}%</span>
                  <button
                    onClick={() => onSelectStock(setup.symbol)}
                    className="px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-1 transition-colors"
                  >
                    Research Stock <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
