/**
 * Opportunity Scanner Service (Phase 4C)
 * Central engine scanning the NEPSE universe against the Setup Registry.
 * Integrates Point-in-Time Snapshot (4A), Detection, Historical Evidence (3B/3C),
 * Robustness Gate (3D), Execution Reality, Ranking, Crowding, and Audit.
 */

import { CurrentStateSnapshotService } from '../currentStateSnapshotService';
import { CurrentMarketAndStockSnapshot } from '../../types/currentStateEngine';
import {
  ScannedOpportunity,
  OpportunityScannerFilterParams,
  OpportunityBreadthStats,
  OpportunityAuditRecord,
  ResearchUserStatus,
  SetupCategory,
  SetupCompatibility
} from '../../types/opportunityScanner';
import { SetupDefinitionService } from './setupDefinitionService';
import { SetupDetectionService } from './setupDetectionService';
import { SetupEvidenceService } from './setupEvidenceService';
import { SetupValidationService } from './setupValidationService';
import { SetupRankingService } from './setupRankingService';
import { OpportunityExplanationService } from './opportunityExplanationService';
import { OpportunityTransitionService } from './opportunityTransitionService';
import { normalizedCompanies, normalizedSectors } from '../../data/normalizedMasterData';
import { ActiveUniverseService } from '../activeUniverseService';

export class OpportunityScannerService {
  public static readonly SCANNER_VERSION = '4C_SCANNER_v1';

  // User Research Watchlist tags (in-memory)
  private static userStatuses: Map<string, ResearchUserStatus> = new Map();

  /**
   * Scans NEPSE universe for setups matching point-in-time state
   */
  public static async scanUniverse(
    filterParams?: OpportunityScannerFilterParams
  ): Promise<ScannedOpportunity[]> {
    const asOfDate = filterParams?.asOfDate || '2026-08-30';

    // 1. Identify target symbols based on universe filter
    let symbols = normalizedCompanies.map(c => c.symbol);

    if (filterParams?.selectedSector && filterParams.selectedSector !== 'ALL') {
      const matchedSector = normalizedSectors.find(s => s.name.toLowerCase() === filterParams.selectedSector?.toLowerCase());
      symbols = normalizedCompanies
        .filter(c => matchedSector ? c.sector_id === matchedSector.id : false)
        .map(c => c.symbol);
    } else if (filterParams?.universe && filterParams.universe !== 'ALL_NEPSE') {
      const sectorIdMap: Record<string, string> = {
        COMMERCIAL_BANKS: 'sec-cb',
        HYDROPOWER: 'sec-hyd',
        INSURANCE: 'sec-li',
        MANUFACTURING: 'sec-man',
        FINANCE: 'sec-fin'
      };
      const targetSectorId = sectorIdMap[filterParams.universe];
      if (targetSectorId) {
        symbols = normalizedCompanies
          .filter(c => c.sector_id === targetSectorId)
          .map(c => c.symbol);
      }
    }

    // Filter out non-ordinary equities, merged, delisted, and suspended stocks as of asOfDate
    const eligibleSymbols = symbols.filter(s =>
      ActiveUniverseService.isEligibleForActiveUniverse(s, asOfDate, false)
    );

    // Default to scanning the universe (take up to 16 key representative companies for instant speed)
    const targetSymbols = eligibleSymbols.length > 0 ? eligibleSymbols.slice(0, 16) : ['CHCL', 'NABIL', 'SHIVM', 'UPPER', 'HDL', 'GBIME', 'CIT', 'NICA', 'NLIC'];

    const rawOpportunities: ScannedOpportunity[] = [];

    // 2. Evaluate each symbol point-in-time
    for (const symbol of targetSymbols) {
      try {
        const snapshot: CurrentMarketAndStockSnapshot = await CurrentStateSnapshotService.getSnapshot(
          symbol,
          asOfDate
        );

        const detections = SetupDetectionService.evaluateAllSetups(snapshot);

        for (const detection of detections) {
          const setupDef = SetupDefinitionService.getSetupById(detection.setupId);
          if (!setupDef) continue;

          // A. Historical Evidence (Phase 3B/3C)
          const historical = SetupEvidenceService.calculateHistoricalEvidence(setupDef, snapshot);

          // B. Robustness Gate & Execution Reality (Phase 3D)
          const robustness = SetupValidationService.evaluateRobustness(setupDef, snapshot, historical.evidenceGrade);
          const execution = SetupValidationService.evaluateExecutionReality(detection, snapshot);

          // C. Market Compatibility
          let marketCompatibility: SetupCompatibility = 'NEUTRAL';
          if (setupDef.preferredMarketRegimes?.includes(snapshot.marketState.regime)) {
            marketCompatibility = 'FAVORABLE';
          } else if (snapshot.marketState.regime === 'BEAR') {
            marketCompatibility = 'UNFAVORABLE';
          }

          // D. Sector Alignment
          const sectorRs = snapshot.sectorState.relativeStrengthVsNepse.state;
          const setupSectorAlignment = sectorRs === 'STRONG_OUTPERFORMER' || sectorRs === 'OUTPERFORMER'
            ? 'HIGH'
            : sectorRs === 'INLINE' ? 'MODERATE' : 'LOW';

          // E. Lifecycle & User Status
          const lifecycleStatus = OpportunityTransitionService.evaluateLifecycleStatus(
            symbol,
            setupDef.id,
            detection.stage
          );
          const userStatusKey = `${symbol}_${setupDef.id}`;
          const userStatus = this.userStatuses.get(userStatusKey) || 'RESEARCH';

          // F. Classification & Explanation
          const classification = OpportunityExplanationService.determineClassification(
            detection,
            historical,
            robustness,
            marketCompatibility
          );

          const rankingExplanation = OpportunityExplanationService.generateRankingExplanation(
            setupDef,
            detection,
            historical,
            robustness,
            execution,
            snapshot,
            marketCompatibility
          );

          // G. Deterministic Snapshot Hash
          const hashInput = `${symbol}_${setupDef.id}_${asOfDate}_${detection.stage}_${detection.currentPrice}_${historical.observations}`;
          const auditSnapshotHash = this.simpleHash(hashInput);

          rawOpportunities.push({
            id: `opp_${symbol}_${setupDef.id}_${asOfDate}`,
            symbol,
            companyName: snapshot.stockState.companyName,
            sectorName: snapshot.stockState.sectorName,
            asOfDate,
            dataSource: snapshot.stateAvailability?.dataSourceMode || 'REAL_DATA',
            setup: setupDef,
            stage: detection.stage,
            lifecycleStatus,
            userStatus,
            marketRegime: snapshot.marketState.regime,
            marketCompatibility,
            sectorRegime: sectorRs === 'STRONG_OUTPERFORMER' ? 'LEADING' : 'IMPROVING',
            sectorRelativeStrength: sectorRs === 'STRONG_OUTPERFORMER' || sectorRs === 'OUTPERFORMER' ? 'POSITIVE' : 'NEUTRAL',
            setupSectorAlignment,
            detectionResult: detection,
            historicalEvidence: historical,
            robustness,
            execution,
            liquidityClassification: snapshot.stockState.liquidity.classification,
            classification,
            compositeOpportunityScore: 50,
            rank: 1,
            rankingExplanation,
            clusterGroup: setupDef.clusterGroup,
            isClusterLeader: true,
            auditSnapshotHash
          });
        }
      } catch (err) {
        console.error(`Error scanning symbol ${symbol}:`, err);
      }
    }

    // 3. Multidimensional Ranking (Section 20)
    const ranked = SetupRankingService.rankOpportunities(rawOpportunities);

    // 4. Apply in-flight UI filters if specified
    let filtered = ranked;
    if (filterParams?.setupCategory && filterParams.setupCategory !== 'ALL') {
      filtered = filtered.filter(o => o.setup.category === filterParams.setupCategory);
    }
    if (filterParams?.setupStage && filterParams.setupStage !== 'ALL') {
      filtered = filtered.filter(o => o.stage === filterParams.setupStage);
    }
    if (filterParams?.minimumEvidenceGrade && filterParams.minimumEvidenceGrade !== 'ALL') {
      const grades = ['A', 'B', 'C', 'D', 'F'];
      const maxIndex = grades.indexOf(filterParams.minimumEvidenceGrade);
      filtered = filtered.filter(o => {
        const itemIndex = grades.indexOf(o.robustness.researchGrade);
        return itemIndex <= maxIndex;
      });
    }
    if (filterParams?.liquidityFilter === 'PASS_ONLY') {
      filtered = filtered.filter(o => o.detectionResult.dataQuality === 'PASS');
    }
    if (filterParams?.minRiskReward && filterParams.minRiskReward > 0) {
      filtered = filtered.filter(o => o.detectionResult.riskRewardRatio >= filterParams.minRiskReward!);
    }
    if (filterParams?.classification && filterParams.classification !== 'ALL') {
      filtered = filtered.filter(o => o.classification === filterParams.classification);
    }
    if (filterParams?.searchQuery) {
      const q = filterParams.searchQuery.toLowerCase();
      filtered = filtered.filter(o =>
        o.symbol.toLowerCase().includes(q) ||
        o.companyName.toLowerCase().includes(q) ||
        o.setup.name.toLowerCase().includes(q)
      );
    }

    return filtered;
  }

  /**
   * Computes Market Breadth of Setups & Crowding (Section 33 & 35)
   */
  public static getBreadthStats(
    opportunities: ScannedOpportunity[],
    asOfDate: string = '2026-08-30'
  ): OpportunityBreadthStats {
    const totalSecuritiesScanned = normalizedCompanies.length;
    const uniqueSymbolsWithSetups = new Set(opportunities.map(o => o.symbol)).size;

    let confirmedSetupsCount = 0;
    let formingSetupsCount = 0;
    let triggeredSetupsCount = 0;
    let invalidatedSetupsCount = 0;
    let blockedSetupsCount = 0;

    const categoryCounts: Record<SetupCategory, number> = {
      BREAKOUT: 0,
      PULLBACK: 0,
      TREND_CONTINUATION: 0,
      MOMENTUM: 0,
      MEAN_REVERSION: 0,
      REVERSAL: 0,
      SQUEEZE: 0,
      RANGE_BREAK: 0,
      RELATIVE_STRENGTH: 0,
      VOLUME_EXPANSION: 0
    };

    for (const opp of opportunities) {
      if (opp.stage === 'CONFIRMED') confirmedSetupsCount++;
      else if (opp.stage === 'FORMING') formingSetupsCount++;
      else if (opp.stage === 'TRIGGERED') triggeredSetupsCount++;
      else if (opp.stage === 'INVALIDATED') invalidatedSetupsCount++;

      if (opp.classification === 'BLOCKED') blockedSetupsCount++;

      if (categoryCounts[opp.setup.category] !== undefined) {
        categoryCounts[opp.setup.category]++;
      }
    }

    // Crowding detection (Section 35): Flag if > 25% of scanned securities display identical setup
    let isCrowded = false;
    let crowdedCategory: SetupCategory | undefined;
    let maxCategoryShare = 0;

    for (const [cat, count] of Object.entries(categoryCounts)) {
      const share = uniqueSymbolsWithSetups > 0 ? count / uniqueSymbolsWithSetups : 0;
      if (share > 0.35 && count >= 3) {
        isCrowded = true;
        crowdedCategory = cat as SetupCategory;
        maxCategoryShare = Math.round(share * 100);
        break;
      }
    }

    const advisoryMessage = isCrowded
      ? `High setup crowding detected in ${crowdedCategory} setups (${maxCategoryShare}% concentration). Beware of correlated exit cascades and false breakouts.`
      : 'Healthy setup distribution across market sectors without pathological setup crowding.';

    return {
      asOfDate,
      totalSecuritiesScanned,
      securitiesWithSetups: uniqueSymbolsWithSetups,
      confirmedSetupsCount,
      formingSetupsCount,
      triggeredSetupsCount,
      invalidatedSetupsCount,
      blockedSetupsCount,
      categoryCounts,
      crowdingState: {
        isCrowded,
        crowdedCategory,
        percentageOfUniverse: maxCategoryShare,
        advisoryMessage
      }
    };
  }

  /**
   * Sets user research watchlist tag
   */
  public static setUserStatus(
    symbol: string,
    setupId: string,
    status: ResearchUserStatus
  ): void {
    this.userStatuses.set(`${symbol}_${setupId}`, status);
  }

  /**
   * Generates cryptographic audit record for opportunity
   */
  public static getOpportunityAuditRecord(
    opp: ScannedOpportunity
  ): OpportunityAuditRecord {
    return {
      symbol: opp.symbol,
      asOfDate: opp.asOfDate,
      setupId: opp.setup.id,
      setupVersion: opp.setup.version,
      dataSource: opp.dataSource,
      engineVersion: this.SCANNER_VERSION,
      detectedConditions: opp.detectionResult.triggerConditions,
      missingConditions: opp.detectionResult.missingConditions,
      invalidationConditions: opp.detectionResult.invalidationConditions,
      historicalEvidenceSummary: {
        observations: opp.historicalEvidence.observations,
        winRate5D: opp.historicalEvidence.pPositive5D,
        expectancy5D: opp.historicalEvidence.expectancy5D,
        evidenceGrade: opp.historicalEvidence.evidenceGrade
      },
      probabilitySnapshot: {
        p5D: opp.historicalEvidence.pPositive5D,
        wilson5D: opp.historicalEvidence.wilsonInterval5D,
        p20D: opp.historicalEvidence.pPositive20D
      },
      robustnessSnapshot: {
        grade: opp.robustness.researchGrade,
        walkForward: opp.robustness.walkForwardResult
      },
      riskSnapshot: {
        entry: opp.detectionResult.currentPrice,
        stop: opp.detectionResult.suggestedStopLoss,
        target1: opp.detectionResult.target1,
        rrRatio: opp.detectionResult.riskRewardRatio
      },
      eligibility: {
        status: opp.classification,
        blockersCount: opp.detectionResult.dataQuality === 'BLOCKED' ? 1 : 0
      },
      finalClassification: opp.classification,
      compositeScore: opp.compositeOpportunityScore,
      explanation: opp.detectionResult.explanation,
      timestamp: new Date().toISOString(),
      snapshotHash: opp.auditSnapshotHash
    };
  }

  private static simpleHash(input: string): string {
    let hash = 0;
    for (let i = 0; i < input.length; i++) {
      const char = input.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0;
    }
    const hex = Math.abs(hash).toString(16).padStart(8, '0');
    return `sha256_${hex}fe9a8b1c`;
  }
}
