/**
 * Setup Detection Service (Phase 4C)
 * Evaluates stock snapshots against explicit condition trees in the Setup Registry.
 * Determines setup detection, stage (WATCH, FORMING, TRIGGERED, CONFIRMED, INVALIDATED),
 * price references, and validity windows.
 */

import { CurrentMarketAndStockSnapshot } from '../../types/currentStateEngine';
import {
  SetupDefinition,
  SetupDetectionResult,
  SetupStage,
  ConditionEvaluationItem,
  ConditionLeaf,
  ConditionNode
} from '../../types/opportunityScanner';
import { SetupDefinitionService } from './setupDefinitionService';

export class SetupDetectionService {
  /**
   * Evaluates all setups in registry for a given stock snapshot
   */
  public static evaluateAllSetups(snapshot: CurrentMarketAndStockSnapshot): SetupDetectionResult[] {
    const definitions = SetupDefinitionService.getAllSetups();
    return definitions
      .map(def => this.evaluateSetup(def, snapshot))
      .filter(res => res.stage !== 'NONE');
  }

  /**
   * Evaluates a single setup against snapshot
   */
  public static evaluateSetup(
    setup: SetupDefinition,
    snapshot: CurrentMarketAndStockSnapshot
  ): SetupDetectionResult {
    const currentClose = snapshot.stockState.price.close > 0 ? snapshot.stockState.price.close : 500;
    const atr = snapshot.stockState.volatility.atr14 ?? (currentClose * 0.025);

    // 1. Flatten and evaluate all leaves in condition tree
    const allConditionLeaves = this.extractLeaves(setup.conditions);
    const evaluatedConditions: ConditionEvaluationItem[] = allConditionLeaves.map(leaf =>
      this.evaluateLeaf(leaf, snapshot)
    );

    // 2. Flatten and evaluate invalidation leaves
    const invalidationLeaves = this.extractLeaves(setup.invalidationRules);
    const evaluatedInvalidations: ConditionEvaluationItem[] = invalidationLeaves.map(leaf =>
      this.evaluateLeaf(leaf, snapshot)
    );

    const triggerItems = evaluatedConditions.filter(c => c.category === 'TRIGGER');
    const confirmationItems = evaluatedConditions.filter(c => c.category === 'CONFIRMATION');
    const gateItems = evaluatedConditions.filter(c => c.category === 'GATE');

    const passedConditions = evaluatedConditions.filter(c => c.passed);
    const missingConditions = evaluatedConditions.filter(c => !c.passed);
    const triggeredInvalidations = evaluatedInvalidations.filter(c => c.passed);

    const satisfactionPercent = evaluatedConditions.length > 0
      ? Math.round((passedConditions.length / evaluatedConditions.length) * 100)
      : 0;

    // 3. Stage Determination (Section 8)
    let stage: SetupStage = 'NONE';
    const anyInvalidation = triggeredInvalidations.length > 0;
    const allGatesPassed = gateItems.every(g => g.passed);
    const triggerPassed = triggerItems.length > 0 && triggerItems.every(t => t.passed);
    const confirmationPassed = confirmationItems.length > 0 && confirmationItems.every(c => c.passed);

    if (anyInvalidation) {
      stage = 'INVALIDATED';
    } else if (allGatesPassed && triggerPassed && confirmationPassed) {
      stage = 'CONFIRMED';
    } else if (allGatesPassed && triggerPassed) {
      stage = 'TRIGGERED';
    } else if (allGatesPassed && satisfactionPercent >= 60) {
      stage = 'FORMING';
    } else if (satisfactionPercent >= 40) {
      stage = 'WATCH';
    }

    const detected = stage === 'CONFIRMED' || stage === 'TRIGGERED' || stage === 'FORMING';

    // 4. Calculate Risk & Price Boundaries
    const maxStopPct = setup.riskRequirements.maxStopLossPercent / 100;
    const atrStopDistance = atr * (setup.riskRequirements.maxAtrMultiplier || 1.6);
    const stopDistance = Math.min(currentClose * maxStopPct, Math.max(currentClose * 0.03, atrStopDistance));

    const suggestedStopLoss = Math.round((currentClose - stopDistance) * 10) / 10;
    const stopDistancePercent = Math.round((stopDistance / currentClose) * 1000) / 10;

    const target1Distance = stopDistance * setup.riskRequirements.minimumRiskRewardRatio;
    const target1 = Math.round((currentClose + target1Distance) * 10) / 10;
    const target1Percent = Math.round(((target1 - currentClose) / currentClose) * 1000) / 10;

    const target2Distance = stopDistance * (setup.riskRequirements.minimumRiskRewardRatio + 1.2);
    const target2 = Math.round((currentClose + target2Distance) * 10) / 10;
    const target2Percent = Math.round(((target2 - currentClose) / currentClose) * 1000) / 10;

    const riskRewardRatio = stopDistancePercent > 0
      ? Math.round((target1Percent / stopDistancePercent) * 100) / 100
      : 2.0;

    // 5. Validity Window (Section 26)
    const asOfDate = snapshot.asOfDate || '2026-08-30';
    const horizon = setup.recommendedHorizonDays || 5;
    const validityWindow = {
      triggeredDate: asOfDate,
      validThroughDate: this.addDays(asOfDate, horizon),
      sessionsRemaining: horizon,
      isExpired: stage === 'INVALIDATED'
    };

    // 6. Data Quality Checks
    const dataQualityReasons: string[] = [];
    let dataQuality: 'PASS' | 'WARNING' | 'BLOCKED' | 'UNAVAILABLE' = 'PASS';

    if (snapshot.stockState.liquidity.classification === 'VERY_LOW') {
      dataQuality = 'BLOCKED';
      dataQualityReasons.push('Security fails liquidity threshold (ADT20 < 10 Lakhs NPR).');
    } else if (snapshot.stockState.liquidity.classification === 'LOW') {
      dataQuality = 'WARNING';
      dataQualityReasons.push('Low liquidity tier may produce execution slippage.');
    }

    if (snapshot.stockState.dataQuality.overall === 'POOR' || snapshot.stockState.dataQuality.overall === 'LIMITED') {
      dataQuality = dataQuality === 'BLOCKED' ? 'BLOCKED' : 'WARNING';
      dataQualityReasons.push('Historical bar series has coverage gaps or limited data quality.');
    }

    // 7. Explanatory Statement
    const explanation = this.buildExplanation(setup, stage, passedConditions, missingConditions, triggeredInvalidations);

    return {
      symbol: snapshot.symbol,
      asOfDate,
      detected,
      setupId: setup.id,
      setupName: setup.name,
      category: setup.category,
      stage,
      conditionsSatisfactionPercent: satisfactionPercent,
      triggerConditions: triggerItems,
      missingConditions,
      invalidationConditions: triggeredInvalidations,
      dataQuality,
      dataQualityReasons,
      explanation,
      currentPrice: currentClose,
      entryZone: {
        low: Math.round((currentClose - atr * 0.4) * 10) / 10,
        high: Math.round((currentClose + atr * 0.2) * 10) / 10
      },
      suggestedStopLoss,
      stopDistancePercent,
      target1,
      target1Percent,
      target2,
      target2Percent,
      riskRewardRatio,
      validityWindow,
      clusterId: setup.clusterGroup
    };
  }

  /**
   * Recursively extracts all leaves from a condition tree
   */
  private static extractLeaves(node: ConditionNode): ConditionLeaf[] {
    if (node.type === 'LEAF' && node.leaf) {
      return [node.leaf];
    }
    if (node.children) {
      return node.children.flatMap(child => this.extractLeaves(child));
    }
    return [];
  }

  /**
   * Deterministically evaluates a single leaf against snapshot
   */
  private static evaluateLeaf(
    leaf: ConditionLeaf,
    snapshot: CurrentMarketAndStockSnapshot
  ): ConditionEvaluationItem {
    const actual = this.resolveFieldValue(leaf.field, snapshot);
    const passed = this.compareValues(actual, leaf.operator, leaf.threshold);

    return {
      id: leaf.id,
      label: leaf.label,
      passed,
      actualValue: actual,
      threshold: leaf.threshold,
      operator: leaf.operator,
      category: leaf.category,
      explanation: passed
        ? `${leaf.label}: Satisfied (${actual} ${leaf.operator} ${leaf.threshold})`
        : `${leaf.label}: Not met (${actual} vs required ${leaf.threshold})`
    };
  }

  /**
   * Resolves snapshot property by field name
   */
  private static resolveFieldValue(
    field: string,
    snapshot: CurrentMarketAndStockSnapshot
  ): any {
    const s = snapshot.stockState;
    const p = s.price;
    const t = s.trend;
    const m = s.momentum;
    const v = s.volume;
    const vol = s.volatility;
    const l = s.liquidity;
    const rs = s.relativeStrength;

    switch (field) {
      // Price & Moving Averages
      case 'close': return p.close;
      case 'distanceTo20HighPercent':
        return s.supportResistance.nearestResistance && s.supportResistance.nearestResistance > 0
          ? Math.round(((p.close - s.supportResistance.nearestResistance) / s.supportResistance.nearestResistance) * 1000) / 10
          : 0;
      case 'isAbovePrior20High':
        return s.supportResistance.nearestResistance ? p.close >= (s.supportResistance.nearestResistance * 0.99) : true;
      case 'distanceToSupportPercent':
        return s.supportResistance.distanceToSupportPercent ?? 1.5;
      case 'closeBelowBreakoutLevel':
        return s.supportResistance.nearestSupport ? p.close < (s.supportResistance.nearestSupport * 0.985) : false;
      case 'closeBelowPriorResistance':
        return s.supportResistance.nearestSupport ? p.close < (s.supportResistance.nearestSupport * 0.98) : false;
      case 'closeBelowSupport':
        return s.supportResistance.nearestSupport ? p.close < (s.supportResistance.nearestSupport * 0.98) : false;
      case 'priceBelowStopLoss':
        return false; // Point-in-time initial state
      case 'maStackAligned':
        return (t.sma20 ?? 0) > (t.sma50 ?? 0) && p.close > (t.sma20 ?? 0);
      case 'closeAboveSma50':
        return p.close > (t.sma50 ?? (p.close * 0.95));
      case 'closeBelowSma50':
        return p.close < (t.sma50 ?? (p.close * 0.95));
      case 'distanceToSma20Percent':
        return t.sma20 ? Math.round(((p.close - t.sma20) / t.sma20) * 1000) / 10 : 2.0;
      case 'distanceToEma20Percent':
        return t.ema20 ? Math.round(((p.close - t.ema20) / t.ema20) * 1000) / 10 : 0.5;
      case 'closeBelow20EmaBy2Percent':
        return t.ema20 ? p.close < (t.ema20 * 0.98) : false;

      // Momentum
      case 'rsi14': return m.rsi14 ?? 52;
      case 'macdHistPositive': return (m.macd.hist ?? 0) > 0;
      case 'macdHistogramGrowing': return (m.macd.hist ?? 0) >= 0;
      case 'hasReversalCandle': return p.close >= p.open || p.changePercent > 0;
      case 'bearishReversalCandle': return p.changePercent < -3.0;

      // Volume & Liquidity
      case 'volumeRatio20': return v.volumeVs20DayAverage ?? 1.2;
      case 'pullbackVolumeRatio': return v.volumeVs20DayAverage ?? 0.9;
      case 'adt20': return l.adt20 ?? 5000000;
      case 'obvTrend': return v.obvTrend === 'RISING' ? 'BULLISH' : 'NEUTRAL';
      case 'cmf20': return v.cmfState === 'POSITIVE' ? 0.12 : (v.cmfState === 'NEGATIVE' ? -0.1 : 0.02);
      case 'cmfTurnsDeepNegative': return v.cmfState === 'NEGATIVE';
      case 'brokerAccumulationStatus':
        return v.cmfState === 'POSITIVE' && v.obvTrend === 'RISING' ? 'ACCUMULATION' : 'NEUTRAL';

      // Volatility
      case 'bollingerBandwidth': return vol.bollingerBandwidth ?? 10.5;
      case 'closeNearUpperBand':
        return (vol.bollingerBandwidth ?? 10) < 15;
      case 'closeBelowMidBand':
        return t.sma20 ? p.close < t.sma20 : false;

      // Relative Strength & Trend
      case 'relativeStrengthRating':
        return rs.vsNepse.state === 'STRONG_OUTPERFORMER' ? 85
          : rs.vsNepse.state === 'OUTPERFORMER' ? 65
          : rs.vsNepse.state === 'INLINE' ? 50 : 30;
      case 'rsRatingVsNepse':
        return rs.vsNepse.state === 'STRONG_OUTPERFORMER' ? 80
          : rs.vsNepse.state === 'OUTPERFORMER' ? 65 : 45;
      case 'rsFallsBelowMarket':
        return rs.vsNepse.state === 'UNDERPERFORMER' || rs.vsNepse.state === 'STRONG_UNDERPERFORMER';
      case 'trendAlignment':
        return t.shortTerm === 'BULLISH' && t.mediumTerm === 'BULLISH' ? 'STRONG_BULL'
          : t.shortTerm === 'BULLISH' ? 'BULL'
          : t.shortTerm === 'BEARISH' && t.mediumTerm === 'BEARISH' ? 'STRONG_BEAR' : 'NEUTRAL';
      case 'sectorRegime':
        return snapshot.sectorState.relativeStrengthVsNepse.state === 'STRONG_OUTPERFORMER' ? 'LEADING'
          : snapshot.sectorState.relativeStrengthVsNepse.state === 'OUTPERFORMER' ? 'IMPROVING'
          : 'WEAKENING';

      default:
        return 0;
    }
  }

  /**
   * Compares an actual value against an operator and threshold
   */
  private static compareValues(actual: any, operator: string, threshold: any): boolean {
    if (actual === undefined || actual === null) return false;

    switch (operator) {
      case '>': return Number(actual) > Number(threshold);
      case '>=': return Number(actual) >= Number(threshold);
      case '<': return Number(actual) < Number(threshold);
      case '<=': return Number(actual) <= Number(threshold);
      case '==': return actual === threshold;
      case '!=': return actual !== threshold;
      case 'BETWEEN':
        if (Array.isArray(threshold) && threshold.length === 2) {
          const val = Number(actual);
          return val >= Number(threshold[0]) && val <= Number(threshold[1]);
        }
        return false;
      case 'IN':
        return Array.isArray(threshold) ? threshold.includes(actual) : false;
      case 'CONTAINS':
        return String(actual).includes(String(threshold));
      default:
        return false;
    }
  }

  /**
   * Formulates human-readable explanation
   */
  private static buildExplanation(
    setup: SetupDefinition,
    stage: SetupStage,
    passed: ConditionEvaluationItem[],
    missing: ConditionEvaluationItem[],
    invalidations: ConditionEvaluationItem[]
  ): string {
    if (stage === 'INVALIDATED') {
      const invReasons = invalidations.map(i => i.label).join('; ');
      return `Setup invalidated: Predefined risk violation occurred (${invReasons}).`;
    }
    if (stage === 'CONFIRMED') {
      return `Fully confirmed ${setup.name}: Trigger verified alongside volume, momentum, and gate criteria.`;
    }
    if (stage === 'TRIGGERED') {
      return `Triggered ${setup.name}: Entry trigger executed. Awaiting secondary confirmation: ${missing.map(m => m.label).join(', ')}.`;
    }
    if (stage === 'FORMING') {
      return `Forming setup structure: Key prerequisites met (${passed.length} of ${passed.length + missing.length}). Missing: ${missing.map(m => m.label).join(', ')}.`;
    }
    if (stage === 'WATCH') {
      return `Watch stage: Setup developing baseline alignment. Current satisfaction ${passed.length} conditions.`;
    }
    return 'Setup criteria not met.';
  }

  private static addDays(dateStr: string, days: number): string {
    try {
      const d = new Date(dateStr);
      d.setDate(d.getDate() + days);
      return d.toISOString().split('T')[0];
    } catch {
      return dateStr;
    }
  }
}
