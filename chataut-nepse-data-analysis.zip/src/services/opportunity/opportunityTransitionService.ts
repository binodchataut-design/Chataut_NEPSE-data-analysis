/**
 * Opportunity Transition Service (Phase 4C)
 * Tracks setup lifecycle stage transitions, records stage change events,
 * and classifies opportunities into NEW, ONGOING, STRENGTHENING, WEAKENING, etc.
 * Conforms to Section 27 & 28 of the Phase 4C specifications.
 */

import {
  OpportunityStageTransition,
  OpportunityLifecycleStatus,
  SetupStage
} from '../../types/opportunityScanner';

export class OpportunityTransitionService {
  // In-memory persistent transition history log
  private static transitionHistory: OpportunityStageTransition[] = [
    {
      id: 'trans-1',
      symbol: 'CHCL',
      setupId: 'SETUP_BREAKOUT',
      asOfDate: '2026-08-30',
      fromStage: 'FORMING',
      toStage: 'CONFIRMED',
      reason: 'Turnover surged to 2.1x 20MA alongside candle close above 550 NPR resistance.',
      timestamp: '2026-08-30T15:00:00Z'
    },
    {
      id: 'trans-2',
      symbol: 'SHIVM',
      setupId: 'SETUP_PULLBACK_EMA',
      asOfDate: '2026-08-30',
      fromStage: 'WATCH',
      toStage: 'TRIGGERED',
      reason: 'Price reached 20 EMA zone with shallow volume pullback.',
      timestamp: '2026-08-30T15:00:00Z'
    },
    {
      id: 'trans-3',
      symbol: 'NABIL',
      setupId: 'SETUP_TREND_CONTINUATION',
      asOfDate: '2026-08-28',
      fromStage: 'FORMING',
      toStage: 'CONFIRMED',
      reason: 'MA stack alignment confirmed with MACD positive crossover.',
      timestamp: '2026-08-28T15:00:00Z'
    }
  ];

  /**
   * Records a transition event
   */
  public static recordTransition(
    symbol: string,
    setupId: string,
    asOfDate: string,
    fromStage: SetupStage,
    toStage: SetupStage,
    reason: string
  ): OpportunityStageTransition {
    const transition: OpportunityStageTransition = {
      id: `trans_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      symbol,
      setupId,
      asOfDate,
      fromStage,
      toStage,
      reason,
      timestamp: new Date().toISOString()
    };
    this.transitionHistory.push(transition);
    return transition;
  }

  /**
   * Retrieves transition history for a specific symbol or setup
   */
  public static getTransitionsForSymbol(symbol: string): OpportunityStageTransition[] {
    return this.transitionHistory.filter(t => t.symbol === symbol);
  }

  /**
   * Returns all logged transitions
   */
  public static getAllTransitions(): OpportunityStageTransition[] {
    return [...this.transitionHistory];
  }

  /**
   * Evaluates opportunity lifecycle status based on recent transitions
   */
  public static evaluateLifecycleStatus(
    symbol: string,
    setupId: string,
    currentStage: SetupStage
  ): OpportunityLifecycleStatus {
    if (currentStage === 'INVALIDATED') return 'INVALIDATED';

    const recent = this.transitionHistory
      .filter(t => t.symbol === symbol && t.setupId === setupId)
      .slice(-1)[0];

    if (!recent) return 'NEW';

    if (recent.toStage === currentStage && recent.fromStage === 'WATCH' && currentStage === 'FORMING') {
      return 'NEW';
    }
    if ((recent.fromStage === 'FORMING' && currentStage === 'TRIGGERED') ||
        (recent.fromStage === 'TRIGGERED' && currentStage === 'CONFIRMED')) {
      return 'STRENGTHENING';
    }
    if (recent.fromStage === 'CONFIRMED' && (currentStage === 'FORMING' || currentStage === 'WATCH')) {
      return 'WEAKENING';
    }
    if (recent.fromStage === 'INVALIDATED') {
      return 'REACTIVATED';
    }

    return 'ONGOING';
  }
}
