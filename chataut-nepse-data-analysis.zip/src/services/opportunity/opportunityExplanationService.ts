/**
 * Opportunity Explanation Service (Phase 4C)
 * Generates transparent, deterministic natural-language rationales for scanned opportunities.
 * Outlines reasons why an opportunity is ranked highly and factors preventing higher rank.
 * Conforms to Section 21 of the Phase 4C specifications.
 */

import {
  SetupDefinition,
  SetupDetectionResult,
  SetupHistoricalEvidence,
  SetupRobustnessResult,
  SetupExecutionReality,
  OpportunityClassification,
  SetupCompatibility
} from '../../types/opportunityScanner';
import { CurrentMarketAndStockSnapshot } from '../../types/currentStateEngine';

export class OpportunityExplanationService {
  /**
   * Generates ranking explanation items
   */
  public static generateRankingExplanation(
    setup: SetupDefinition,
    detection: SetupDetectionResult,
    historical: SetupHistoricalEvidence,
    robustness: SetupRobustnessResult,
    execution: SetupExecutionReality,
    snapshot: CurrentMarketAndStockSnapshot,
    compatibility: SetupCompatibility
  ): { whyRankedHighly: string[]; reasonsPreventingHigherRank: string[] } {
    const whyRankedHighly: string[] = [];
    const reasonsPreventingHigherRank: string[] = [];

    // 1. Setup Stage & Trigger
    if (detection.stage === 'CONFIRMED') {
      whyRankedHighly.push(`Full setup confirmation: Trigger condition met with ${detection.conditionsSatisfactionPercent}% criteria satisfied.`);
    } else if (detection.stage === 'TRIGGERED') {
      whyRankedHighly.push(`Active entry trigger: Primary trigger condition printed with ${detection.riskRewardRatio}:1 risk-reward profile.`);
    } else if (detection.stage === 'FORMING') {
      reasonsPreventingHigherRank.push(`Setup is still forming (${detection.conditionsSatisfactionPercent}% satisfied); confirmation candle has not yet printed.`);
    } else if (detection.stage === 'INVALIDATED') {
      reasonsPreventingHigherRank.push('Setup was invalidated by predefined structural risk exit.');
    }

    // 2. Historical Edge
    if (historical.wilsonInterval5D.lower >= 50) {
      whyRankedHighly.push(`Statistically significant historical edge: 5D positive rate of ${historical.pPositive5D}% (Wilson 95% CI: ${historical.wilsonInterval5D.lower}% - ${historical.wilsonInterval5D.upper}%, N=${historical.observations}).`);
    } else if (historical.pPositive5D >= 55) {
      whyRankedHighly.push(`Positive historical baseline: ${historical.pPositive5D}% 5-day success rate across ${historical.observations} comparable occurrences.`);
    } else {
      reasonsPreventingHigherRank.push(`Moderate historical win rate (${historical.pPositive5D}%), dampening statistical conviction.`);
    }

    if (historical.sampleTier === 'LOW' || historical.sampleTier === 'VERY_LOW') {
      reasonsPreventingHigherRank.push(`Limited sample size (tier: ${historical.sampleTier}, N=${historical.observations}), increasing estimator variance.`);
    }

    // 3. Market Regime Compatibility
    if (compatibility === 'FAVORABLE') {
      whyRankedHighly.push(`Strong macro alignment: Current ${snapshot.marketState.regime} regime historically favors ${setup.category} setups.`);
    } else if (compatibility === 'UNFAVORABLE') {
      reasonsPreventingHigherRank.push(`Hostile macro backdrop: ${snapshot.marketState.regime} regime creates cross-current drag for ${setup.name}.`);
    }

    // 4. Sector Leadership
    const sectorRs = snapshot.sectorState.relativeStrengthVsNepse.state;
    if (sectorRs === 'STRONG_OUTPERFORMER' || sectorRs === 'OUTPERFORMER') {
      whyRankedHighly.push(`Sector tailwind: ${snapshot.sectorState.sectorName} is outperforming NEPSE, supporting institutional follow-through.`);
    } else if (sectorRs === 'UNDERPERFORMER') {
      reasonsPreventingHigherRank.push(`Sector headwind: ${snapshot.sectorState.sectorName} is currently lagging the broader index.`);
    }

    // 5. Robustness & Execution
    if (robustness.walkForwardResult === 'PASS' && robustness.researchGrade === 'A') {
      whyRankedHighly.push('Grade A statistical robustness: Passed full walk-forward out-of-sample and parameter stability testing.');
    } else if (robustness.researchGrade === 'C' || robustness.researchGrade === 'D') {
      reasonsPreventingHigherRank.push(`Lower research robustness grade (${robustness.researchGrade}) under walk-forward evaluation.`);
    }

    if (execution.liquidityImpactScore > 50) {
      reasonsPreventingHigherRank.push(`Elevated execution friction (estimated round-trip cost + slippage ${execution.totalRoundTripFrictionPercent}%).`);
    }

    if (execution.circuitConstraintWarning) {
      reasonsPreventingHigherRank.push('Price trading near 10% daily circuit limit, posing potential order execution queuing constraints.');
    }

    // Ensure at least 1 reason in each array for complete explainability
    if (whyRankedHighly.length === 0) {
      whyRankedHighly.push(`Active setup structure detected with ${detection.conditionsSatisfactionPercent}% rule compliance.`);
    }
    if (reasonsPreventingHigherRank.length === 0) {
      reasonsPreventingHigherRank.push('Top-tier setup; maintain standard execution discipline and stop loss adherence.');
    }

    return { whyRankedHighly, reasonsPreventingHigherRank };
  }

  /**
   * Classifies opportunity into multi-dimensional category (Section 19)
   */
  public static determineClassification(
    detection: SetupDetectionResult,
    historical: SetupHistoricalEvidence,
    robustness: SetupRobustnessResult,
    compatibility: SetupCompatibility
  ): OpportunityClassification {
    if (detection.dataQuality === 'BLOCKED') {
      return 'BLOCKED';
    }
    if (historical.sampleTier === 'VERY_LOW' && historical.observations < 10) {
      return 'INSUFFICIENT_DATA';
    }
    if (detection.stage === 'CONFIRMED' && historical.wilsonInterval5D.lower >= 48 && compatibility !== 'UNFAVORABLE') {
      return 'HIGH_CONVICTION_RESEARCH';
    }
    if (detection.stage === 'CONFIRMED' || detection.stage === 'TRIGGERED') {
      return 'VALID_OPPORTUNITY';
    }
    if (detection.stage === 'FORMING') {
      return 'EARLY_FORMING';
    }
    if (detection.stage === 'WATCH') {
      return 'WATCH';
    }
    if (historical.wilsonInterval5D.lower < 40 || robustness.robustnessRating === 'WEAK') {
      return 'WEAK_EVIDENCE';
    }
    return 'VALID_OPPORTUNITY';
  }
}
