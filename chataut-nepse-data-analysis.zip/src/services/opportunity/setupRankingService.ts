/**
 * Setup Ranking Service (Phase 4C)
 * Multidimensional ranking of scanned opportunities without collinear double-counting.
 * Computes non-magical composite score and handles duplicate setup clustering.
 * Conforms to Section 20 & 36 of the Phase 4C specifications.
 */

import { ScannedOpportunity } from '../../types/opportunityScanner';

export class SetupRankingService {
  /**
   * Ranks an array of scanned opportunities and assigns deterministic ranks
   */
  public static rankOpportunities(opportunities: ScannedOpportunity[]): ScannedOpportunity[] {
    // 1. Compute composite score for each
    const scored = opportunities.map(opp => {
      const compositeScore = this.calculateCompositeScore(opp);
      return {
        ...opp,
        compositeOpportunityScore: compositeScore
      };
    });

    // 2. Sort descending by composite score, then by 5D win rate, then by risk-reward
    scored.sort((a, b) => {
      // High conviction first
      if (b.compositeOpportunityScore !== a.compositeOpportunityScore) {
        return b.compositeOpportunityScore - a.compositeOpportunityScore;
      }
      if (b.historicalEvidence.pPositive5D !== a.historicalEvidence.pPositive5D) {
        return b.historicalEvidence.pPositive5D - a.historicalEvidence.pPositive5D;
      }
      return b.detectionResult.riskRewardRatio - a.detectionResult.riskRewardRatio;
    });

    // 3. Cluster duplicate setups (Section 36) and elect cluster leaders
    const seenClusters = new Set<string>();
    const rankedWithClusterLeaders = scored.map((opp, index) => {
      const clusterKey = `${opp.symbol}_${opp.setup.clusterGroup || opp.setup.category}`;
      let isClusterLeader = false;
      if (!seenClusters.has(clusterKey)) {
        seenClusters.add(clusterKey);
        isClusterLeader = true;
      }

      return {
        ...opp,
        rank: index + 1,
        isClusterLeader
      };
    });

    return rankedWithClusterLeaders;
  }

  /**
   * Transparent, non-magical composite scoring (0-100)
   * Weight breakdown:
   * - Setup stage & condition compliance: 30%
   * - Historical statistical edge (Wilson lower bound & win rate): 25%
   * - Market & Sector macro alignment: 20%
   * - Robustness & walk-forward grade: 15%
   * - Risk-reward & execution efficiency: 10%
   */
  public static calculateCompositeScore(opp: ScannedOpportunity): number {
    if (opp.detectionResult.stage === 'INVALIDATED' || opp.classification === 'BLOCKED') {
      return 10;
    }

    // A. Setup Stage (0 - 30 pts)
    let stagePoints = 0;
    if (opp.stage === 'CONFIRMED') stagePoints = 30;
    else if (opp.stage === 'TRIGGERED') stagePoints = 25;
    else if (opp.stage === 'FORMING') stagePoints = 16;
    else if (opp.stage === 'WATCH') stagePoints = 10;

    // B. Historical Statistical Edge (0 - 25 pts)
    // Scale Wilson 95% lower bound (40% -> 0 pts, 60% -> 25 pts)
    const wilsonLower = opp.historicalEvidence.wilsonInterval5D.lower;
    const histPoints = Math.max(0, Math.min(25, (wilsonLower - 38) * 1.25));

    // C. Market & Sector Alignment (0 - 20 pts)
    let macroPoints = 10;
    if (opp.marketCompatibility === 'FAVORABLE') macroPoints += 5;
    else if (opp.marketCompatibility === 'UNFAVORABLE') macroPoints -= 5;

    if (opp.setupSectorAlignment === 'HIGH') macroPoints += 5;
    else if (opp.setupSectorAlignment === 'LOW') macroPoints -= 3;

    // D. Robustness Grade (0 - 15 pts)
    let robustnessPoints = 8;
    if (opp.robustness.researchGrade === 'A') robustnessPoints = 15;
    else if (opp.robustness.researchGrade === 'B') robustnessPoints = 12;
    else if (opp.robustness.researchGrade === 'C') robustnessPoints = 7;
    else robustnessPoints = 3;

    // E. Risk/Reward & Execution Friction (0 - 10 pts)
    const rr = opp.detectionResult.riskRewardRatio;
    const rrPoints = Math.min(6, Math.max(1, (rr - 1.5) * 3));
    const frictionPenalty = opp.execution.totalRoundTripFrictionPercent > 1.2 ? -2 : 0;
    const riskPoints = Math.max(0, Math.min(10, rrPoints + 4 + frictionPenalty));

    const total = Math.round(stagePoints + histPoints + macroPoints + robustnessPoints + riskPoints);
    return Math.max(0, Math.min(100, total));
  }
}
