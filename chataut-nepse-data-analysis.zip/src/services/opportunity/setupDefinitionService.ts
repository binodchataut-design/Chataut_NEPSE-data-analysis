/**
 * Setup Definition Service (Phase 4C)
 * Single source of truth for setup definitions, transparent condition trees,
 * invalidation rules, risk requirements, and historical validity benchmarks.
 * Conforms to Section 4 & 5 of the Phase 4C specifications.
 */

import { SetupDefinition, SetupCategory, ConditionTree } from '../../types/opportunityScanner';

export class SetupDefinitionService {
  public static readonly REGISTRY_VERSION = '4C_REGISTRY_v1';

  private static setups: SetupDefinition[] = [
    // ----------------------------------------------------
    // A. BREAKOUT (Section 5.A)
    // ----------------------------------------------------
    {
      id: 'SETUP_BREAKOUT',
      name: 'Validated Resistance Breakout',
      category: 'BREAKOUT',
      description: 'Daily close breaking above validated horizontal resistance with expanding turnover and relative strength confirmation.',
      version: '1.0',
      clusterGroup: 'BREAKOUT_CLUSTER',
      recommendedHorizonDays: 5,
      preferredMarketRegimes: ['BULL', 'SIDEWAYS'],
      preferredSectorTrends: ['BULLISH'],
      riskRequirements: {
        maxStopLossPercent: 7.0,
        minimumRiskRewardRatio: 2.0,
        maxAtrMultiplier: 1.8,
        allowWithoutVolumeConfirmation: false,
        requiresStrictSupportProximity: false
      },
      minimumHistoricalEvidence: {
        minimumObservations: 40,
        minimumWinRate5D: 55.0,
        minimumEvidenceGrade: 'C',
        minimumWilsonLowerBound: 45.0
      },
      conditions: {
        type: 'AND',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'c_breakout_price',
              field: 'distanceTo20HighPercent',
              label: 'Price Testing / Exceeding Resistance',
              operator: '>=',
              threshold: -0.5,
              category: 'TRIGGER',
              weight: 0.35,
              description: 'Current closing price is at or above 20-day resistance high.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_breakout_volume',
              field: 'volumeRatio20',
              label: 'Turnover & Volume Confirmation',
              operator: '>=',
              threshold: 1.25,
              category: 'CONFIRMATION',
              weight: 0.25,
              description: 'Turnover expanding to >= 1.25x 20-day moving average volume.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_breakout_rs',
              field: 'relativeStrengthRating',
              label: 'Supportive Relative Strength vs NEPSE',
              operator: '>=',
              threshold: 45,
              category: 'CONFIRMATION',
              weight: 0.20,
              description: 'Stock relative strength rating not lagging market index.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_breakout_trend',
              field: 'trendAlignment',
              label: 'Underlying Trend Not Hostile',
              operator: '!=',
              threshold: 'STRONG_BEAR',
              category: 'GATE',
              weight: 0.10,
              description: 'Primary trend must not be in an extreme collapse/strong bear regime.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_breakout_liquidity',
              field: 'adt20',
              label: 'Liquidity Absorption Gate',
              operator: '>=',
              threshold: 3000000,
              category: 'GATE',
              weight: 0.10,
              description: 'Average Daily Turnover (ADT20) >= 30 Lakhs NPR.'
            }
          }
        ]
      },
      invalidationRules: {
        type: 'OR',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'inv_breakout_fail',
              field: 'priceBelowBreakoutLevel',
              label: 'Daily Close Below Breakout Level',
              operator: '==',
              threshold: true,
              category: 'INVALIDATION',
              description: 'Price fails back inside the consolidation range by closing below broken resistance.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'inv_stop_loss',
              field: 'priceBelowStopLoss',
              label: 'Close Below Stop Loss',
              operator: '==',
              threshold: true,
              category: 'INVALIDATION',
              description: 'Price drops below predefined stop loss level (1.5x ATR below entry).'
            }
          }
        ]
      }
    },

    // ----------------------------------------------------
    // B. RANGE_BREAK / BREAKOUT RETEST (Section 5.B)
    // ----------------------------------------------------
    {
      id: 'SETUP_BREAKOUT_RETEST',
      name: 'Breakout Retest & Level Stabilization',
      category: 'RANGE_BREAK',
      description: 'Prior resistance level broken, price retests breakout zone from above on decreasing volume, confirming support.',
      version: '1.0',
      clusterGroup: 'BREAKOUT_CLUSTER',
      recommendedHorizonDays: 10,
      preferredMarketRegimes: ['BULL', 'SIDEWAYS'],
      preferredSectorTrends: ['BULLISH', 'NEUTRAL'],
      riskRequirements: {
        maxStopLossPercent: 6.0,
        minimumRiskRewardRatio: 2.2,
        maxAtrMultiplier: 1.6,
        allowWithoutVolumeConfirmation: false,
        requiresStrictSupportProximity: true
      },
      minimumHistoricalEvidence: {
        minimumObservations: 35,
        minimumWinRate5D: 57.0,
        minimumEvidenceGrade: 'B',
        minimumWilsonLowerBound: 46.0
      },
      conditions: {
        type: 'AND',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'c_retest_prior_break',
              field: 'isAbovePrior20High',
              label: 'Recent Prior Resistance Break',
              operator: '==',
              threshold: true,
              category: 'GATE',
              weight: 0.30,
              description: 'Stock traded above prior 20-day high within the last 5 sessions.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_retest_zone_hold',
              field: 'distanceToSupportPercent',
              label: 'Retest Zone Proximity & Holding',
              operator: '<=',
              threshold: 2.5,
              category: 'TRIGGER',
              weight: 0.35,
              description: 'Price pulled back to within 2.5% of breakout support and holds.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_retest_drying_vol',
              field: 'pullbackVolumeRatio',
              label: 'Drying Selling Pressure on Dip',
              operator: '<=',
              threshold: 1.1,
              category: 'CONFIRMATION',
              weight: 0.25,
              description: 'Pullback volume remains calm, preventing institutional distribution.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_retest_liquidity',
              field: 'adt20',
              label: 'Minimum Liquidity Gate',
              operator: '>=',
              threshold: 2500000,
              category: 'GATE',
              weight: 0.10,
              description: 'ADT20 >= 25 Lakhs NPR.'
            }
          }
        ]
      },
      invalidationRules: {
        type: 'OR',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'inv_retest_breakdown',
              field: 'closeBelowPriorResistance',
              label: 'Breakdown Below Retested Support',
              operator: '==',
              threshold: true,
              category: 'INVALIDATION',
              description: 'Retest fails by closing more than 1.5% below the retested support.'
            }
          }
        ]
      }
    },

    // ----------------------------------------------------
    // C. TREND_CONTINUATION (Section 5.C)
    // ----------------------------------------------------
    {
      id: 'SETUP_TREND_CONTINUATION',
      name: 'Moving Average Trend Continuation',
      category: 'TREND_CONTINUATION',
      description: 'Primary and intermediate moving averages aligned bullishly (SMA20 > SMA50 > SMA200) with controlled consolidation.',
      version: '1.0',
      clusterGroup: 'TREND_CLUSTER',
      recommendedHorizonDays: 10,
      preferredMarketRegimes: ['BULL'],
      preferredSectorTrends: ['BULLISH'],
      riskRequirements: {
        maxStopLossPercent: 7.5,
        minimumRiskRewardRatio: 2.0,
        maxAtrMultiplier: 2.0,
        allowWithoutVolumeConfirmation: true,
        requiresStrictSupportProximity: false
      },
      minimumHistoricalEvidence: {
        minimumObservations: 50,
        minimumWinRate5D: 56.0,
        minimumEvidenceGrade: 'B',
        minimumWilsonLowerBound: 48.0
      },
      conditions: {
        type: 'AND',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'c_tc_ma_stack',
              field: 'maStackAligned',
              label: 'Bullish Moving Average Stack',
              operator: '==',
              threshold: true,
              category: 'GATE',
              weight: 0.35,
              description: 'Close > SMA20 and SMA20 > SMA50.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_tc_rsi_range',
              field: 'rsi14',
              label: 'Momentum In Healthy Bullish Range',
              operator: 'BETWEEN',
              threshold: [48, 72],
              category: 'CONFIRMATION',
              weight: 0.25,
              description: 'RSI(14) maintaining support above 48 without severe overextension (>72).'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_tc_macd_pos',
              field: 'macdHistPositive',
              label: 'Positive MACD Momentum',
              operator: '==',
              threshold: true,
              category: 'TRIGGER',
              weight: 0.25,
              description: 'MACD histogram printing positive expansion.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_tc_extension_cap',
              field: 'distanceToSma20Percent',
              label: 'Not Severely Overextended',
              operator: '<=',
              threshold: 8.0,
              category: 'GATE',
              weight: 0.15,
              description: 'Price not more than 8% above 20 SMA.'
            }
          }
        ]
      },
      invalidationRules: {
        type: 'OR',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'inv_tc_ma_loss',
              field: 'closeBelowSma50',
              label: 'Close Below SMA50',
              operator: '==',
              threshold: true,
              category: 'INVALIDATION',
              description: 'Intermediate trend collapses with close below 50-day SMA.'
            }
          }
        ]
      }
    },

    // ----------------------------------------------------
    // D. PULLBACK (Section 5.D)
    // ----------------------------------------------------
    {
      id: 'SETUP_PULLBACK_EMA',
      name: 'Pullback to 20 EMA in Established Trend',
      category: 'PULLBACK',
      description: 'Healthy 2-5% controlled counter-trend dip towards rising 20 EMA with momentum reset and stabilization candle.',
      version: '1.0',
      clusterGroup: 'TREND_CLUSTER',
      recommendedHorizonDays: 5,
      preferredMarketRegimes: ['BULL', 'SIDEWAYS'],
      preferredSectorTrends: ['BULLISH'],
      riskRequirements: {
        maxStopLossPercent: 5.5,
        minimumRiskRewardRatio: 2.2,
        maxAtrMultiplier: 1.5,
        allowWithoutVolumeConfirmation: false,
        requiresStrictSupportProximity: true
      },
      minimumHistoricalEvidence: {
        minimumObservations: 45,
        minimumWinRate5D: 59.0,
        minimumEvidenceGrade: 'B',
        minimumWilsonLowerBound: 49.0
      },
      conditions: {
        type: 'AND',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'c_pb_primary_trend',
              field: 'closeAboveSma50',
              label: 'Primary Trend Bullish (Above SMA50)',
              operator: '==',
              threshold: true,
              category: 'GATE',
              weight: 0.30,
              description: 'Stock maintains primary structural support above 50 SMA.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_pb_ema_proximity',
              field: 'distanceToEma20Percent',
              label: 'Price Approaching 20 EMA Zone',
              operator: 'BETWEEN',
              threshold: [-1.5, 2.0],
              category: 'TRIGGER',
              weight: 0.35,
              description: 'Price within -1.5% to +2.0% of rising 20-day exponential moving average.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_pb_rsi_cooling',
              field: 'rsi14',
              label: 'RSI Cooled Off To Support (40 - 58)',
              operator: 'BETWEEN',
              threshold: [40, 58],
              category: 'CONFIRMATION',
              weight: 0.20,
              description: 'Momentum reset without bearish momentum breakdown.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_pb_volume_calm',
              field: 'volumeRatio20',
              label: 'Selling Volume Lower on Pullback',
              operator: '<=',
              threshold: 1.2,
              category: 'CONFIRMATION',
              weight: 0.15,
              description: 'Volume subdued during retracement.'
            }
          }
        ]
      },
      invalidationRules: {
        type: 'OR',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'inv_pb_ema_failure',
              field: 'closeBelow20EmaBy2Percent',
              label: 'Breakdown Below 20 EMA (>2%)',
              operator: '==',
              threshold: true,
              category: 'INVALIDATION',
              description: 'Pullback turns into structural breakdown below 20 EMA.'
            }
          }
        ]
      }
    },

    // ----------------------------------------------------
    // E. MOMENTUM (Section 5.E)
    // ----------------------------------------------------
    {
      id: 'SETUP_MOMENTUM_EXPANSION',
      name: 'Momentum Acceleration & Expansion',
      category: 'MOMENTUM',
      description: 'Rapid acceleration in MACD histogram, RSI push > 60 with above-average volume and relative strength surge.',
      version: '1.0',
      clusterGroup: 'MOMENTUM_CLUSTER',
      recommendedHorizonDays: 5,
      preferredMarketRegimes: ['BULL'],
      preferredSectorTrends: ['BULLISH'],
      riskRequirements: {
        maxStopLossPercent: 7.0,
        minimumRiskRewardRatio: 2.0,
        maxAtrMultiplier: 1.8,
        allowWithoutVolumeConfirmation: false,
        requiresStrictSupportProximity: false
      },
      minimumHistoricalEvidence: {
        minimumObservations: 40,
        minimumWinRate5D: 57.0,
        minimumEvidenceGrade: 'B',
        minimumWilsonLowerBound: 47.0
      },
      conditions: {
        type: 'AND',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'c_mom_rsi',
              field: 'rsi14',
              label: 'RSI Momentum Acceleration (> 58)',
              operator: '>=',
              threshold: 58,
              category: 'TRIGGER',
              weight: 0.35,
              description: 'RSI(14) advancing decisively into strong bullish territory.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_mom_macd_expansion',
              field: 'macdHistogramGrowing',
              label: 'MACD Histogram Expanding',
              operator: '==',
              threshold: true,
              category: 'CONFIRMATION',
              weight: 0.30,
              description: 'MACD histogram higher than previous session.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_mom_vol',
              field: 'volumeRatio20',
              label: 'Volume Expansion (>= 1.3x)',
              operator: '>=',
              threshold: 1.3,
              category: 'CONFIRMATION',
              weight: 0.25,
              description: 'Volume expands with price surge.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_mom_liquidity',
              field: 'adt20',
              label: 'Liquidity Gate (>= 40 Lakhs)',
              operator: '>=',
              threshold: 4000000,
              category: 'GATE',
              weight: 0.10,
              description: 'Requires high liquidity for momentum execution.'
            }
          }
        ]
      },
      invalidationRules: {
        type: 'OR',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'inv_mom_divergence',
              field: 'bearishReversalCandle',
              label: 'Climactic Exhaustion Reversal',
              operator: '==',
              threshold: true,
              category: 'INVALIDATION',
              description: 'Shooting star or bearish engulfing print invalidates momentum thrust.'
            }
          }
        ]
      }
    },

    // ----------------------------------------------------
    // F. SQUEEZE (Section 5.F)
    // ----------------------------------------------------
    {
      id: 'SETUP_VOLATILITY_SQUEEZE',
      name: 'Volatility Squeeze & Band Expansion',
      category: 'SQUEEZE',
      description: 'Historical volatility compression (tight Bollinger Bands) resolving into directional breakout.',
      version: '1.0',
      clusterGroup: 'BREAKOUT_CLUSTER',
      recommendedHorizonDays: 10,
      preferredMarketRegimes: ['BULL', 'SIDEWAYS'],
      preferredSectorTrends: ['BULLISH', 'NEUTRAL'],
      riskRequirements: {
        maxStopLossPercent: 6.0,
        minimumRiskRewardRatio: 2.2,
        maxAtrMultiplier: 1.5,
        allowWithoutVolumeConfirmation: false,
        requiresStrictSupportProximity: false
      },
      minimumHistoricalEvidence: {
        minimumObservations: 35,
        minimumWinRate5D: 58.0,
        minimumEvidenceGrade: 'B',
        minimumWilsonLowerBound: 46.0
      },
      conditions: {
        type: 'AND',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'c_sq_bandwidth',
              field: 'bollingerBandwidth',
              label: 'Tight Bollinger Bandwidth (<= 12%)',
              operator: '<=',
              threshold: 12.0,
              category: 'GATE',
              weight: 0.35,
              description: 'Volatility contraction indicated by narrow bandwidth.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_sq_breakout',
              field: 'closeNearUpperBand',
              label: 'Expansion Toward Upper Band',
              operator: '==',
              threshold: true,
              category: 'TRIGGER',
              weight: 0.35,
              description: 'Closing price testing or piercing upper Bollinger band.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_sq_volume_spike',
              field: 'volumeRatio20',
              label: 'Volume Expansion Trigger',
              operator: '>=',
              threshold: 1.25,
              category: 'CONFIRMATION',
              weight: 0.30,
              description: 'Volume expands out of low-volatility slumber.'
            }
          }
        ]
      },
      invalidationRules: {
        type: 'OR',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'inv_sq_midband_loss',
              field: 'closeBelowMidBand',
              label: 'Close Below 20 SMA (Mid-Band)',
              operator: '==',
              threshold: true,
              category: 'INVALIDATION',
              description: 'False breakout turns back below middle Bollinger band.'
            }
          }
        ]
      }
    },

    // ----------------------------------------------------
    // G. MEAN_REVERSION (Section 5.G)
    // ----------------------------------------------------
    {
      id: 'SETUP_MEAN_REVERSION',
      name: 'Oversold Support Mean Reversion',
      category: 'MEAN_REVERSION',
      description: 'Statistically extreme oversold dislocation near major structural support with bullish reversal print.',
      version: '1.0',
      clusterGroup: 'REVERSAL_CLUSTER',
      recommendedHorizonDays: 5,
      preferredMarketRegimes: ['BULL', 'SIDEWAYS'],
      riskRequirements: {
        maxStopLossPercent: 4.5, // Strict risk constraint per Section 5.G
        minimumRiskRewardRatio: 2.5,
        maxAtrMultiplier: 1.3,
        allowWithoutVolumeConfirmation: true,
        requiresStrictSupportProximity: true
      },
      minimumHistoricalEvidence: {
        minimumObservations: 35,
        minimumWinRate5D: 53.0,
        minimumEvidenceGrade: 'C',
        minimumWilsonLowerBound: 42.0
      },
      conditions: {
        type: 'AND',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'c_mr_oversold',
              field: 'rsi14',
              label: 'Oversold Dislocation (RSI <= 34)',
              operator: '<=',
              threshold: 34,
              category: 'GATE',
              weight: 0.35,
              description: 'Extreme short-term selling exhaustion.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_mr_support_proximity',
              field: 'distanceToSupportPercent',
              label: 'Proximity to Validated Support (<= 3%)',
              operator: '<=',
              threshold: 3.0,
              category: 'GATE',
              weight: 0.30,
              description: 'Must be within 3% of validated multi-month support level.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_mr_stabilization',
              field: 'hasReversalCandle',
              label: 'Stabilization Reversal Print',
              operator: '==',
              threshold: true,
              category: 'TRIGGER',
              weight: 0.35,
              description: 'Rejection wick or green stabilization candle printing.'
            }
          }
        ]
      },
      invalidationRules: {
        type: 'OR',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'inv_mr_support_loss',
              field: 'closeBelowSupport',
              label: 'Close Below Validated Support',
              operator: '==',
              threshold: true,
              category: 'INVALIDATION',
              description: 'Price penetrates support by > 1.5% without bouncing.'
            }
          }
        ]
      }
    },

    // ----------------------------------------------------
    // H. RELATIVE_STRENGTH (Section 5.H)
    // ----------------------------------------------------
    {
      id: 'SETUP_RELATIVE_STRENGTH',
      name: 'Relative Strength Sector Leadership',
      category: 'RELATIVE_STRENGTH',
      description: 'Stock and sector simultaneously outperforming NEPSE with positive RS momentum and intact price structure.',
      version: '1.0',
      clusterGroup: 'MOMENTUM_CLUSTER',
      recommendedHorizonDays: 10,
      preferredMarketRegimes: ['BULL', 'SIDEWAYS'],
      preferredSectorTrends: ['BULLISH'],
      riskRequirements: {
        maxStopLossPercent: 6.5,
        minimumRiskRewardRatio: 2.0,
        maxAtrMultiplier: 1.7,
        allowWithoutVolumeConfirmation: true,
        requiresStrictSupportProximity: false
      },
      minimumHistoricalEvidence: {
        minimumObservations: 45,
        minimumWinRate5D: 60.0,
        minimumEvidenceGrade: 'A',
        minimumWilsonLowerBound: 50.0
      },
      conditions: {
        type: 'AND',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'c_rs_stock_outperf',
              field: 'rsRatingVsNepse',
              label: 'Stock Outperforming NEPSE (>= 60)',
              operator: '>=',
              threshold: 60,
              category: 'TRIGGER',
              weight: 0.35,
              description: 'Stock 1-month alpha vs NEPSE index positive and accelerating.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_rs_sector_leading',
              field: 'sectorRegime',
              label: 'Sector in Leading / Improving Regime',
              operator: 'IN',
              threshold: ['LEADING', 'IMPROVING'],
              category: 'CONFIRMATION',
              weight: 0.35,
              description: 'Belongs to top-performing sector quartile.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_rs_trend_intact',
              field: 'trendAlignment',
              label: 'Price Structure Intact (Above SMA50)',
              operator: '!=',
              threshold: 'STRONG_BEAR',
              category: 'GATE',
              weight: 0.30,
              description: 'Stock price structure not in a long-term downtrend.'
            }
          }
        ]
      },
      invalidationRules: {
        type: 'OR',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'inv_rs_divergence',
              field: 'rsFallsBelowMarket',
              label: 'RS Drops Below Benchmark (Lagging)',
              operator: '==',
              threshold: true,
              category: 'INVALIDATION',
              description: 'Relative strength breaks down below median benchmark.'
            }
          }
        ]
      }
    },

    // ----------------------------------------------------
    // I. VOLUME_EXPANSION (Section 5.I)
    // ----------------------------------------------------
    {
      id: 'SETUP_VOLUME_ACCUMULATION',
      name: 'Institutional Volume Accumulation',
      category: 'VOLUME_EXPANSION',
      description: 'Persistent positive institutional volume/flow characteristics, rising OBV/CMF, and concentrated buyer floor activity.',
      version: '1.0',
      clusterGroup: 'ACCUMULATION_CLUSTER',
      recommendedHorizonDays: 10,
      preferredMarketRegimes: ['BULL', 'SIDEWAYS'],
      riskRequirements: {
        maxStopLossPercent: 6.0,
        minimumRiskRewardRatio: 2.0,
        maxAtrMultiplier: 1.6,
        allowWithoutVolumeConfirmation: false,
        requiresStrictSupportProximity: false
      },
      minimumHistoricalEvidence: {
        minimumObservations: 40,
        minimumWinRate5D: 58.0,
        minimumEvidenceGrade: 'B',
        minimumWilsonLowerBound: 48.0
      },
      conditions: {
        type: 'AND',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'c_vol_obv_slope',
              field: 'obvTrend',
              label: 'On-Balance Volume Rising / Accumulating',
              operator: '==',
              threshold: 'BULLISH',
              category: 'TRIGGER',
              weight: 0.35,
              description: 'OBV slope positive over 20-day window.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_vol_cmf_positive',
              field: 'cmf20',
              label: 'Chaikin Money Flow Positive (> 0.05)',
              operator: '>=',
              threshold: 0.05,
              category: 'CONFIRMATION',
              weight: 0.35,
              description: 'CMF indicates net positive buying pressure.'
            }
          },
          {
            type: 'LEAF',
            leaf: {
              id: 'c_vol_broker_acc',
              field: 'brokerAccumulationStatus',
              label: 'Top Broker Net Accumulation',
              operator: 'IN',
              threshold: ['ACCUMULATION', 'HEAVY_ACCUMULATION'],
              category: 'CONFIRMATION',
              weight: 0.30,
              description: 'Top floor brokers exhibiting net absorption.'
            }
          }
        ]
      },
      invalidationRules: {
        type: 'OR',
        children: [
          {
            type: 'LEAF',
            leaf: {
              id: 'inv_vol_distribution',
              field: 'cmfTurnsDeepNegative',
              label: 'Heavy Distribution Event (CMF < -0.15)',
              operator: '==',
              threshold: true,
              category: 'INVALIDATION',
              description: 'Sudden institutional distribution invalidates accumulation thesis.'
            }
          }
        ]
      }
    }
  ];

  /**
   * Returns all active setup definitions
   */
  public static getAllSetups(): SetupDefinition[] {
    return [...this.setups];
  }

  /**
   * Returns a setup definition by ID
   */
  public static getSetupById(id: string): SetupDefinition | undefined {
    return this.setups.find(s => s.id === id);
  }

  /**
   * Returns setup definitions by category
   */
  public static getSetupsByCategory(category: SetupCategory): SetupDefinition[] {
    return this.setups.filter(s => s.category === category);
  }

  /**
   * Returns clusters of related setups (Section 36)
   */
  public static getRelatedCluster(setupId: string): SetupDefinition[] {
    const setup = this.getSetupById(setupId);
    if (!setup || !setup.clusterGroup) return setup ? [setup] : [];
    return this.setups.filter(s => s.clusterGroup === setup.clusterGroup);
  }
}
