/**
 * Phase 4C — NEPSE Opportunity Discovery & Setup Scanner Types
 * Standardized contracts for setup definitions, condition trees, detection results,
 * stage lifecycles, historical evidence, quality classification, and universe ranking.
 */

import { MarketRegimeType, SampleSizeTier } from './historicalResearch';
import { EvidenceGrade, LiquidityClassification } from './researchValidation';
import { TrendState, MomentumState, RelativeStrengthState } from './currentStateEngine';
import { EvidenceItem } from './decisionIntelligence';

// ==========================================
// 1. Setup Categories & Stages
// ==========================================

export type SetupCategory =
  | 'BREAKOUT'
  | 'PULLBACK'
  | 'TREND_CONTINUATION'
  | 'MOMENTUM'
  | 'MEAN_REVERSION'
  | 'REVERSAL'
  | 'SQUEEZE'
  | 'RANGE_BREAK'
  | 'RELATIVE_STRENGTH'
  | 'VOLUME_EXPANSION';

export type SetupStage =
  | 'NONE'
  | 'WATCH'
  | 'FORMING'
  | 'TRIGGERED'
  | 'CONFIRMED'
  | 'INVALIDATED';

export type OpportunityLifecycleStatus =
  | 'NEW'
  | 'ONGOING'
  | 'STRENGTHENING'
  | 'WEAKENING'
  | 'INVALIDATED'
  | 'REACTIVATED';

export type OpportunityClassification =
  | 'HIGH_CONVICTION_RESEARCH'
  | 'VALID_OPPORTUNITY'
  | 'WATCH'
  | 'EARLY_FORMING'
  | 'WEAK_EVIDENCE'
  | 'BLOCKED'
  | 'INSUFFICIENT_DATA';

export type SetupCompatibility =
  | 'FAVORABLE'
  | 'NEUTRAL'
  | 'UNFAVORABLE';

export type ResearchUserStatus =
  | 'RESEARCH'
  | 'HIGH_PRIORITY'
  | 'IGNORE';

// ==========================================
// 2. Condition Trees (Section 4 & 6)
// ==========================================

export type ConditionOperator =
  | '>'
  | '>='
  | '<'
  | '<='
  | '=='
  | '!='
  | 'BETWEEN'
  | 'IN'
  | 'CONTAINS';

export type ConditionNodeType = 'AND' | 'OR' | 'NOT' | 'LEAF';

export interface ConditionLeaf {
  id: string;
  field: string;
  label: string;
  operator: ConditionOperator;
  threshold: number | string | boolean | (number | string)[];
  category: 'TRIGGER' | 'CONFIRMATION' | 'GATE' | 'INVALIDATION';
  weight?: number;
  description: string;
}

export interface ConditionNode {
  type: ConditionNodeType;
  children?: ConditionNode[];
  leaf?: ConditionLeaf;
}

export type ConditionTree = ConditionNode;

// ==========================================
// 3. Risk & Historical Requirements
// ==========================================

export interface RiskRequirements {
  maxStopLossPercent: number;
  minimumRiskRewardRatio: number;
  maxAtrMultiplier: number;
  allowWithoutVolumeConfirmation: boolean;
  requiresStrictSupportProximity: boolean;
}

export interface HistoricalEvidenceRequirement {
  minimumObservations: number;
  minimumWinRate5D: number;
  minimumEvidenceGrade: EvidenceGrade;
  minimumWilsonLowerBound?: number;
}

// ==========================================
// 4. Standardized Setup Definition Contract (Section 4)
// ==========================================

export interface SetupDefinition {
  id: string;
  name: string;
  category: SetupCategory;
  description: string;
  version: string;

  // Explicit condition trees
  conditions: ConditionTree;
  invalidationRules: ConditionTree;

  // Regime compatibility
  preferredMarketRegimes?: MarketRegimeType[];
  preferredSectorTrends?: TrendState[];

  // Risk & historical validation criteria
  riskRequirements: RiskRequirements;
  minimumHistoricalEvidence?: HistoricalEvidenceRequirement;

  // Typical holding period & characteristics
  recommendedHorizonDays: number;
  clusterGroup?: string;
}

// ==========================================
// 5. Setup Detection Result (Section 7)
// ==========================================

export interface ConditionEvaluationItem {
  id: string;
  label: string;
  passed: boolean;
  actualValue: number | string | boolean;
  threshold: number | string | boolean | (number | string)[];
  operator: ConditionOperator;
  category: 'TRIGGER' | 'CONFIRMATION' | 'GATE' | 'INVALIDATION';
  explanation: string;
}

export interface SetupDetectionResult {
  symbol: string;
  asOfDate: string;
  detected: boolean;

  setupId: string;
  setupName: string;
  category: SetupCategory;
  stage: SetupStage;

  conditionsSatisfactionPercent: number; // 0 - 100%
  triggerConditions: ConditionEvaluationItem[];
  missingConditions: ConditionEvaluationItem[];
  invalidationConditions: ConditionEvaluationItem[];

  dataQuality: 'PASS' | 'WARNING' | 'BLOCKED' | 'UNAVAILABLE';
  dataQualityReasons: string[];

  explanation: string;

  // Price references for setup
  currentPrice: number;
  entryZone: { low: number; high: number };
  suggestedStopLoss: number;
  stopDistancePercent: number;
  target1: number;
  target1Percent: number;
  target2: number;
  target2Percent: number;
  riskRewardRatio: number;

  // Validity window (Section 26)
  validityWindow: {
    triggeredDate: string;
    validThroughDate: string;
    sessionsRemaining: number;
    isExpired: boolean;
  };

  clusterId?: string;
}

// ==========================================
// 6. Setup-Specific Historical Evidence (Section 11 & 12)
// ==========================================

export interface SetupHistoricalEvidence {
  setupId: string;
  observations: number;
  sampleTier: SampleSizeTier;
  conditionSimilarityScore: number; // 0 - 100% (feature match)
  evidenceGrade: EvidenceGrade;

  // Positive outcome rates across holding horizons
  pPositive1D: number;
  pPositive5D: number;
  pPositive10D: number;
  pPositive20D: number;

  // 5D detailed statistics
  wilsonInterval5D: { lower: number; upper: number };
  meanReturn5D: number;
  medianReturn5D: number;
  expectancy5D: number;
  profitFactor5D: number;
  mfe5D: number;
  mae5D: number;

  // 20D statistics
  wilsonInterval20D: { lower: number; upper: number };
  meanReturn20D: number;

  // Regime breakdown (Section 34)
  regimePerformance: {
    bull: { observations: number; winRate: number; meanReturn: number };
    sideways: { observations: number; winRate: number; meanReturn: number };
    bear: { observations: number; winRate: number; meanReturn: number };
  };
}

// ==========================================
// 7. Setup Robustness & Execution Reality (Section 15 & 17)
// ==========================================

export interface SetupRobustnessResult {
  researchGrade: EvidenceGrade;
  robustnessRating: 'STRONG' | 'MODERATE' | 'WEAK';
  walkForwardResult: 'PASS' | 'FAIL';
  parameterStability: 'PASS' | 'WARNING' | 'FAIL';
  regimeStability: 'PASS' | 'WARNING' | 'FAIL';
  summary: string;
}

export interface SetupExecutionReality {
  estimatedEntry: number;
  stopReference: number;
  target1Reference: number;
  target2Reference: number;
  riskReward: number;
  estimatedBrokeragePercent: number;
  estimatedSebonFeePercent: number;
  estimatedDpFeeNpr: number;
  cgtAssumptionPercent: number;
  estimatedSlippagePercent: number;
  totalRoundTripFrictionPercent: number;
  liquidityImpactScore: number; // 0 - 100
  circuitConstraintWarning: boolean;
}

// ==========================================
// 8. Opportunity Transition & History (Section 27 & 28)
// ==========================================

export interface OpportunityStageTransition {
  id: string;
  symbol: string;
  setupId: string;
  asOfDate: string;
  fromStage: SetupStage;
  toStage: SetupStage;
  reason: string;
  timestamp: string;
}

// ==========================================
// 9. Complete Scanned Opportunity Item (Section 23 & 31)
// ==========================================

export interface ScannedOpportunity {
  id: string;
  symbol: string;
  companyName: string;
  sectorName: string;
  asOfDate: string;
  dataSource: string;

  // Setup Detection
  setup: SetupDefinition;
  stage: SetupStage;
  lifecycleStatus: OpportunityLifecycleStatus;
  userStatus: ResearchUserStatus;

  // Market & Sector Alignment (Section 9 & 10)
  marketRegime: MarketRegimeType;
  marketCompatibility: SetupCompatibility;
  sectorRegime: 'LEADING' | 'IMPROVING' | 'WEAKENING' | 'LAGGING';
  sectorRelativeStrength: 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE';
  setupSectorAlignment: 'HIGH' | 'MODERATE' | 'LOW';

  // Multi-dimensional Evidence
  detectionResult: SetupDetectionResult;
  historicalEvidence: SetupHistoricalEvidence;
  robustness: SetupRobustnessResult;
  execution: SetupExecutionReality;
  liquidityClassification: LiquidityClassification;

  // Multi-dimensional Opportunity Classification (Section 18 & 19)
  classification: OpportunityClassification;
  compositeOpportunityScore: number; // 0 - 100 (non-magical multi-factor rank)
  rank: number;

  // Explainability (Section 21)
  rankingExplanation: {
    whyRankedHighly: string[];
    reasonsPreventingHigherRank: string[];
  };

  // Duplicate / cluster relation (Section 36)
  clusterGroup?: string;
  isClusterLeader: boolean;

  // Audit
  auditSnapshotHash: string;
}

// ==========================================
// 10. Scanner Breadth & Crowding (Section 33 & 35)
// ==========================================

export interface OpportunityBreadthStats {
  asOfDate: string;
  totalSecuritiesScanned: number;
  securitiesWithSetups: number;
  confirmedSetupsCount: number;
  formingSetupsCount: number;
  triggeredSetupsCount: number;
  invalidatedSetupsCount: number;
  blockedSetupsCount: number;

  // Breakdown by setup category
  categoryCounts: Record<SetupCategory, number>;

  // Crowding detection (Section 35)
  crowdingState: {
    isCrowded: boolean;
    crowdedCategory?: SetupCategory;
    percentageOfUniverse: number;
    advisoryMessage: string;
  };
}

// ==========================================
// 11. Scanner Filter Parameters (Section 22)
// ==========================================

export interface OpportunityScannerFilterParams {
  asOfDate: string;
  universe: 'ALL_NEPSE' | 'COMMERCIAL_BANKS' | 'HYDROPOWER' | 'INSURANCE' | 'MANUFACTURING' | 'FINANCE';
  selectedSector?: string;
  setupCategory?: SetupCategory | 'ALL';
  setupStage?: SetupStage | 'ALL';
  minimumEvidenceGrade?: EvidenceGrade | 'ALL';
  minimumSampleSize?: SampleSizeTier | 'ALL';
  liquidityFilter?: 'ALL' | 'PASS_ONLY';
  minRiskReward?: number;
  classification?: OpportunityClassification | 'ALL';
  searchQuery?: string;
}

// ==========================================
// 12. Opportunity Audit Record (Section 45)
// ==========================================

export interface OpportunityAuditRecord {
  symbol: string;
  asOfDate: string;
  setupId: string;
  setupVersion: string;
  dataSource: string;
  engineVersion: string;
  detectedConditions: ConditionEvaluationItem[];
  missingConditions: ConditionEvaluationItem[];
  invalidationConditions: ConditionEvaluationItem[];
  historicalEvidenceSummary: {
    observations: number;
    winRate5D: number;
    expectancy5D: number;
    evidenceGrade: EvidenceGrade;
  };
  probabilitySnapshot: {
    p5D: number;
    wilson5D: { lower: number; upper: number };
    p20D: number;
  };
  robustnessSnapshot: {
    grade: EvidenceGrade;
    walkForward: 'PASS' | 'FAIL';
  };
  riskSnapshot: {
    entry: number;
    stop: number;
    target1: number;
    rrRatio: number;
  };
  eligibility: {
    status: string;
    blockersCount: number;
  };
  finalClassification: OpportunityClassification;
  compositeScore: number;
  explanation: string;
  timestamp: string;
  snapshotHash: string;
}
