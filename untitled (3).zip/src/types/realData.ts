/**
 * Phase 4D — Real NEPSE Historical Data Integration & Active Universe Reconstruction Types
 * Contracts for:
 * 1. Data Provenance & Raw Traceability
 * 2. Security Classification & Active Universe Filtering
 * 3. Point-in-Time Universe Rules
 * 4. OHLC Integrity & Data Health Auditing
 * 5. Cross-Source Validation
 */

export type SecurityClassification =
  | 'ACTIVE_ORDINARY_EQUITY'
  | 'MERGED'
  | 'DELISTED'
  | 'SUSPENDED'
  | 'PROMOTER_SHARE'
  | 'PREFERENCE_SHARE'
  | 'DEBENTURE'
  | 'MUTUAL_FUND'
  | 'UNKNOWN';

export type InstrumentType =
  | 'ordinary'
  | 'debenture'
  | 'mutual_fund'
  | 'promoter_share'
  | 'preference'
  | 'government_bond'
  | 'unknown';

export interface DataProvenance {
  sourceType: string;
  repository: string;
  repositoryCommit?: string;
  sourceFile: string;
  importedAt: string;
  dateRange: {
    start: string;
    end: string;
  };
  symbol: string;
  transformationVersion: string;
}

export interface RawSourceDataRecord {
  published_date: string;
  open: number | string;
  high: number | string;
  low: number | string;
  close: number | string;
  per_change: number | string;
  traded_quantity: number | string;
  traded_amount: number | string;
  status: number | string;
}

export interface NormalizedHistoricalBar {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  turnover: number;
  percentageChange: number;
  rawStatus: string;
  isValidOHLC: boolean;
  discrepancies?: string[];
}

export interface SecurityReference {
  symbol: string;
  name: string;
  instrumentType: InstrumentType;
  sector: string;
  status: 'listed' | 'delisted' | 'merged' | 'suspended';
  classification: SecurityClassification;
  mergerTargetSymbol?: string;
  mergerEffectiveDate?: string;
  listingDate?: string;
  delistingDate?: string;
  isEligibleForCurrentActive: boolean;
  sharesansarId?: number;
}

export interface CrossSourceSessionComparison {
  date: string;
  primaryClose: number;
  secondaryClose: number;
  primaryVolume: number;
  secondaryVolume: number;
  closeDiffPercent: number;
  status: 'EXACT_MATCH' | 'ROUNDING_DIFF' | 'DISCREPANCY';
}

export interface CrossSourceValidationResult {
  symbol: string;
  primaryRepository: string;
  secondaryRepository: string;
  comparisonDate: string;
  sessionsCompared: number;
  exactMatches: number;
  minorDifferences: number;
  majorDifferences: number;
  sampleSessions: CrossSourceSessionComparison[];
}

export interface SymbolCoverageAudit {
  symbol: string;
  barCount: number;
  earliestDate: string;
  latestDate: string;
  zeroVolumeDays: number;
  largeMoveDays: number;
  invalidBarCount: number;
  notes: string;
}

export interface RealDataQualityReport {
  repository: string;
  secondaryRepository: string;
  commitHash: string;
  timestamp: string;
  totalDiscoveredFiles: number;
  totalSymbolsCataloged: number;
  importedSymbolsCount: number;
  totalRowsImported: number;
  earliestTradingDate: string;
  latestTradingDate: string;
  totalTradingSessions: number;
  validOHLCRowsCount: number;
  invalidOHLCRowsCount: number;
  duplicateRowsCount: number;
  missingCalendarDatesCount: number;
  activeOrdinaryEquityCount: number;
  mergedSecuritiesCount: number;
  delistedSecuritiesCount: number;
  debenturesCount: number;
  mutualFundsCount: number;
  promoterSharesCount: number;
  unknownClassificationCount: number;
  corporateActionCoverage: 'PARTIAL' | 'FULL' | 'NONE';
  corporateActionNotice: string;
  crossSourceAudit?: CrossSourceValidationResult;
  coverageBySymbol: SymbolCoverageAudit[];
}

export interface UniversePointInTimeQuery {
  asOfDate: string;
  allowNonOrdinary?: boolean;
  includeMergedPriorToDate?: boolean;
  includeDelistedPriorToDate?: boolean;
  includeSuspended?: boolean;
}
