/**
 * Active Universe & Security Classification Service (Phase 4D)
 * Manages NEPSE Security Master, Point-in-Time eligibility, and Universe Reconstruction.
 *
 * Core Mandates:
 * 1. Exclude MERGED, DELISTED, SUSPENDED, DEBENTURES, MUTUAL FUNDS, and PROMOTER SHARES
 *    from CURRENT ACTIVE UNIVERSE.
 * 2. Retain merged/delisted historical securities in HISTORICAL UNIVERSE for
 *    survivorship-bias-free backtesting up to their merger/delisting date.
 * 3. Point-in-Time Universe: Determine whether security was active and tradable on Date T.
 */

import {
  SecurityReference,
  SecurityClassification,
  InstrumentType,
  UniversePointInTimeQuery
} from '../types/realData';
import { NEPSE_SECURITY_UNIVERSE, NEPSE_CLOSED_DAYS } from '../data/nepseSecurityUniverse';
import { ListingLifecycleService } from './listingLifecycleService';

export class ActiveUniverseService {
  private static readonly universeMap: Map<string, SecurityReference> = new Map();
  private static readonly closedDaysSet: Set<string> = new Set(NEPSE_CLOSED_DAYS);

  static {
    for (const sec of NEPSE_SECURITY_UNIVERSE) {
      this.universeMap.set(sec.symbol.toUpperCase(), sec);
    }
  }

  /**
   * Canonical symbol normalization layer
   * Handles: whitespace, case-insensitivity, filename patterns (e.g., "nabil", "NABIL.csv", " NABIL ")
   */
  public static normalizeSymbol(rawInput: string): string {
    if (!rawInput) return '';
    let clean = rawInput.trim().toUpperCase();
    // Strip company id prefix if present (e.g. cmp-chcl)
    if (clean.startsWith('CMP-')) {
      clean = clean.slice(4);
    }
    // Strip trailing file extension if provided
    if (clean.endsWith('.CSV')) {
      clean = clean.slice(0, -4);
    }
    // Remove any non-alphanumeric trailing symbols
    clean = clean.replace(/[^A-Z0-9]/g, '');
    return clean;
  }

  /**
   * Retrieves security metadata record by canonical symbol
   */
  public static getSecurity(symbolOrInput: string): SecurityReference | null {
    const sym = this.normalizeSymbol(symbolOrInput);
    return this.universeMap.get(sym) || null;
  }

  /**
   * Classifies security into standard NEPSE classification buckets
   */
  public static classifySecurity(symbolOrInput: string): SecurityClassification {
    const sec = this.getSecurity(symbolOrInput);
    if (!sec) {
      // Fallback check in ListingLifecycleService
      const sym = this.normalizeSymbol(symbolOrInput);
      const lifecycle = ListingLifecycleService.getLifecycle(sym);
      if (lifecycle) {
        if (lifecycle.currentStatus === 'DELISTED') return 'DELISTED';
        if (lifecycle.currentStatus === 'SUSPENDED') return 'SUSPENDED';
        return 'ACTIVE_ORDINARY_EQUITY';
      }
      return 'UNKNOWN';
    }
    return sec.classification;
  }

  /**
   * Primary Active Universe Filter
   * Section 18: isEligibleForActiveUniverse(symbol, asOfDate)
   *
   * Evaluates:
   * 1. Instrument Type (ordinary equity vs debenture / mutual fund / promoter share)
   * 2. Listing status
   * 3. Merger status as of asOfDate
   * 4. Delisting status as of asOfDate
   * 5. Suspension status as of asOfDate
   */
  public static isEligibleForActiveUniverse(
    symbolOrInput: string,
    asOfDate?: string,
    allowNonOrdinary: boolean = false
  ): boolean {
    const sym = this.normalizeSymbol(symbolOrInput);
    const sec = this.getSecurity(sym);
    const targetDate = asOfDate || '2026-09-14';

    // Check lifecycle rules from ListingLifecycleService for deep suspension/delisting tracking
    const lifecycle = ListingLifecycleService.getLifecycle(sym);
    if (lifecycle) {
      // If target date is before listing date, not yet listed
      if (lifecycle.listingDate > targetDate) {
        return false;
      }
      // If delisted on or before target date, it is not eligible as of targetDate
      if (lifecycle.delistingDate && lifecycle.delistingDate <= targetDate) {
        return false;
      }
      // If suspended during targetDate
      for (const sp of lifecycle.suspensionPeriods) {
        if (targetDate >= sp.startDate && (!sp.endDate || targetDate <= sp.endDate)) {
          return false;
        }
      }
    }

    if (sec) {
      // Instrument type check: only ordinary equity by default
      if (!allowNonOrdinary && sec.instrumentType !== 'ordinary') {
        return false;
      }

      // If merged: was it merged on or before targetDate?
      if (sec.classification === 'MERGED' || sec.status === 'merged') {
        if (sec.mergerEffectiveDate && targetDate >= sec.mergerEffectiveDate) {
          return false;
        }
        // If no merger date is specified, treat it as merged today
        if (!sec.mergerEffectiveDate && targetDate >= '2023-01-01') {
          return false;
        }
      }

      // If delisted: was it delisted on or before targetDate?
      if (sec.classification === 'DELISTED' || sec.status === 'delisted') {
        if (sec.delistingDate && targetDate >= sec.delistingDate) {
          return false;
        }
      }

      return true;
    }

    // Fallback: if unknown security, do not include in active universe
    return false;
  }

  /**
   * Retrieves all securities eligible for the CURRENT ACTIVE UNIVERSE
   * Represents ACTIVE ORDINARY EQUITY only.
   */
  public static getCurrentActiveUniverse(asOfDate: string = '2026-09-14'): string[] {
    return NEPSE_SECURITY_UNIVERSE
      .filter(sec => this.isEligibleForActiveUniverse(sec.symbol, asOfDate, false))
      .map(sec => sec.symbol);
  }

  /**
   * Retrieves all securities eligible for HISTORICAL RESEARCH as of a given date.
   * Preserves merged/delisted securities (like NBB, BOKL) for point-in-time backtests
   * before their corporate end date.
   */
  public static getHistoricalUniverse(asOfDate: string = '2026-09-14'): string[] {
    return NEPSE_SECURITY_UNIVERSE
      .filter(sec => {
        // Exclude debentures and mutual funds unless ordinary equity
        if (sec.instrumentType !== 'ordinary') return false;

        // If listed after asOfDate, exclude
        if (sec.listingDate && sec.listingDate > asOfDate) return false;

        // If merged or delisted before asOfDate, it wasn't alive at asOfDate
        if (sec.mergerEffectiveDate && sec.mergerEffectiveDate < asOfDate) {
          // If query is strictly asOfDate, not alive. But for full historical span, keep it
          return true;
        }

        return true;
      })
      .map(sec => sec.symbol);
  }

  /**
   * Point-in-time universe query engine
   */
  public static queryUniverse(query: UniversePointInTimeQuery): string[] {
    const { asOfDate, allowNonOrdinary = false, includeMergedPriorToDate = false } = query;

    return NEPSE_SECURITY_UNIVERSE
      .filter(sec => {
        if (!allowNonOrdinary && sec.instrumentType !== 'ordinary') {
          return false;
        }

        if (includeMergedPriorToDate) {
          return true;
        }

        return this.isEligibleForActiveUniverse(sec.symbol, asOfDate, allowNonOrdinary);
      })
      .map(sec => sec.symbol);
  }

  /**
   * Validates whether a calendar date is an official NEPSE closed day
   * (Saturday, Friday half/holiday, public holidays)
   */
  public static isMarketClosedDay(dateStr: string): boolean {
    if (this.closedDaysSet.has(dateStr)) {
      return true;
    }

    // Check day of week (0 = Sunday, 5 = Friday, 6 = Saturday)
    // Note: In NEPSE, Friday and Saturday are weekend closed days
    const d = new Date(dateStr);
    const day = d.getUTCDay();
    if (day === 5 || day === 6) {
      return true;
    }

    return false;
  }

  /**
   * Returns all cataloged security references
   */
  public static getAllSecurities(): SecurityReference[] {
    return [...NEPSE_SECURITY_UNIVERSE];
  }

  /**
   * Returns count summary by classification
   */
  public static getClassificationCounts(): Record<SecurityClassification, number> {
    const counts: Record<SecurityClassification, number> = {
      ACTIVE_ORDINARY_EQUITY: 0,
      MERGED: 0,
      DELISTED: 0,
      SUSPENDED: 0,
      PROMOTER_SHARE: 0,
      PREFERENCE_SHARE: 0,
      DEBENTURE: 0,
      MUTUAL_FUND: 0,
      UNKNOWN: 0
    };

    for (const sec of NEPSE_SECURITY_UNIVERSE) {
      counts[sec.classification] = (counts[sec.classification] || 0) + 1;
    }

    return counts;
  }
}
