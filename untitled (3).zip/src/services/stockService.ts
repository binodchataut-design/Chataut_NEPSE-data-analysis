import { Company, CandleData } from '../types';
import { mockCompanies, mockCandlesCHCL } from '../data/mockData';
import { priceHistoryService } from './priceHistoryService';
import { companyRepository } from '../repositories/companyRepository';
import { providerRegistry } from '../providers/providerRegistry';
import { ActiveUniverseService } from './activeUniverseService';

class StockService {
  public async getAllStocks(): Promise<Company[]> {
    if (providerRegistry.getMode() === 'MOCK_DATA') {
      return [...mockCompanies];
    }
    if (providerRegistry.getMode() === 'REAL_HISTORICAL_GITHUB') {
      const gitHubProvider = providerRegistry.getGitHubProvider();
      const securities = ActiveUniverseService.getAllSecurities();
      return securities.map(s => {
        const history = gitHubProvider.getParsedBarsSync(s.symbol);
        const hasHistory = history.length > 0;
        const latest = hasHistory ? history[history.length - 1] : null;

        let fiftyTwoWeekHigh = latest ? latest.high : 0;
        let fiftyTwoWeekLow = latest ? latest.low : 0;
        if (hasHistory) {
          const yearBars = history.slice(-250);
          fiftyTwoWeekHigh = Math.max(...yearBars.map(b => b.high));
          fiftyTwoWeekLow = Math.min(...yearBars.map(b => b.low));
        }

        return {
          id: `cmp-${s.symbol.toLowerCase()}`,
          symbol: s.symbol,
          name: s.name,
          sectorId: s.sector,
          sectorName: s.sector,
          listingDate: s.listingDate || '2010-01-01',
          paidUpCapital: 5000000000,
          sharesOutstanding: 50000000,
          promoterHoldingPercent: 51,
          publicHoldingPercent: 49,
          ltp: latest ? latest.close : 0,
          openPrice: latest ? latest.open : 0,
          highPrice: latest ? latest.high : 0,
          lowPrice: latest ? latest.low : 0,
          previousClose: latest ? latest.previous_close : 0,
          change: latest ? latest.change : 0,
          changePercent: latest ? latest.change_percent : 0,
          volume: latest ? latest.volume : 0,
          turnover: latest ? latest.turnover : 0,
          transactions: latest ? latest.transactions : 0,
          fiftyTwoWeekHigh,
          fiftyTwoWeekLow,
          isActive: ActiveUniverseService.isEligibleForActiveUniverse(s.symbol, '2026-09-14'),
        };
      });
    }
    // Live mode: call companyRepository. LiveDataSourceUnavailableError will be thrown if unauthenticated.
    const companies = await companyRepository.getAllCompanies();
    return companies.map(c => ({
      id: c.id,
      symbol: c.symbol,
      name: c.company_name || c.symbol,
      sectorId: c.sector_id,
      sectorName: c.sector_id,
      listingDate: c.listed_date || '2020-01-01',
      paidUpCapital: c.paid_up_capital || 0,
      sharesOutstanding: c.listed_shares || 0,
      promoterHoldingPercent: 51,
      publicHoldingPercent: 49,
      ltp: 0,
      openPrice: 0,
      highPrice: 0,
      lowPrice: 0,
      previousClose: 0,
      change: 0,
      changePercent: 0,
      volume: 0,
      turnover: 0,
      transactions: 0,
      fiftyTwoWeekHigh: 0,
      fiftyTwoWeekLow: 0,
      isActive: c.status === 'ACTIVE',
    }));
  }

  public async getStockBySymbol(symbol: string): Promise<Company | null> {
    const clean = ActiveUniverseService.normalizeSymbol(symbol);
    const stocks = await this.getAllStocks();
    const found = stocks.find(s => s.symbol.toUpperCase() === clean);
    if (!found) return null;

    if (found.ltp === 0 && providerRegistry.getMode() === 'REAL_HISTORICAL_GITHUB') {
      const records = await priceHistoryService.getHistoricalPrices(clean);
      if (records.length > 0) {
        const latest = records[records.length - 1];
        const yearBars = records.slice(-250);
        return {
          ...found,
          ltp: latest.close,
          openPrice: latest.open,
          highPrice: latest.high,
          lowPrice: latest.low,
          previousClose: latest.previous_close,
          change: latest.change,
          changePercent: latest.change_percent,
          volume: latest.volume,
          turnover: latest.turnover,
          transactions: latest.transactions,
          fiftyTwoWeekHigh: Math.max(...yearBars.map(b => b.high)),
          fiftyTwoWeekLow: Math.min(...yearBars.map(b => b.low)),
        };
      }
    }
    return found;
  }

  public async searchStocks(query: string): Promise<Company[]> {
    const q = query.trim().toUpperCase();
    if (!q) return this.getAllStocks();
    const stocks = await this.getAllStocks();
    return stocks.filter(
      s => s.symbol.toUpperCase().includes(q) || s.name.toUpperCase().includes(q) || s.sectorName.toUpperCase().includes(q)
    );
  }

  /**
   * Data pipeline: stockService -> priceHistoryService -> priceRepository -> provider
   */
  public async getStockCandles(symbol: string, timeframe: '1D' | '1W' | '1M' | 'INTRA' = '1D'): Promise<CandleData[]> {
    if (providerRegistry.getMode() === 'REAL_DATA' || providerRegistry.getMode() === 'REAL_HISTORICAL_GITHUB') {
      // Live / GitHub mode: strictly inquire priceHistoryService, never substitute mock candles
      const historicalRecords = await priceHistoryService.getHistoricalPrices(symbol);
      const sortedAsc = [...historicalRecords].sort(
        (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
      );

      if (sortedAsc.length === 0) return [];

      if (timeframe === '1D') {
        return sortedAsc.map(p => ({
          timestamp: `${p.date} 15:00:00`,
          date: p.date,
          open: p.open,
          high: p.high,
          low: p.low,
          close: p.close,
          volume: p.volume,
          turnover: p.turnover,
        }));
      }

      if (timeframe === '1W') {
        // Resample daily candles into weekly candles (chunks of 5 trading sessions)
        const weekly: CandleData[] = [];
        for (let i = 0; i < sortedAsc.length; i += 5) {
          const chunk = sortedAsc.slice(i, i + 5);
          const first = chunk[0];
          const last = chunk[chunk.length - 1];
          weekly.push({
            timestamp: `${last.date} 15:00:00`,
            date: last.date,
            open: first.open,
            high: Math.max(...chunk.map(c => c.high)),
            low: Math.min(...chunk.map(c => c.low)),
            close: last.close,
            volume: chunk.reduce((sum, c) => sum + c.volume, 0),
            turnover: chunk.reduce((sum, c) => sum + c.turnover, 0)
          });
        }
        return weekly;
      }

      if (timeframe === '1M') {
        // Resample daily candles into monthly candles (chunks of ~21 trading sessions)
        const monthly: CandleData[] = [];
        for (let i = 0; i < sortedAsc.length; i += 21) {
          const chunk = sortedAsc.slice(i, i + 21);
          const first = chunk[0];
          const last = chunk[chunk.length - 1];
          monthly.push({
            timestamp: `${last.date} 15:00:00`,
            date: last.date,
            open: first.open,
            high: Math.max(...chunk.map(c => c.high)),
            low: Math.min(...chunk.map(c => c.low)),
            close: last.close,
            volume: chunk.reduce((sum, c) => sum + c.volume, 0),
            turnover: chunk.reduce((sum, c) => sum + c.turnover, 0)
          });
        }
        return monthly;
      }

      // INTRA: show the latest trading session's progression
      const last = sortedAsc[sortedAsc.length - 1];
      const hours = ['11:00', '12:00', '13:00', '14:00', '15:00'];
      return hours.map((hr, idx) => {
        const factor = idx / 4;
        const intraClose = Math.round((last.open + (last.close - last.open) * factor) * 10) / 10;
        return {
          timestamp: `${last.date} ${hr}:00`,
          date: last.date,
          open: idx === 0 ? last.open : Math.round((last.open + (last.close - last.open) * ((idx - 1) / 4)) * 10) / 10,
          high: Math.round(Math.max(last.open, intraClose, last.high * (0.99 + factor * 0.01)) * 10) / 10,
          low: Math.round(Math.min(last.open, intraClose, last.low * (1.01 - factor * 0.01)) * 10) / 10,
          close: intraClose,
          volume: Math.round(last.volume / 5),
          turnover: Math.round(last.turnover / 5)
        };
      });
    }

    // 1. Inquire priceHistoryService for normalized price records in MOCK mode
    const historicalRecords = await priceHistoryService.getHistoricalPrices(symbol);
    const stock = await this.getStockBySymbol(symbol);
    const targetLTP = stock ? stock.ltp : 500;

    // If historical price records exist for this symbol, format them into candle series
    if (historicalRecords.length >= 3 && timeframe === '1D') {
      const sortedAsc = [...historicalRecords].sort(
        (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
      );
      return sortedAsc.map(p => ({
        timestamp: `${p.date} 15:00:00`,
        date: p.date,
        open: p.open,
        high: p.high,
        low: p.low,
        close: p.close,
        volume: p.volume,
        turnover: p.turnover,
      }));
    }

    // Otherwise use calibrated base series relative to stock LTP
    const base = mockCandlesCHCL;
    const scale = targetLTP / 548.0;

    if (timeframe === '1D') {
      return base.map(c => ({
        ...c,
        open: Math.round(c.open * scale * 10) / 10,
        high: Math.round(c.high * scale * 10) / 10,
        low: Math.round(c.low * scale * 10) / 10,
        close: Math.round(c.close * scale * 10) / 10,
        volume: Math.round(c.volume * (stock ? stock.volume / 384500 : 1)),
      }));
    }

    if (timeframe === 'INTRA') {
      // 15-minute intraday snapshots
      const times = ['11:15', '11:45', '12:15', '12:45', '13:15', '13:45', '14:15', '14:45', '15:00'];
      let current = stock ? stock.openPrice : targetLTP * 0.98;
      return times.map(t => {
        const step = (Math.random() - 0.45) * 4;
        const open = Math.round(current * 10) / 10;
        const close = Math.round((current + step) * 10) / 10;
        const high = Math.round((Math.max(open, close) + Math.random() * 2) * 10) / 10;
        const low = Math.round((Math.min(open, close) - Math.random() * 2) * 10) / 10;
        current = close;
        return {
          timestamp: `2026-09-11 ${t}:00`,
          date: t,
          open,
          high,
          low,
          close,
          volume: Math.round(20000 + Math.random() * 40000),
        };
      });
    }

    // Weekly or monthly aggregates
    return base.slice(-12).map((c, idx) => ({
      ...c,
      date: timeframe === '1W' ? `Wk ${idx + 1}` : `M${idx + 1}`,
      open: Math.round(c.open * scale * 10) / 10,
      high: Math.round(c.high * scale * 1.02 * 10) / 10,
      low: Math.round(c.low * scale * 0.98 * 10) / 10,
      close: Math.round(c.close * scale * 10) / 10,
      volume: Math.round(c.volume * 3.5),
    }));
  }
}

export const stockService = new StockService();
