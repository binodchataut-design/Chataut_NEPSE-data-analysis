import {
  IMarketDataProvider,
  IStockDataProvider,
  IFundamentalDataProvider,
  IBrokerDataProvider,
} from './interfaces';
import { MockMarketDataProvider } from './mock/MockMarketDataProvider';
import { MockStockDataProvider } from './mock/MockStockDataProvider';
import { MockFundamentalDataProvider } from './mock/MockFundamentalDataProvider';
import { MockBrokerDataProvider } from './mock/MockBrokerDataProvider';
import {
  LiveMarketDataProvider,
  LiveStockDataProvider,
  LiveFundamentalDataProvider,
  LiveBrokerDataProvider,
} from './live/LiveProviders';
import { GitHubHistoricalDataProvider, gitHubHistoricalDataProvider } from './github/GitHubHistoricalDataProvider';
import { DataSourceMode } from '../types';
import { ActiveDataState, ProviderStatusInfo } from '../types/dataInfrastructure';
import { registerDataModeGetter } from '../data/normalizedMasterData';
import { CurrentStateSnapshotService } from '../services/currentStateSnapshotService';

class ProviderRegistry {
  private currentMode: DataSourceMode = 'MOCK_DATA';

  // Mock Singletons
  private mockMarket = new MockMarketDataProvider();
  private mockStock = new MockStockDataProvider();
  private mockFundamental = new MockFundamentalDataProvider();
  private mockBroker = new MockBrokerDataProvider();

  // Live Singletons (disabled stubs)
  private liveMarket = new LiveMarketDataProvider();
  private liveStock = new LiveStockDataProvider();
  private liveFundamental = new LiveFundamentalDataProvider();
  private liveBroker = new LiveBrokerDataProvider();

  // Real Historical GitHub Provider
  private gitHubHistorical = gitHubHistoricalDataProvider;

  public setMode(mode: DataSourceMode): void {
    this.currentMode = mode;
    try {
      CurrentStateSnapshotService.clearAllCaches();
    } catch {
      // safe fallback
    }
  }

  public getMode(): DataSourceMode {
    return this.currentMode;
  }

  public isLiveMode(): boolean {
    return this.currentMode === 'REAL_DATA';
  }

  public isGitHubHistoricalMode(): boolean {
    return this.currentMode === 'REAL_HISTORICAL_GITHUB';
  }

  public getActiveDataState(): ActiveDataState {
    if (this.currentMode === 'MOCK_DATA') {
      return 'MOCK_DATA';
    }
    if (this.currentMode === 'REAL_HISTORICAL_GITHUB') {
      return 'REAL_HISTORICAL_GITHUB';
    }
    const status = this.getStockProvider().getStatus();
    return status.providerStatus;
  }

  public getProviderStatus(): ProviderStatusInfo {
    return this.getStockProvider().getStatus();
  }

  public getMarketProvider(): IMarketDataProvider {
    if (this.currentMode === 'REAL_HISTORICAL_GITHUB') {
      return this.gitHubHistorical;
    }
    return this.currentMode === 'REAL_DATA' ? this.liveMarket : this.mockMarket;
  }

  public getStockProvider(): IStockDataProvider {
    if (this.currentMode === 'REAL_HISTORICAL_GITHUB') {
      return this.gitHubHistorical;
    }
    return this.currentMode === 'REAL_DATA' ? this.liveStock : this.mockStock;
  }

  public getFundamentalProvider(): IFundamentalDataProvider {
    return this.currentMode === 'REAL_DATA' ? this.liveFundamental : this.mockFundamental;
  }

  public getBrokerProvider(): IBrokerDataProvider {
    return this.currentMode === 'REAL_DATA' ? this.liveBroker : this.mockBroker;
  }

  public getGitHubProvider(): GitHubHistoricalDataProvider {
    return this.gitHubHistorical;
  }
}

export const providerRegistry = new ProviderRegistry();
registerDataModeGetter(() => providerRegistry.getMode());

