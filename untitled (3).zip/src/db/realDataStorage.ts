/**
 * Real Data Persistent Store (IndexedDB + In-Memory Fast Cache)
 *
 * Implements durable, structured browser storage for real historical NEPSE records.
 * Bypasses localStorage 5MB size limits: IndexedDB accommodates hundreds of megabytes
 * for 370+ securities x 5+ years of OHLCV bars without quota issues.
 *
 * Provides:
 * 1. Synchronous O(1) in-memory cache for ultra-fast UI rendering & calculation loops
 * 2. Asynchronous write-through to IndexedDB for cross-session & reload durability
 * 3. Point-in-time querying and provenance tracking
 * 4. Graceful fallback for non-browser/Node environments
 */

import { HistoricalPriceRecord, MarketIndexRecord } from '../types/dataInfrastructure';
import { DataProvenance } from '../types/realData';

export interface DiscoveredGitHubFile {
  path: string;
  symbol: string;
  rawUrl: string;
  size?: number;
  sha?: string;
}

export interface RealDataStorageStats {
  symbolsCount: number;
  rowsCount: number;
  earliestDate: string;
  latestDate: string;
  indicesCount: number;
  indexRowsCount: number;
  filesDiscoveredCount: number;
  lastUpdated: string;
}

const DB_NAME = 'NepseRealHistoricalDB';
const DB_VERSION = 1;
const STORE_STOCK_BARS = 'stock_bars';
const STORE_INDEX_BARS = 'index_bars';
const STORE_PROVENANCE = 'provenance';
const STORE_DISCOVERED = 'discovered_files';
const STORE_META = 'meta';

class RealDataStorage {
  private memoryStockBars: Map<string, HistoricalPriceRecord[]> = new Map();
  private memoryIndexBars: Map<string, MarketIndexRecord[]> = new Map();
  private memoryProvenance: Map<string, DataProvenance> = new Map();
  private memoryDiscoveredFiles: DiscoveredGitHubFile[] = [];
  private dbPromise: Promise<IDBDatabase | null> | null = null;
  private isInitialized = false;

  constructor() {
    this.initDatabase();
  }

  private isBrowserIndexedDBAvailable(): boolean {
    return typeof window !== 'undefined' && typeof window.indexedDB !== 'undefined';
  }

  private async initDatabase(): Promise<IDBDatabase | null> {
    if (!this.isBrowserIndexedDBAvailable()) {
      return null;
    }

    if (this.dbPromise) {
      return this.dbPromise;
    }

    this.dbPromise = new Promise<IDBDatabase | null>((resolve) => {
      try {
        const req = window.indexedDB.open(DB_NAME, DB_VERSION);

        req.onupgradeneeded = (e: any) => {
          const db: IDBDatabase = e.target.result;
          if (!db.objectStoreNames.contains(STORE_STOCK_BARS)) {
            const stockStore = db.createObjectStore(STORE_STOCK_BARS, { keyPath: 'storageKey' });
            stockStore.createIndex('symbol', 'symbol', { unique: false });
            stockStore.createIndex('date', 'date', { unique: false });
          }
          if (!db.objectStoreNames.contains(STORE_INDEX_BARS)) {
            const indexStore = db.createObjectStore(STORE_INDEX_BARS, { keyPath: 'storageKey' });
            indexStore.createIndex('index_id', 'index_id', { unique: false });
          }
          if (!db.objectStoreNames.contains(STORE_PROVENANCE)) {
            db.createObjectStore(STORE_PROVENANCE, { keyPath: 'symbol' });
          }
          if (!db.objectStoreNames.contains(STORE_DISCOVERED)) {
            db.createObjectStore(STORE_DISCOVERED, { keyPath: 'symbol' });
          }
          if (!db.objectStoreNames.contains(STORE_META)) {
            db.createObjectStore(STORE_META, { keyPath: 'key' });
          }
        };

        req.onsuccess = async (e: any) => {
          const db: IDBDatabase = e.target.result;
          await this.hydrateFromIndexedDB(db);
          this.isInitialized = true;
          resolve(db);
        };

        req.onerror = () => {
          console.warn('[RealDataStorage] IndexedDB open error; continuing with memory cache.');
          resolve(null);
        };
      } catch (err) {
        console.warn('[RealDataStorage] IndexedDB initialization failed:', err);
        resolve(null);
      }
    });

    return this.dbPromise;
  }

  /**
   * Pre-loads all records from IndexedDB into memory cache upon application startup
   */
  private async hydrateFromIndexedDB(db: IDBDatabase): Promise<void> {
    return new Promise((resolve) => {
      try {
        const tx = db.transaction([STORE_STOCK_BARS, STORE_INDEX_BARS, STORE_PROVENANCE, STORE_DISCOVERED], 'readonly');

        // Load Stock Bars
        const stockStore = tx.objectStore(STORE_STOCK_BARS);
        const stockReq = stockStore.getAll();
        stockReq.onsuccess = () => {
          const allStockItems: Array<HistoricalPriceRecord & { storageKey: string }> = stockReq.result || [];
          const grouped = new Map<string, HistoricalPriceRecord[]>();
          for (const item of allStockItems) {
            const sym = item.symbol.toUpperCase();
            if (!grouped.has(sym)) {
              grouped.set(sym, []);
            }
            grouped.get(sym)!.push(item);
          }
          // Sort each symbol ascending by date
          for (const [sym, records] of grouped.entries()) {
            records.sort((a, b) => a.date.localeCompare(b.date));
            this.memoryStockBars.set(sym, records);
          }
        };

        // Load Index Bars
        const indexStore = tx.objectStore(STORE_INDEX_BARS);
        const indexReq = indexStore.getAll();
        indexReq.onsuccess = () => {
          const allIndexItems: Array<MarketIndexRecord & { storageKey: string }> = indexReq.result || [];
          const grouped = new Map<string, MarketIndexRecord[]>();
          for (const item of allIndexItems) {
            const idxId = item.index_id.toUpperCase();
            if (!grouped.has(idxId)) {
              grouped.set(idxId, []);
            }
            grouped.get(idxId)!.push(item);
          }
          for (const [idxId, records] of grouped.entries()) {
            records.sort((a, b) => a.date.localeCompare(b.date));
            this.memoryIndexBars.set(idxId, records);
          }
        };

        // Load Provenance
        const provStore = tx.objectStore(STORE_PROVENANCE);
        const provReq = provStore.getAll();
        provReq.onsuccess = () => {
          const provItems: DataProvenance[] = provReq.result || [];
          for (const p of provItems) {
            this.memoryProvenance.set(p.symbol.toUpperCase(), p);
          }
        };

        // Load Discovered Files
        const discStore = tx.objectStore(STORE_DISCOVERED);
        const discReq = discStore.getAll();
        discReq.onsuccess = () => {
          this.memoryDiscoveredFiles = discReq.result || [];
        };

        tx.oncomplete = () => {
          resolve();
        };

        tx.onerror = () => {
          resolve();
        };
      } catch (err) {
        console.warn('[RealDataStorage] Hydration error:', err);
        resolve();
      }
    });
  }

  // =========================================================================
  // Stock Bar Storage
  // =========================================================================

  public async saveStockBars(
    symbol: string,
    bars: HistoricalPriceRecord[],
    provenance?: DataProvenance
  ): Promise<void> {
    const cleanSym = symbol.trim().toUpperCase();
    const sorted = [...bars].sort((a, b) => a.date.localeCompare(b.date));

    // Update in-memory cache immediately
    this.memoryStockBars.set(cleanSym, sorted);

    if (provenance) {
      this.memoryProvenance.set(cleanSym, provenance);
    }

    // Write to IndexedDB
    const db = await this.initDatabase();
    if (!db) return;

    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction([STORE_STOCK_BARS, STORE_PROVENANCE], 'readwrite');
        const stockStore = tx.objectStore(STORE_STOCK_BARS);

        for (const bar of sorted) {
          const storageKey = `${cleanSym}_${bar.date}`;
          stockStore.put({ ...bar, storageKey, symbol: cleanSym });
        }

        if (provenance) {
          const provStore = tx.objectStore(STORE_PROVENANCE);
          provStore.put(provenance);
        }

        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      } catch (err) {
        console.warn('[RealDataStorage] Failed to write stock bars to IndexedDB:', err);
        resolve();
      }
    });
  }

  public getStockBarsSync(symbol: string): HistoricalPriceRecord[] {
    const cleanSym = symbol.trim().toUpperCase();
    return this.memoryStockBars.get(cleanSym) || [];
  }

  public async getStockBars(symbol: string): Promise<HistoricalPriceRecord[]> {
    return this.getStockBarsSync(symbol);
  }

  public hasStockBars(symbol: string): boolean {
    const cleanSym = symbol.trim().toUpperCase();
    const bars = this.memoryStockBars.get(cleanSym);
    return Boolean(bars && bars.length > 0);
  }

  public getLatestStockBar(symbol: string): HistoricalPriceRecord | null {
    const bars = this.getStockBarsSync(symbol);
    if (bars.length === 0) return null;
    return bars[bars.length - 1];
  }

  public getAllStoredSymbols(): string[] {
    return Array.from(this.memoryStockBars.keys());
  }

  // =========================================================================
  // Index Bar Storage
  // =========================================================================

  public async saveIndexBars(indexId: string, bars: MarketIndexRecord[]): Promise<void> {
    const cleanId = indexId.trim().toUpperCase();
    const sorted = [...bars].sort((a, b) => a.date.localeCompare(b.date));

    // In-memory update
    this.memoryIndexBars.set(cleanId, sorted);

    const db = await this.initDatabase();
    if (!db) return;

    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction([STORE_INDEX_BARS], 'readwrite');
        const store = tx.objectStore(STORE_INDEX_BARS);

        for (const bar of sorted) {
          const storageKey = `${cleanId}_${bar.date}`;
          store.put({ ...bar, storageKey, index_id: cleanId });
        }

        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      } catch (err) {
        console.warn('[RealDataStorage] Failed to write index bars to IndexedDB:', err);
        resolve();
      }
    });
  }

  public getIndexBars(indexId: string): MarketIndexRecord[] {
    const cleanId = indexId.trim().toUpperCase();
    return this.memoryIndexBars.get(cleanId) || [];
  }

  public getLatestIndexBar(indexId: string): MarketIndexRecord | null {
    const bars = this.getIndexBars(indexId);
    if (bars.length === 0) return null;
    return bars[bars.length - 1];
  }

  // =========================================================================
  // Discovered Files & Metadata
  // =========================================================================

  public async saveDiscoveredFiles(files: DiscoveredGitHubFile[]): Promise<void> {
    this.memoryDiscoveredFiles = files;

    const db = await this.initDatabase();
    if (!db) return;

    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction([STORE_DISCOVERED], 'readwrite');
        const store = tx.objectStore(STORE_DISCOVERED);
        for (const f of files) {
          store.put(f);
        }
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      } catch (err) {
        console.warn('[RealDataStorage] Failed to write discovered files:', err);
        resolve();
      }
    });
  }

  public getDiscoveredFiles(): DiscoveredGitHubFile[] {
    return this.memoryDiscoveredFiles;
  }

  public async saveProvenance(symbol: string, prov: DataProvenance): Promise<void> {
    const clean = symbol.trim().toUpperCase();
    this.memoryProvenance.set(clean, prov);

    const db = await this.initDatabase();
    if (!db) return;

    return new Promise((resolve) => {
      try {
        const tx = db.transaction([STORE_PROVENANCE], 'readwrite');
        tx.objectStore(STORE_PROVENANCE).put(prov);
        tx.oncomplete = () => resolve();
      } catch {
        resolve();
      }
    });
  }

  public getProvenance(symbol: string): DataProvenance | null {
    return this.memoryProvenance.get(symbol.trim().toUpperCase()) || null;
  }

  public getAllProvenances(): DataProvenance[] {
    return Array.from(this.memoryProvenance.values());
  }

  // =========================================================================
  // Health & Statistics
  // =========================================================================

  public getStorageStats(): RealDataStorageStats {
    let totalRows = 0;
    let earliest = '9999-99-99';
    let latest = '0000-00-00';

    for (const bars of this.memoryStockBars.values()) {
      totalRows += bars.length;
      if (bars.length > 0) {
        if (bars[0].date < earliest) earliest = bars[0].date;
        if (bars[bars.length - 1].date > latest) latest = bars[bars.length - 1].date;
      }
    }

    let indexRows = 0;
    for (const bars of this.memoryIndexBars.values()) {
      indexRows += bars.length;
      if (bars.length > 0) {
        if (bars[0].date < earliest) earliest = bars[0].date;
        if (bars[bars.length - 1].date > latest) latest = bars[bars.length - 1].date;
      }
    }

    return {
      symbolsCount: this.memoryStockBars.size,
      rowsCount: totalRows,
      earliestDate: earliest === '9999-99-99' ? 'N/A' : earliest,
      latestDate: latest === '0000-00-00' ? 'N/A' : latest,
      indicesCount: this.memoryIndexBars.size,
      indexRowsCount: indexRows,
      filesDiscoveredCount: this.memoryDiscoveredFiles.length,
      lastUpdated: new Date().toISOString()
    };
  }

  public async clearAllRealData(): Promise<void> {
    this.memoryStockBars.clear();
    this.memoryIndexBars.clear();
    this.memoryProvenance.clear();
    this.memoryDiscoveredFiles = [];

    const db = await this.initDatabase();
    if (!db) return;

    return new Promise((resolve) => {
      try {
        const tx = db.transaction([STORE_STOCK_BARS, STORE_INDEX_BARS, STORE_PROVENANCE, STORE_DISCOVERED, STORE_META], 'readwrite');
        tx.objectStore(STORE_STOCK_BARS).clear();
        tx.objectStore(STORE_INDEX_BARS).clear();
        tx.objectStore(STORE_PROVENANCE).clear();
        tx.objectStore(STORE_DISCOVERED).clear();
        tx.objectStore(STORE_META).clear();
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      } catch {
        resolve();
      }
    });
  }
}

export const realDataStorage = new RealDataStorage();
