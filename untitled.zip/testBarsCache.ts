import 'dotenv/config';
import {
  initializeBarsCache,
  getCachedSymbols,
  getCachedBars,
  isCacheReady,
} from './src/data/liveBarsCache';
import { providerRegistry } from './src/providers/providerRegistry';

async function run() {
  console.log('--- TEST 1: Cache before initialization ---');
  console.log('isCacheReady():', isCacheReady());
  console.log('getCachedSymbols() length:', getCachedSymbols().length);

  console.log('\n--- TEST 2: Initializing in SUPABASE mode ---');
  providerRegistry.setMode('SUPABASE');
  console.log('Current provider mode:', providerRegistry.getMode());

  const t0 = Date.now();
  await initializeBarsCache();
  const elapsedSec = ((Date.now() - t0) / 1000).toFixed(2);

  console.log('isCacheReady():', isCacheReady());
  const symbols = getCachedSymbols();
  console.log('getCachedSymbols().length:', symbols.length);

  let totalBars = 0;
  for (const s of symbols) {
    totalBars += getCachedBars(s).length;
  }
  console.log('Total bars across all symbols:', totalBars);
  console.log('Elapsed time:', elapsedSec, 'seconds');
  console.log('Sample symbols (first 10):', symbols.slice(0, 10));
  if (symbols.length > 0) {
    const sampleSym = symbols[0];
    const sampleBars = getCachedBars(sampleSym);
    console.log(`Sample symbol "${sampleSym}" bar count:`, sampleBars.length);
    console.log('Sample symbol first bar:', sampleBars[0]);
    console.log('Sample symbol last bar:', sampleBars[sampleBars.length - 1]);
  }

  console.log('\n--- TEST 3: Initializing in MOCK_DATA mode ---');
  providerRegistry.setMode('MOCK_DATA');
  console.log('Current provider mode:', providerRegistry.getMode());
  await initializeBarsCache();
  const mockSymbols = getCachedSymbols();
  console.log('Mock getCachedSymbols().length:', mockSymbols.length);
  let mockTotalBars = 0;
  for (const s of mockSymbols) {
    mockTotalBars += getCachedBars(s).length;
  }
  console.log('Mock total bars across all symbols:', mockTotalBars);
}

run().catch((err) => {
  console.error('Test execution failed:', err);
  process.exit(1);
});
