import { createClient, SupabaseClient } from '@supabase/supabase-js';

const getEnvVar = (key: string): string => {
  if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env[key]) {
    return String(import.meta.env[key]);
  }
  if (typeof process !== 'undefined' && process.env && process.env[key]) {
    return String(process.env[key]);
  }
  return '';
};

const DEFAULT_SUPABASE_URL = 'https://tbeznjlzyinoaorcovis.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRiZXpuamx6eWlub2FvcmNvdmlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk0NzQ5OTIsImV4cCI6MjEwNTA1MDk5Mn0.7o8LvlY-xyH1B959-GZlkfUyomeoCAAL-Ex9tW3LXnE';

const rawUrl =
  getEnvVar('VITE_SUPABASE_URL') || getEnvVar('SUPABASE_URL') || DEFAULT_SUPABASE_URL;
const rawAnonKey =
  getEnvVar('VITE_SUPABASE_ANON_KEY') ||
  getEnvVar('SUPABASE_SERVICE_ROLE_KEY') ||
  getEnvVar('SUPABASE_ANON_KEY') ||
  DEFAULT_SUPABASE_ANON_KEY;

export const isSupabaseConfigured: boolean = Boolean(
  rawUrl &&
  rawAnonKey &&
  rawUrl.trim() !== '' &&
  rawAnonKey.trim() !== ''
);

// Fallback chainable query builder when Supabase is not configured
function createUnconfiguredSupabaseClient(): SupabaseClient {
  const errorResult = {
    data: null,
    error: {
      message:
        'Supabase configuration missing: VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY must be provided in environment variables.',
      details:
        'Please add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your environment secrets or switch to MOCK_DATA mode.',
      hint: 'Configure environment variables in settings or .env',
      code: 'CONFIG_MISSING',
    },
  };

  const createHandler = (): any => {
    const fn: any = () => proxy;
    const proxy = new Proxy(fn, {
      get(_target, prop) {
        if (prop === 'then') {
          return (resolve: (val: any) => any) => Promise.resolve(errorResult).then(resolve);
        }
        if (prop === 'catch') {
          return (reject: (val: any) => any) => Promise.resolve(errorResult).catch(reject);
        }
        return createHandler();
      },
      apply() {
        return createHandler();
      },
    });
    return proxy;
  };

  return createHandler() as SupabaseClient;
}

const cleanUrl = rawUrl ? rawUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '') : '';

export const supabase: SupabaseClient = isSupabaseConfigured
  ? createClient(cleanUrl, rawAnonKey)
  : createUnconfiguredSupabaseClient();

